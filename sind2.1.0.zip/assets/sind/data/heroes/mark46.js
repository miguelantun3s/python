var iron_man = implement("sind:external/iron_man_base");
var landing = implement("sind:external/superhero_landing");
var jarvis = implement("sind:external/jarvis");

function init(hero) {
    hero.setName("Iron Man/\u00A74\u00A7lMark 46 \u00A76\u00A7l(XLVI)");

    hero.addPowers("sind:mk46", "sind:adv", "sind:friday");
    //tier, sentry, is advanced, type of rocket, can use arm laser, leftclick weapon type, isfriday, tony system
    iron_man.init(hero, 7, true, false, "SHOULDER", true, "beams", true, true);
    hero.addAttribute("PUNCH_DAMAGE", 7.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);

    hero.addKeyBind("ENERGY_PROJECTION", "Repulsor Beams", -1);
    hero.addKeyBind("SONIC_WAVES", "Sonic Repulsors", -1);
    hero.addKeyBind("FAKE_AIM", "Arm Lasers", 5);
    hero.addKeyBind("AIM_BRUH", "Repulsor Blast/Sonic Gauntlet", 1);
    hero.addKeyBind("AIM_BRUH_C_4", "\u00A7eRight/Left-Click \u00A77-\u00A7r Repulsor Blast/Sonic Gauntlet", 1);
    hero.addKeyBind("SONIC_SFX", "Sonic Repulsors SFX", -1);

    var rocketArm = iron_man.createRocketArm(hero, 4, 4);
    hero.addPrimaryEquipment("fiskheroes:superhero_chestplate{HeroType:sind:mark46_watch}", true, item => item.nbt().getString("HeroType") == "sind:mark46_watch");

    hero.setTickHandler((entity, manager) => {
        iron_man.tick(entity, manager);
        if (!entity.is("DISPLAY") && entity.is("PLAYER")) {
            landing.tick(entity, manager);
            jarvis.health(entity, manager, "friday");
            jarvis.lowhealth(entity, manager, "friday");
            jarvis.heatwarning(entity, manager, "friday");
            jarvis.timers(entity, manager);
            rocketArm.tick(entity, manager);
        }

        var nbt = entity.getWornChestplate().nbt();
        var hasItem = !nbt.hasKey("Equipment")
            || nbt.getTagList("Equipment").getCompoundTag(0).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType") == "sind:mark46_watch"
            || nbt.getTagList("Equipment").getCompoundTag(1).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType") == "sind:mark46_watch"
            || nbt.getTagList("Equipment").getCompoundTag(2).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType") == "sind:mark46_watch"
            || nbt.getTagList("Equipment").getCompoundTag(3).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType") == "sind:mark46_watch"
            || nbt.getTagList("Equipment").getCompoundTag(4).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType") == "sind:mark46_watch";

        if (hasItem) {
            manager.setData(entity, "sind:dyn/watch", true);
        } else {
            manager.setData(entity, "sind:dyn/watch", false);
        }
    });
}