function init(hero) {
    hero.setName("Iron Man/\u00A74\u00A76\u00A7lMark 42 \u00A74\u00A7l(XLII) \u00A7f\u00A7l- \u00A77\u00A7lProdigal Son");
    hero.setTier(2);
    hero.hide()

    hero.setHelmet("Helmet");

    hero.addPowers("fiskheroes:archery");
    hero.setTickHandler((entity, manager) => {
        var nbt = entity.getWornHelmet().nbt();
        var suitType = entity.getWornHelmet().suitType().split("/")[0];
        var unbreakable = nbt.hasKey("Unbreakable") ? nbt.getBoolean("Unbreakable") : false;
        if (suitType == "sind:42_1" && !unbreakable) {
            manager.setBoolean(nbt, "Unbreakable", true);
        }
    });
}