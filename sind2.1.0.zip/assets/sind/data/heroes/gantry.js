var valid_suits = ["sind:mark2", "sind:mark3", "sind:mark4", "sind:mark6", "sind:warmachine_mk1",
    //alts
    "sind:mark3/gm", "sind:mark3/gold", "sind:mark3/rc", "sind:mark3/stealth",
    "sind:mark4/sp", "sind:mark4/v2", "sind:mark6/v2", "sind:mark6/sc",
    "sind:warmachine_mk1/r", "sind:warmachine_mk1/mm"
];

var suit_map = {
    "mark2": ["Mark 2", "J"],
    "mark3": ["Mark 3", "J"],
    "mark4": ["Mark 4", "J"],
    "mark6": ["Mark 6", "J"],
    "warmachine_mk1": ["War Machine Mark 1", "H"],
}
var suit_map_keys = Object.keys(suit_map);
var iron_man = implement("sind:external/iron_man_base");
var jarvis = implement("sind:external/jarvis");
function init(hero) {
    hero.setName("\u00A7rGantry");
    hero.setTier(1);

    hero.setHelmet("Top Section");
    hero.setChestplate("Upper Middle Section");
    hero.setLeggings("Lower Middle Section");
    hero.setBoots("Bottom Section");

    hero.addPowers("sind:gantry");

    hero.addKeyBind("PISTON", "\u00A74Please stand on a 5x5 grid of pistons", 1);
    hero.addKeyBind("SUMMON", "Summon Suit", 1);
    hero.addKeyBind("INCOMPLETE", "\u00A74Suit set seems to be incomplete", 1);
    hero.addKeyBind("INCOMPATIBLE", "\u00A74Suit is incompatible. Please equip a different suit", 1);
    hero.addKeyBind("DAMAGED", "\u00A74Suit is too damaged to be summoned", 1);
    hero.addKeyBind("REQUEST", "Please equip a suit to be summoned", 1);

    for (var i = 0; i < suit_map_keys.length; i++) {
        var suit = suit_map_keys[i];
        hero.addKeyBind("SUMMON_A_" + suit.toUpperCase(), "Summon " + suit_map[suit][0], 1);
    }

    hero.addPrimaryEquipment("fiskheroes:superhero_helmet{HeroType:sind:gantry_equip}", false);
    hero.addPrimaryEquipment("fiskheroes:superhero_chestplate{HeroType:sind:gantry_equip}", false);
    hero.addPrimaryEquipment("fiskheroes:superhero_leggings{HeroType:sind:gantry_equip}", false);
    hero.addPrimaryEquipment("fiskheroes:superhero_boots{HeroType:sind:gantry_equip}", false);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addAttributeProfile("DONTMOVE", dontMoveProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.setTickHandler((entity, manager) => {
        var nbt = entity.getWornChestplate().nbt();
        var suit = getSuit(entity);
        manager.setString(nbt, "Pick", suit);
        var pick = nbt.getString("Pick");
        var suitType0 = entity.getWornHelmet().suitType().split("/")[0];
        var suitType1 = entity.getWornChestplate().suitType().split("/")[0];
        var suitType2 = entity.getWornLeggings().suitType().split("/")[0];
        var suitType3 = entity.getWornBoots().suitType().split("/")[0];
        var unbreakable0 = entity.getWornHelmet().nbt().hasKey("Unbreakable") ? entity.getWornHelmet().nbt().getBoolean("Unbreakable") : false;
        var unbreakable1 = nbt.hasKey("Unbreakable") ? nbt.getBoolean("Unbreakable") : false;
        var unbreakable2 = entity.getWornLeggings().nbt().hasKey("Unbreakable") ? entity.getWornLeggings().nbt().getBoolean("Unbreakable") : false;
        var unbreakable3 = entity.getWornBoots().nbt().hasKey("Unbreakable") ? entity.getWornBoots().nbt().getBoolean("Unbreakable") : false;
        if (suitType0 == "sind:gantry" && !unbreakable0) {
            manager.setBoolean(entity.getWornHelmet().nbt(), "Unbreakable", true);
        }
        if (suitType1 == "sind:gantry" && !unbreakable1) {
            manager.setBoolean(nbt, "Unbreakable", true);
        }
        if (suitType2 == "sind:gantry" && !unbreakable2) {
            manager.setBoolean(entity.getWornLeggings().nbt(), "Unbreakable", true);
        }
        if (suitType3 == "sind:gantry" && !unbreakable3) {
            manager.setBoolean(entity.getWornBoots().nbt(), "Unbreakable", true);
        }

        var getPiece = tag => {
            return nbt.getTagList("Equipment").getCompoundTag(tag).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType");
        }
        var same = getPiece(0) == getPiece(1) && getPiece(1) == getPiece(2) && getPiece(2) == getPiece(3);
        if ((!same || nbt.getTagList("Equipment").tagCount() < 4) && entity.getData("sind:dyn/summon")) {
            manager.setData(entity, "sind:dyn/summon", false);
            manager.setInterpolatedData(entity, "sind:dyn/summon_timer", 0);
        }

        if ((entity.getData("sind:dyn/summon_timer") >= 1) && (valid_suits.indexOf(pick) !== -1 && pick != "" && pick != "incomplete" && pick != "damaged" && pick != "incompatible")) {
            // Transform current suit to a selected suit
            var equipments = nbt.getTagList("Equipment");
            
            var gp_ammo = -1;
            var fc_ammo = -1;
            var tnt_ammo = -1;
            if (getIndex(equipments, 1) != null) {
                var mainTag = getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").getTagList("Equipment");
                var hasKey = getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").hasKey("Equipment");

                gp_ammo = getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").hasKey("gp_ammo") ? getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").getByte("gp_ammo") : -1;
                fc_ammo = getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").hasKey("fc_ammo") ? getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").getByte("fc_ammo") : -1;
                tnt_ammo = getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").hasKey("tnt_ammo") ? getIndex(equipments, 1).getCompoundTag("Item").getCompoundTag("tag").getByte("tnt_ammo") : -1;

                equipments = manager.newTagList();
                var choice = pick.split("/")[0].split(":")[1];
                var hasArmRocket = choice == "mark3" || choice == "mark4";
                //SPECIAL CASE FOR KEEPING ARM ROCKET AMMO, MK6 REDSTONE
                var numSlots = hasArmRocket ? 4 : choice == "mark6" ? 5 : choice == "warmachine_mk1" ? 2 : -1;
                for (var i = 1; i < numSlots; ++i) {
                    tag = getIndex(mainTag, i);
                    if (tag != null) {
                        setEquipmentItem(manager, i, equipments, tag);
                    }
                }
                setEquipmentItem(manager, 0, equipments, manager.newCompoundTag('{Item:{id:' + PackLoader.getNumericalItemId("fiskheroes:mini_suit") + 's,Count:1b,tag:{Suit:"sind:gantry"},Damage:0s},Index:0b}'));
                manager.setTagList(nbt, "Equipment", equipments);
            }
            if (suitType0 == "sind:gantry") {
                manager.setBoolean(entity.getWornHelmet().nbt(), "Unbreakable", false);
            }
            if (suitType1 == "sind:gantry") {
                manager.setBoolean(nbt, "Unbreakable", false);
                if (gp_ammo != -1) {
                    manager.setByte(nbt, "gp_ammo", gp_ammo);
                }
                if (fc_ammo != -1) {
                    manager.setByte(nbt, "fc_ammo", fc_ammo);
                }
                if (tnt_ammo != -1) {
                    manager.setByte(nbt, "tnt_ammo", tnt_ammo);
                }
            }
            if (suitType2 == "sind:gantry") {
                manager.setBoolean(entity.getWornLeggings().nbt(), "Unbreakable", false);
            }
            if (suitType3 == "sind:gantry") {
                manager.setBoolean(entity.getWornBoots().nbt(), "Unbreakable", false);
            }

            manager.setInterpolatedData(entity, "sind:dyn/tony_to_suit", 1);
            manager.setString(entity.getWornHelmet().nbt(), "HeroType", pick);
            manager.setString(nbt, "HeroType", pick);
            manager.setString(entity.getWornLeggings().nbt(), "HeroType", pick);
            manager.setString(entity.getWornBoots().nbt(), "HeroType", pick);
            manager.removeTag(nbt, "Pick");
            //idk why but i need to set this twice?
            manager.setInterpolatedData(entity, "sind:dyn/tony_to_suit", 1);

            printMessage(entity, manager, pick);
        }
    });
}

function getSuit(entity) {
    var nbt = entity.getWornChestplate().nbt();
    var getPiece = tag => {
        return nbt.getTagList("Equipment").getCompoundTag(tag).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType");
    }
    var getDamage = tag => {
        return nbt.getTagList("Equipment").getCompoundTag(tag).getCompoundTag("Item").getShort("Damage");
    }
    if (getDamage(0) > 204 || getDamage(1) > 204 || getDamage(2) > 204 || getDamage(3) > 204) {
        return "damaged";
    }
    // Return suit name if all pieces are same and is valid.
    var same = getPiece(0) == getPiece(1) && getPiece(1) == getPiece(2) && getPiece(2) == getPiece(3);
    return (same) ? (valid_suits.indexOf(getPiece(0)) !== -1 ? getPiece(0) : (getPiece(0) == "" ? "" : "incompatible")) : "incomplete";
}

function isKeyBindEnabled(entity, keyBind) {
    var nbt = entity.getWornChestplate().nbt();
    var pick = nbt.getString("Pick");
    var onPistons = isOnPistonGrid(entity);
    switch (keyBind) {
        case "PISTON":
            return !onPistons && pick != "" && pick != "incomplete" && pick != "damaged" && pick != "incompatible" && !entity.getData("sind:dyn/summon");
        case "SUMMON":
            return onPistons && pick != "" && pick != "incomplete" && pick != "damaged" && pick != "incompatible" && !entity.getData("sind:dyn/summon");
        case "REQUEST":
            return pick == "";
        case "INCOMPLETE":
            return pick == "incomplete";
        case "INCOMPATIBLE":
            return pick == "incompatible";
        case "DAMAGED":
            return pick == "damaged";
    }
    for (var i = 0; i < suit_map_keys.length; i++) {
        var suit = suit_map_keys[i];
        if (keyBind == "SUMMON_A_" + suit.toUpperCase()) {
            var choice = pick.split("/")[0].split(":")[1];
            return onPistons && choice == suit && pick != "" && pick != "incomplete" && pick != "damaged" && pick != "incompatible" && !entity.getData("sind:dyn/summon");
        }
    }
    return true;
}
function dontMoveProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}
function getAttributeProfile(entity) {
    return entity.getData("sind:dyn/summon_timer") > 0 ? "DONTMOVE" : null;
}

function printMessage(entity, manager, pick) {
    var choice = pick.split("/")[0].split(":")[1];
    if (PackLoader.getSide() == "SERVER") {
        if (valid_suits.indexOf(pick) !== -1) {
            var name = suit_map[choice][0];
            var os = suit_map[choice][1];
            var message = "";
            var message2 = "";
            if (os == "H") {
                message = encode("HAMMER O.S>", "\u00A72") + encode(" Successfully donned the ", "\u00A7c") + encode(String(name), "\u00A7c") + encode(" Armor", "\u00A7c");
                message2 = encode("HAMMER O.S>", "\u00A72") + encode(" Your suit-up gantry has been stowed away in your equipment slot", "\u00A7c");
            } else {
                message = encode("J.A.R.V.I.S>", "\u00A73") + encode(" Successfully donned the ", "\u00A7b") + encode(String(name), "\u00A7b") + encode(" Armor", "\u00A7b");
                message2 = encode("J.A.R.V.I.S>", "\u00A73") + encode(" Your suit-up gantry has been stowed away in your equipment slot", "\u00A7b");
            }
            if (message != "" && message2 != "") {
                entity.as("PLAYER").addChatMessage(message);
                entity.as("PLAYER").addChatMessage(message2);
            }
        }
    } else if (PackLoader.getSide() == "CLIENT") {
        entity.playSound("minecraft:random.orb", 4, 1);
    }
}

function encode(string, code) {
    var output = "";
    for (var i = 0; i < string.length; i++) {
        output += code + string[i];
    }
    return output;
}

function setEquipmentItem(manager, tagIndex, equipments, equipment, replaceTo) {
    replaceTo = replaceTo == undefined ? equipments : replaceTo;
    var tag = getIndex(equipments, tagIndex);
    if (tag == null) {
        manager.appendTag(equipments, equipment);
        return;
    }
    manager.setCompoundTag(tag, "Item", equipment.getCompoundTag("Item"));
}

function getIndex(nbtList, index) {
    for (var i = 0; i < nbtList.tagCount(); ++i) {
        if (nbtList.getCompoundTag(i).getByte("Index") == index) {
            return nbtList.getCompoundTag(i);
        }
    }
    return null;
}

function addEquipmentItemList(manager, equipments, itemlist) {
    for (var i = 0; i < itemlist.tagCount(); i++) {
        var item = itemlist.getCompoundTag(i);
        manager.appendTag(equipments, item);
    }
}

function isOnPistonGrid(entity) {
    for (var i = -2; i <= 2; i++) {
        for (var j = -2; j <= 2; j++) {
            var block = entity.world().getBlock(entity.pos().add(i, -1, j));
            if (block != "minecraft:piston") {
                return false;
            }
        }
    }
    return true;
}
