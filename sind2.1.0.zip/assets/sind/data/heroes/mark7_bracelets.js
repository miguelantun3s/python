var iron_man = implement("sind:external/iron_man_base");
var jarvis = implement("sind:external/jarvis");
var space = implement("sind:external/spacetp");
var landing = implement("sind:external/superhero_landing");

function init(hero) {
    hero.setName("Iron Man/Mark 07 (VII)");

    hero.addPowers("sind:7aw_visual", "sind:mk7", "sind:jarvis", "sind:bracelets");
    hero.setChestplate("Bracelets");
    hero.setTier(7);
    hero.setTierOverride(getTierOverride);

    hero.addAttributeProfile("INACTIVE", inactiveProfile);
    hero.addAttributeProfile("TRANSFORM", transformProfile);
    hero.addAttributeProfile("DONTMOVE", dontMoveProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");

    hero.addSoundEvent("AIM_START", "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "sind:bracelets_step");

    hero.addKeyBind("MARKSEVEN", "Summon Mark 7 Pod", 1);

    hero.addKeyBind("AIM", "Repulsor Blast", 1);
    hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight-Click \u00A77-\u00A7r Repulsor Blast", 1);
    hero.addKeyBind("CHARGED_BEAM", "Unibeam", 2);
    hero.addKeyBind("SENTRY_MODE", "key.sentryMode", 3);
    hero.addKeyBindFunc("func_MOBSCAN", mobScan, "Mob Scan", 2);
    hero.addKeyBindFunc("func_JARVIS", jarvisKey, "Toggle JARVIS", 5);
    hero.addKeyBind("SCROCKETS", "Fire Shoulder Rockets", 4);
    hero.addKeyBind("HEAT_VISION", "Arm Lasers", 5);
    hero.addKeyBind("DISABLE_PUNCH", "Disable Punch", -1);

    hero.addKeyBind("SPACE", "Toggle Space Mode", 4);

    hero.addDamageProfile("FLARES", {
        "types": {
            "ENERGY": 0.4,
            "EXPLOSION": 0.3,
            "FIRE": 0.3
        },
        "properties": {
            "EFFECTS": [{
                    "id": "fiskheroes:flashbang",
                    "duration": 40,
                    "amplifier": 1
                }, {
                    "id": "minecraft:slowness",
                    "duration": 40,
                    "amplifier": 1
                }
            ]
        }
    });
    hero.setDamageProfile(entity => null);
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);

    hero.addKeyBind("FLARES", "Deploy Flares", 3);
    var rocketArm = iron_man.createRocketArm(hero, 4, 3);

    hero.setTickHandler((entity, manager) => {
        iron_man.tick(entity, manager);
        if (!entity.is("DISPLAY") && entity.is("PLAYER")) {
            //head easing fix below
            manager.incrementData(entity, "sind:dyn/hulkbuster_arm_timer", 10, entity.getData("sind:dyn/summon7_timer") == 1);
            // jarivs
            if (entity.getData("sind:dyn/summon7_timer") == 1) {
                landing.tick(entity, manager);
                jarvis.health(entity, manager, "jarvis");
                jarvis.lowhealth(entity, manager, "jarvis");
                jarvis.heatwarning(entity, manager, "jarvis");
                // fix later jarvis.spacewarning2(entity, manager);
                jarvis.timers(entity, manager);

                iron_man.flares(entity, manager, hero);
                rocketArm.tick(entity, manager);
            }
        }
        //stupid sentry mode code
        var nbt = entity.getWornChestplate().nbt();
        if (entity.getEntityName() == "fiskheroes.IronMan") {
            manager.setByte(nbt, "sentry", 5);
            manager.setData(entity, "sind:dyn/summon7", true);
            manager.setInterpolatedData(entity, "sind:dyn/summon7_timer", 1);
            manager.setInterpolatedData(entity, "sind:dyn/hulkbuster_arm_timer", 1);
        } else if (nbt.getByte("sentry") > 0 && entity.is("PLAYER")) {
            manager.setDataWithNotify(entity, "sind:dyn/summon7", true);
            manager.setDataWithNotify(entity, "sind:dyn/summon", true);
            manager.setDataWithNotify(entity, "sind:dyn/summon7_timer", 1);
            manager.setInterpolatedData(entity, "sind:dyn/hulkbuster_arm_timer", 1);
            manager.setByte(nbt, "sentry", nbt.getByte("sentry") - 1);
        }
        // flight stuff after summon
        if (entity.getData("sind:dyn/summon7_timer") == 0) {
            manager.setData(entity, "sind:dyn/summon", false);
        }
        if (entity.getData("sind:dyn/summon7_timer") == 1 && !entity.getData("sind:dyn/summon") && entity.is("PLAYER")) {
            manager.setData(entity, "sind:dyn/summon", true);
            manager.setByte(nbt, "flight", 5);
        }
        //space mode tp
        if (entity.getData("sind:dyn/space7")) {
            space.teleport(entity, manager);
            if ((entity.getData("sind:dyn/space7_timer") > 0.01) && (entity.getData("sind:dyn/space7_timer") < 0.02)) {
                entity.playSound("minecraft:random.anvil_land", 4, -1);
            }
        }

        if ((entity.getData("sind:dyn/space7_timer") > 0.48) && (entity.getData("sind:dyn/space7_timer") < 0.49) && !entity.getData("sind:dyn/space7")) {
            entity.playSound("minecraft:random.anvil_use", 4, -1);
        }

        //auto flight after transform (5 ticks/chances just in case)
        if (nbt.getByte("flight") > 0 && entity.is("PLAYER")) {
            manager.setByte(nbt, "flight", nbt.getByte("flight") - 1);
            if (!entity.isOnGround()) {
                manager.setData(entity, "fiskheroes:flying", true);
            }
        }
    });
}
function inactiveProfile(profile) {
    profile.revokeAugments();
}
function getAttributeProfile(entity) {
    if (entity.getData("sind:dyn/summon7_timer") < 1) {
        return entity.getData("sind:dyn/summon7_timer") > 0 ? "TRANSFORM" : "INACTIVE";
    }
    return iron_man.getAttributeProfile(entity);
}
function dontMoveProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}
function transformProfile(profile) {
    profile.revokeAugments();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}
function isModifierEnabled(entity, modifier) {
    var beamshooting = entity.getData("fiskheroes:beam_shooting_timer") > 0;
    switch (modifier.id()) {
    case "7":
        return true;
    case "flight_normal":
        return (entity.getData("sind:dyn/summon7_timer") == 1 && !beamshooting) || entity.getEntityName() == "fiskheroes.IronMan";
    case "flight_unibeam":
        return (entity.getData("sind:dyn/summon7_timer") == 1 && beamshooting) || entity.getEntityName() == "fiskheroes.IronMan";
    }
    if (modifier.name() == "fiskheroes:sentry_mode") {
        return true;
    }
    return entity.getData("sind:dyn/summon7_timer") == 1 && iron_man.isModifierEnabled(entity, modifier);
}
function hasProperty(entity, property) {
    return entity.getData("sind:dyn/summon7_timer") == 1 && iron_man.hasProperty(entity, property);
}
function canAim(entity) {
    return entity.getData("sind:dyn/summon7_timer") == 1 && iron_man.canAim(entity);
}
function isKeyBindEnabled(entity, keyBind) {
    var podtimerfinished = entity.getData("sind:dyn/summon7_timer") == 1
        var flying = entity.getData("fiskheroes:flying");
    var canSpaceTransform = ((entity.posY() > 275 && entity.world().getDimension() == 0) || (entity.getData("sind:dyn/space7") && entity.world().getDimension() == 0) || (!entity.getData("sind:dyn/space7") && entity.world().getDimension() == 2595));
    switch (keyBind) {
    case "MARKSEVEN":
        return !entity.getData("sind:dyn/summon7");
    case "SPACE":
        return podtimerfinished && canSpaceTransform;
    case "SENTRY_MODE": 
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && iron_man.isKeyBindEnabled(entity, keyBind);
    case "SCROCKETS":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    case "AROCKET":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    case "VISUAL_AROCKET":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    case "RELOADARMGP":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    case "RELOADARMFC":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    case "RELOADARMTNT":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    case "NORELOADARM":
        return podtimerfinished && entity.getData("sind:dyn/space7_timer") == 0 && !canSpaceTransform && iron_man.isKeyBindEnabled(entity, keyBind);
    default:
        return podtimerfinished && iron_man.isKeyBindEnabled(entity, keyBind);
    }

}
function jarvisKey(player, manager) {
    iron_man.jarvisKey(player, manager);
    return true;
}

function mobScan(entity, manager) {
    iron_man.mobScan(entity, manager, "jarvis");
    return true;
}

function getTierOverride(entity) {
    return entity.getData("sind:dyn/summon7_timer") == 1 ? 7 : 0;
}
