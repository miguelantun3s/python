function init(hero) {
    hero.setName("\u00A74\u00A7lMark 46 \u00A76\u00A7l(XLVI)\u00A7e\u00A7l/\u00A7e\u00A7lBeams -> Sonic Attachment");
    hero.setTier(1);
    hero.setChestplate("Watch");
    hero.addPowers("sind:watch");
    hero.hide()

    hero.addKeyBind("NANITE_TRANSFORM", "Activate Watch", 5);
    hero.addKeyBind("FAKE_AIM", "Sonic Repulsor", 4);
    hero.addKeyBind("SONIC_WAVES", "Sonic Repulsor", 4);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setTickHandler((entity, manager) => {
        var nbt = entity.getWornChestplate().nbt();
        var suitType = entity.getWornChestplate().suitType().split("/")[0];
        var unbreakable = nbt.hasKey("Unbreakable") ? nbt.getBoolean("Unbreakable") : false;
        if (suitType == "sind:mark46_watch" && !unbreakable) {
            manager.setBoolean(nbt, "Unbreakable", true);
        }
    });
}

function isKeyBindEnabled(entity, keyBind) {
    var transform = entity.getData("sind:dyn/nanites") && entity.getData("sind:dyn/nanite_timer") == 1;
    switch (keyBind) {
        case "SONIC_WAVES":
            return transform;
        case "FAKE_AIM":
            return transform;
        default:
            return true;
    }
}