function init(hero) {
    hero.setName("Miscellaneous Heropack");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Power Stone");
}