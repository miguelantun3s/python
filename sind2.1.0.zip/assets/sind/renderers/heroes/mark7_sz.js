extend("sind:mark7");
loadTextures({
    "layer1": "sind:mark7/mark7_sz_layer1.tx.json",
    "layer2": "sind:mark7/mark7_sz_layer2",
    "suit": "sind:mark7/mark7_sz_suit.tx.json",
    "mask": "sind:mark7/mark7_sz_mask.tx.json",
    "chin": "sind:mark7/mark7_sz_chin",
    "rocket": "sind:mark7/mark7_sz_rocket.tx.json",
    "chest": "sind:mark7/mark7_sz_chest",
    "cannons": "sind:mark7/mark7_sz_cannon",
    "flaps": "sind:mark7/mark7_sz_flaps.tx.json",
    "laser": "sind:mark7/mark7_sz_laser",
    "legflap_bottom": "sind:mark7/mark7_sz_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark7/mark7_sz_legflaps_top.tx.json",
});





