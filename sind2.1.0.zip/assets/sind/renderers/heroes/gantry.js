extend("sind:external/hero_basic");
loadTextures({
    "null": "sind:null",

    "holo0": "sind:gantry/holo/0",
    "holo1": "sind:gantry/holo/1",
    "holo2": "sind:gantry/holo/2",
    "holo3": "sind:gantry/holo/3",

    // gantry textures
    "gantry": "sind:gantry/gantry",

    // suit lights
    "reactor": "sind:gantry/lights/reactor",
    "reactor_red": "sind:gantry/lights/reactor_red",
    "reactor_triangle": "sind:gantry/lights/reactor_triangle",
    "eyes": "sind:gantry/lights/eyes",
    "eyes_red": "sind:gantry/lights/eyes_red",
    "reactor_wm1": "sind:gantry/lights/reactor_wm1",
    "eyes_wm1": "sind:gantry/lights/eyes_wm1",

    // suits
    "mark2": "sind:gantry/suits/mark2", 
    "mark3": "sind:gantry/suits/mark3",
    "mark4": "sind:gantry/suits/mark4",
    "mark6": "sind:gantry/suits/mark6",
    "warmachine_mk1": "sind:gantry/suits/warmachine_mk1",

    //alts
    "mark3/stealth": "sind:gantry/suits/mark3_stealth",
    "mark3/gm": "sind:gantry/suits/mark3_gm",
    "mark3/gold": "sind:gantry/suits/mark3_gold",
    "mark3/rc": "sind:gantry/suits/mark3_rc",

    "mark4/sp": "sind:gantry/suits/mark4_sp",
    "mark4/v2": "sind:gantry/suits/mark4_v2",
    "mark6/sc": "sind:gantry/suits/mark6_sc",
    "mark6/v2": "sind:gantry/suits/mark6_v2",

    "warmachine_mk1/r": "sind:gantry/suits/warmachine_mk1_r",
    "warmachine_mk1/mm": "sind:gantry/suits/warmachine_mk1_mm",

    //wm1 models
    "warmachine_mk1_models": "sind:gantry/suits/warmachine_mk1_models",
    "warmachine_mk1/r_models": "sind:gantry/suits/warmachine_mk1_r_models",
    "warmachine_mk1/mm_models": "sind:gantry/suits/warmachine_mk1_mm_models",
});
var utils = implement("fiskheroes:external/utils");
var overlay0, overlay1, overlay2, overlay3;
var gantry;
var suitModel, suit, reactorModel, reactor, eyesModel, eyes, wm1Model, wm1;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return "null";
    });
}

function initEffects(renderer){
    overlay0 = renderer.createEffect("fiskheroes:overlay");
    overlay0.texture.set(null, "holo0");
    overlay1 = renderer.createEffect("fiskheroes:overlay");
    overlay1.texture.set(null, "holo1");
    overlay2 = renderer.createEffect("fiskheroes:overlay");
    overlay2.texture.set(null, "holo2");
    overlay3 = renderer.createEffect("fiskheroes:overlay");
    overlay3.texture.set(null, "holo3");
    overlay0.opacity = overlay1.opacity = overlay2.opacity = overlay3.opacity = 0.5;

    var gantryModel = createModel(renderer, "sind:gantry/gantry");
    gantryModel.texture.set("gantry");
    gantry = createEffect(renderer, gantryModel);

    suitModel = createModel(renderer, "sind:gantry/suit");
    suit = createEffect(renderer, suitModel);

    wm1Model = createModel(renderer, "sind:gantry/wm1");
    wm1 = createEffect(renderer, wm1Model);

    reactorModel = createModel(renderer, "sind:gantry/suit");
    reactor = createEffect(renderer, reactorModel);

    eyesModel = createModel(renderer, "sind:gantry/suit");
    eyes = createEffect(renderer, eyesModel);
}

function initAnimations(renderer){
    addAnimation(renderer, "cancel", "sind:cancel").setData((entity, data) => {
        var t = entity.getInterpolatedData("sind:dyn/summon_timer");
        data.load(Math.min(1, 20*t));
    }).priority = -11;
    addAnimation(renderer, "gantry", "sind:gantry").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    }).priority = 14;
    addAnimationWithData(renderer, "tony_suit", "sind:cancel", "sind:dyn/tony_to_suit").priority = -11;
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (entity.is("DISPLAY")) {
        if (renderLayer == "HELMET") {
            overlay0.render();
        } else if (renderLayer == "CHESTPLATE") {
            overlay1.render();
        } else if (renderLayer == "LEGGINGS") {
            overlay2.render();
        } else if (renderLayer == "BOOTS") {
            overlay3.render();
        }
    } else {
        if (entity.getData("sind:dyn/summon_timer") > 0) {
            var nbt = entity.getWornChestplate().nbt();
            var pick = nbt.getString("Pick").split("sind:")[1];
            var mk6 = pick == "mark6" || pick == "mark6/v2" || pick == "mark6/sc";
            var isWm1 = pick == "warmachine_mk1";
            var isWm1r = pick == "warmachine_mk1/r" || pick == "warmachine_mk1/mm";
            var red_lights = pick == "mark3/stealth" || isWm1r;
            
            var eq = Math.min(1, clamp(1000/75 * entity.getInterpolatedData("sind:dyn/summon_timer"), 0, 1), clamp(-1000/75 * (entity.getInterpolatedData("sind:dyn/summon_timer") - 1), 0, 1));

            if (isFirstPersonArm) {
                gantry.anchor.set("rightArm");
                gantry.setOffset(0, 4 + (5 * eq), 4);
                suit.anchor.set("rightArm");
                suit.setOffset(0, 4 + (5 * eq), 4);
                reactor.anchor.set("rightArm");
                reactor.setOffset(0, 4 + (5 * eq), 4);
                eyes.anchor.set("rightArm");
                eyes.setOffset(0, 4 + (5 * eq), 4);
                wm1.anchor.set("rightArm");
                wm1.setOffset(0, 4 + (5 * eq), 4);
            } else{
                gantry.anchor.set("body");
                gantry.setOffset(0, 0, 0);
                suit.anchor.set("body");
                suit.setOffset(0, 0, 0);
                reactor.anchor.set("body");
                reactor.setOffset(0, 0, 0);
                eyes.anchor.set("body");
                eyes.setOffset(0, 0, 0);
                wm1.anchor.set("body");
                wm1.setOffset(0, 0, 0);
            }
            gantry.render();
            suitModel.texture.set(pick);
            suit.render();

            if (isWm1 || isWm1r) {
                wm1Model.texture.set(pick + "_models");
                wm1.render();
            }

            if (entity.getData("sind:dyn/summon_timer") > 0.685) {
                var reactortexture = red_lights ? "reactor_red" : 
                    mk6 ? "reactor_triangle" : 
                        isWm1 ? "reactor_wm1" :
                            "reactor";
                reactorModel.texture.set(null, reactortexture);
                reactor.render();
            }
            if (entity.getData("sind:dyn/summon_timer") > 0.9) {
                var eyestexture = red_lights ? "eyes_red" : 
                    isWm1 ? "eyes_wm1" :
                        "eyes";
                eyesModel.texture.set(null, eyestexture);
                eyes.render();
            }
        }
    }
}
// helpers
function createModel(renderer, modelPath){
    var model = renderer.createResource("MODEL", modelPath);
    model.bindAnimation("sind:gantry").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    return model;
}
function createEffect(renderer, modelPointer){
    var effect = renderer.createEffect("fiskheroes:model").setModel(modelPointer);
    // possibly change anchor points later
    effect.anchor.set("body");
    effect.anchor.ignoreAnchor(true);
    return effect;
}

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}