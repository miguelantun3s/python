extend("sind:warmachine_mk5");
loadTextures({
    "layer1": "sind:wm5_r/wm_layer1",
    "layer2": "sind:wm5_r/wm_layer2",
    "lights_layer1": "sind:wm5_r/wm_lights_layer1",
    "lights_layer2": "sind:wm5_r/wm_lights_layer2",
    "lights_suit": "sind:wm5_r/wm_lights.tx.json",
    "suit": "sind:wm5_r/wm_suit.tx.json",
    "mask": "sind:wm5_r/wm_helmet.tx.json",
    "mask_lights": "sind:wm5_r/wm_helmet_lights.tx.json",
    "armgun": "sind:wm5_r/wm_armgun.tx.json",
    "chest": "sind:wm5_r/wm_chest.tx.json",
    "chest_lights": "sind:wm5_r/wm_chest_lights",
});