extend("sind:external/advanced_lasers");
loadTextures({
    "layer1": "sind:mark14/mark14_layer1",
    "layer2": "sind:mark14/mark14_layer2",
    "suit": "sind:mark14/mark14_suit.tx.json",
    "mask": "sind:mark14/mark14_mask.tx.json",
    "chin": "sind:null",
    "rocket": "sind:null",
    "chest": "sind:mark14/mark14_chest",
    "cannons": "sind:mark13/mark13_cannon",
    "flaps": "sind:mark14/mark14_flaps.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark14/full",
    "player_mh": "sind:hud/mark14/mh",
    "player0": "sind:hud/mark25/0",
    "player1": "sind:hud/mark14/1",
    "player2": "sind:hud/mark14/2",
    "player3": "sind:hud/mark25/3"
});

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimationWithData(renderer, "clamping", "sind:feetlock", "sind:dyn/clamp_timer")
        .priority = -7;
}