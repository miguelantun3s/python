extend("sind:external/advanced_lasers");
loadTextures({
    "layer1": "sind:mark7/mark7_layer1.tx.json",
    "layer2": "sind:mark7/mark7_layer2",
    "suit": "sind:mark7/mark7_suit.tx.json",
    "mask": "sind:mark3/mark3_mask.tx.json",
    "chin": "sind:mark4/mark4_chin",
    "rocket": "sind:mark7/mark7_rocket.tx.json",
    "chest": "sind:mark7/mark7_chest",
    "cannons": "sind:mark7/mark7_cannon",
    "flaps": "sind:mark7/mark7_flaps.tx.json",
    "laser": "sind:mark7/mark7_laser",
    "legflap_bottom": "sind:mark7/mark7_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark7/mark7_legflaps_top.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark7/full",
    "player_mh": "sind:hud/mark7/mh",
    "player1": "sind:hud/mark7/1",
    "player2": "sind:hud/mark7/2",
    "player3": "sind:hud/mark7/3",
});




