extend("sind:mark42");
loadTextures({
    "layer1": "sind:mark42/mark42_sdca_layer1",
    "layer2": "sind:mark42/mark42_sdca_layer2",
    "whole": "sind:mark42/mark42_sdca_complete",
    "rocket": "sind:mark42/mark42_sdca_rocket.tx.json",

    "split": "sind:mark42/mark42_sdca",
    "suit": "sind:mark42/mark42_sdca_suit.tx.json",

    "right": "sind:mark42/mark42_sdca_ov1",
    "left": "sind:mark42/mark42_sdca_ov2",
    "booty": "sind:mark42/mark42_sdca_ov3",

    "flaps": "sind:mark42/mark42_sdca_flaps.tx.json",
});