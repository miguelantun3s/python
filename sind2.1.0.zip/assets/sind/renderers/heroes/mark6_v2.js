extend("sind:mark6");
loadTextures({
    "layer1": "sind:mark6/mark6v2_layer1.tx.json",
    "layer2": "sind:mark4/mark4_layer2",
    "rocket": "sind:mark4/mark4_rocket",
    "layer1gauntlet": "sind:mark6/mark6v2_layer1_gauntlet.tx.json",
});
