extend("sind:mark7");
loadTextures({
    "layer1": "sind:mark7/mark7_d100_layer1.tx.json",
    "layer2": "sind:mark7/mark7_d100_layer2",
    "suit": "sind:mark7/mark7_d100_suit.tx.json",
    "mask": "sind:mark2/mark2_mask.tx.json",
    "chin": "sind:mark5/mark5_chin",
    "chest": "sind:mark7/mark7_d100_chest",
    "flaps": "sind:mark7/mark7_d100_flaps.tx.json",
    "legflap_top": "sind:mark7/mark7_d100_legflaps_top.tx.json",
});





