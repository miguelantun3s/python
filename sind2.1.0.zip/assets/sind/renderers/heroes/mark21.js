extend("sind:mark7");
loadTextures({
    "layer1": "sind:mark21/mark21_layer1.tx.json",
    "layer2": "sind:mark21/mark21_layer2",
    "suit": "sind:mark21/mark21_suit.tx.json",
    "mask": "sind:mark21/mark21_mask.tx.json",
    "chin": "sind:mark21/mark21_chin",
    "rocket": "sind:mark21/mark21_rocket.tx.json",
    "chest": "sind:mark21/mark21_chest",
    "cannons": "sind:mark21/mark21_cannon",
    "flaps": "sind:mark21/mark21_flaps.tx.json",
    "laser": "sind:mark21/mark21_laser",
    "legflap_bottom": "sind:mark21/mark21_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark21/mark21_legflaps_top.tx.json",
});
function range(){
    return 20;
}
