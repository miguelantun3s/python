extend("sind:mark32");
loadTextures({
    "mask": "sind:mark32/mark32_zd_mask.tx.json",
});