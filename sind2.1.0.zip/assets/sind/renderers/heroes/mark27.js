//EVIL LOAD TEXTURES CALL INCOMING
extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark27/mark27_layer1",
    "layer2": "sind:mark27/mark27_layer2",
    "suit": "sind:mark27/mark27_suit.tx.json",
    "chest": "sind:mark27/mark27_chest",
    "mask": "sind:mark27/mark27_mask.tx.json",
    "cannon": "sind:mark27/mark27_cannon",
    "flaps": "sind:mark27/mark27_flaps.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark12/full",
    "player_mh": "sind:hud/mark12/mh",
    "player0": "sind:hud/wm2/0",
    "player1": "sind:hud/mark12/1",
    "player2": "sind:hud/mark12/2",
    "player3": "sind:hud/mark40/3",

    "h_cannons": "sind:hud/mark7/cannon",
    "h_cannons1": "sind:hud/mark7/w_cannon",
    "h_cannons_mh": "sind:hud/mark7/mh_cannon",
    "h_bulkchest": "sind:hud/mark7/chest",
    "h_bulkchest1": "sind:hud/mark7/w_chest",
    "h_bulkchest_mh": "sind:hud/mark7/mh_chest",
    
    "bedrock_suit": "sind:mark27/camos/bedrock_suit.tx.json", "bedrock_chest": "sind:mark27/camos/bedrock_chest.tx.json", "bedrock_cannon": "sind:mark27/camos/bedrock_cannon.tx.json", "bedrock_flaps": "sind:mark27/camos/bedrock_flaps.tx.json",
    "brick_suit": "sind:mark27/camos/brick_suit.tx.json", "brick_chest": "sind:mark27/camos/brick_chest.tx.json", "brick_cannon": "sind:mark27/camos/brick_cannon.tx.json", "brick_flaps": "sind:mark27/camos/brick_flaps.tx.json",
    "clay_suit": "sind:mark27/camos/clay_suit.tx.json", "clay_chest": "sind:mark27/camos/clay_chest.tx.json", "clay_cannon": "sind:mark27/camos/clay_cannon.tx.json", "clay_flaps": "sind:mark27/camos/clay_flaps.tx.json",
    "coal_block_suit": "sind:mark27/camos/coal_block_suit.tx.json", "coal_block_chest": "sind:mark27/camos/coal_block_chest.tx.json", "coal_block_cannon": "sind:mark27/camos/coal_block_cannon.tx.json", "coal_block_flaps": "sind:mark27/camos/coal_block_flaps.tx.json",
    "coal_ore_suit": "sind:mark27/camos/coal_ore_suit.tx.json", "coal_ore_chest": "sind:mark27/camos/coal_ore_chest.tx.json", "coal_ore_cannon": "sind:mark27/camos/coal_ore_cannon.tx.json", "coal_ore_flaps": "sind:mark27/camos/coal_ore_flaps.tx.json",
    "cobblestone_suit": "sind:mark27/camos/cobblestone_suit.tx.json", "cobblestone_chest": "sind:mark27/camos/cobblestone_chest.tx.json", "cobblestone_cannon": "sind:mark27/camos/cobblestone_cannon.tx.json", "cobblestone_flaps": "sind:mark27/camos/cobblestone_flaps.tx.json",
    "cobblestone_mossy_suit": "sind:mark27/camos/cobblestone_mossy_suit.tx.json", "cobblestone_mossy_chest": "sind:mark27/camos/cobblestone_mossy_chest.tx.json", "cobblestone_mossy_cannon": "sind:mark27/camos/cobblestone_mossy_cannon.tx.json", "cobblestone_mossy_flaps": "sind:mark27/camos/cobblestone_mossy_flaps.tx.json",
    "diamond_block_suit": "sind:mark27/camos/diamond_block_suit.tx.json", "diamond_block_chest": "sind:mark27/camos/diamond_block_chest.tx.json", "diamond_block_cannon": "sind:mark27/camos/diamond_block_cannon.tx.json", "diamond_block_flaps": "sind:mark27/camos/diamond_block_flaps.tx.json",
    "diamond_ore_suit": "sind:mark27/camos/diamond_ore_suit.tx.json", "diamond_ore_chest": "sind:mark27/camos/diamond_ore_chest.tx.json", "diamond_ore_cannon": "sind:mark27/camos/diamond_ore_cannon.tx.json", "diamond_ore_flaps": "sind:mark27/camos/diamond_ore_flaps.tx.json",
    "dirt_suit": "sind:mark27/camos/dirt_suit.tx.json", "dirt_chest": "sind:mark27/camos/dirt_chest.tx.json", "dirt_cannon": "sind:mark27/camos/dirt_cannon.tx.json", "dirt_flaps": "sind:mark27/camos/dirt_flaps.tx.json",
    "dirt_podzol_top_suit": "sind:mark27/camos/dirt_podzol_top_suit.tx.json", "dirt_podzol_top_chest": "sind:mark27/camos/dirt_podzol_top_chest.tx.json", "dirt_podzol_top_cannon": "sind:mark27/camos/dirt_podzol_top_cannon.tx.json", "dirt_podzol_top_flaps": "sind:mark27/camos/dirt_podzol_top_flaps.tx.json",
    "emerald_block_suit": "sind:mark27/camos/emerald_block_suit.tx.json", "emerald_block_chest": "sind:mark27/camos/emerald_block_chest.tx.json", "emerald_block_cannon": "sind:mark27/camos/emerald_block_cannon.tx.json", "emerald_block_flaps": "sind:mark27/camos/emerald_block_flaps.tx.json",
    "emerald_ore_suit": "sind:mark27/camos/emerald_ore_suit.tx.json", "emerald_ore_chest": "sind:mark27/camos/emerald_ore_chest.tx.json", "emerald_ore_cannon": "sind:mark27/camos/emerald_ore_cannon.tx.json", "emerald_ore_flaps": "sind:mark27/camos/emerald_ore_flaps.tx.json",
    "end_stone_suit": "sind:mark27/camos/end_stone_suit.tx.json", "end_stone_chest": "sind:mark27/camos/end_stone_chest.tx.json", "end_stone_cannon": "sind:mark27/camos/end_stone_cannon.tx.json", "end_stone_flaps": "sind:mark27/camos/end_stone_flaps.tx.json",
    "glowstone_suit": "sind:mark27/camos/glowstone_suit.tx.json", "glowstone_chest": "sind:mark27/camos/glowstone_chest.tx.json", "glowstone_cannon": "sind:mark27/camos/glowstone_cannon.tx.json", "glowstone_flaps": "sind:mark27/camos/glowstone_flaps.tx.json",
    "gold_block_suit": "sind:mark27/camos/gold_block_suit.tx.json", "gold_block_chest": "sind:mark27/camos/gold_block_chest.tx.json", "gold_block_cannon": "sind:mark27/camos/gold_block_cannon.tx.json", "gold_block_flaps": "sind:mark27/camos/gold_block_flaps.tx.json",
    "gold_ore_suit": "sind:mark27/camos/gold_ore_suit.tx.json", "gold_ore_chest": "sind:mark27/camos/gold_ore_chest.tx.json", "gold_ore_cannon": "sind:mark27/camos/gold_ore_cannon.tx.json", "gold_ore_flaps": "sind:mark27/camos/gold_ore_flaps.tx.json",
    "gravel_suit": "sind:mark27/camos/gravel_suit.tx.json", "gravel_chest": "sind:mark27/camos/gravel_chest.tx.json", "gravel_cannon": "sind:mark27/camos/gravel_cannon.tx.json", "gravel_flaps": "sind:mark27/camos/gravel_flaps.tx.json",
    "hardened_clay_suit": "sind:mark27/camos/hardened_clay_suit.tx.json", "hardened_clay_chest": "sind:mark27/camos/hardened_clay_chest.tx.json", "hardened_clay_cannon": "sind:mark27/camos/hardened_clay_cannon.tx.json", "hardened_clay_flaps": "sind:mark27/camos/hardened_clay_flaps.tx.json",
    "hardened_clay_stained_black_suit": "sind:mark27/camos/hardened_clay_stained_black_suit.tx.json", "hardened_clay_stained_black_chest": "sind:mark27/camos/hardened_clay_stained_black_chest.tx.json", "hardened_clay_stained_black_cannon": "sind:mark27/camos/hardened_clay_stained_black_cannon.tx.json", "hardened_clay_stained_black_flaps": "sind:mark27/camos/hardened_clay_stained_black_flaps.tx.json",
    "hardened_clay_stained_blue_suit": "sind:mark27/camos/hardened_clay_stained_blue_suit.tx.json", "hardened_clay_stained_blue_chest": "sind:mark27/camos/hardened_clay_stained_blue_chest.tx.json", "hardened_clay_stained_blue_cannon": "sind:mark27/camos/hardened_clay_stained_blue_cannon.tx.json", "hardened_clay_stained_blue_flaps": "sind:mark27/camos/hardened_clay_stained_blue_flaps.tx.json",
    "hardened_clay_stained_brown_suit": "sind:mark27/camos/hardened_clay_stained_brown_suit.tx.json", "hardened_clay_stained_brown_chest": "sind:mark27/camos/hardened_clay_stained_brown_chest.tx.json", "hardened_clay_stained_brown_cannon": "sind:mark27/camos/hardened_clay_stained_brown_cannon.tx.json", "hardened_clay_stained_brown_flaps": "sind:mark27/camos/hardened_clay_stained_brown_flaps.tx.json",
    "hardened_clay_stained_cyan_suit": "sind:mark27/camos/hardened_clay_stained_cyan_suit.tx.json", "hardened_clay_stained_cyan_chest": "sind:mark27/camos/hardened_clay_stained_cyan_chest.tx.json", "hardened_clay_stained_cyan_cannon": "sind:mark27/camos/hardened_clay_stained_cyan_cannon.tx.json", "hardened_clay_stained_cyan_flaps": "sind:mark27/camos/hardened_clay_stained_cyan_flaps.tx.json",
    "hardened_clay_stained_gray_suit": "sind:mark27/camos/hardened_clay_stained_gray_suit.tx.json", "hardened_clay_stained_gray_chest": "sind:mark27/camos/hardened_clay_stained_gray_chest.tx.json", "hardened_clay_stained_gray_cannon": "sind:mark27/camos/hardened_clay_stained_gray_cannon.tx.json", "hardened_clay_stained_gray_flaps": "sind:mark27/camos/hardened_clay_stained_gray_flaps.tx.json",
    "hardened_clay_stained_green_suit": "sind:mark27/camos/hardened_clay_stained_green_suit.tx.json", "hardened_clay_stained_green_chest": "sind:mark27/camos/hardened_clay_stained_green_chest.tx.json", "hardened_clay_stained_green_cannon": "sind:mark27/camos/hardened_clay_stained_green_cannon.tx.json", "hardened_clay_stained_green_flaps": "sind:mark27/camos/hardened_clay_stained_green_flaps.tx.json",
    "hardened_clay_stained_light_blue_suit": "sind:mark27/camos/hardened_clay_stained_light_blue_suit.tx.json", "hardened_clay_stained_light_blue_chest": "sind:mark27/camos/hardened_clay_stained_light_blue_chest.tx.json", "hardened_clay_stained_light_blue_cannon": "sind:mark27/camos/hardened_clay_stained_light_blue_cannon.tx.json", "hardened_clay_stained_light_blue_flaps": "sind:mark27/camos/hardened_clay_stained_light_blue_flaps.tx.json",
    "hardened_clay_stained_lime_suit": "sind:mark27/camos/hardened_clay_stained_lime_suit.tx.json", "hardened_clay_stained_lime_chest": "sind:mark27/camos/hardened_clay_stained_lime_chest.tx.json", "hardened_clay_stained_lime_cannon": "sind:mark27/camos/hardened_clay_stained_lime_cannon.tx.json", "hardened_clay_stained_lime_flaps": "sind:mark27/camos/hardened_clay_stained_lime_flaps.tx.json",
    "hardened_clay_stained_magenta_suit": "sind:mark27/camos/hardened_clay_stained_magenta_suit.tx.json", "hardened_clay_stained_magenta_chest": "sind:mark27/camos/hardened_clay_stained_magenta_chest.tx.json", "hardened_clay_stained_magenta_cannon": "sind:mark27/camos/hardened_clay_stained_magenta_cannon.tx.json", "hardened_clay_stained_magenta_flaps": "sind:mark27/camos/hardened_clay_stained_magenta_flaps.tx.json",
    "hardened_clay_stained_orange_suit": "sind:mark27/camos/hardened_clay_stained_orange_suit.tx.json", "hardened_clay_stained_orange_chest": "sind:mark27/camos/hardened_clay_stained_orange_chest.tx.json", "hardened_clay_stained_orange_cannon": "sind:mark27/camos/hardened_clay_stained_orange_cannon.tx.json", "hardened_clay_stained_orange_flaps": "sind:mark27/camos/hardened_clay_stained_orange_flaps.tx.json",
    "hardened_clay_stained_pink_suit": "sind:mark27/camos/hardened_clay_stained_pink_suit.tx.json", "hardened_clay_stained_pink_chest": "sind:mark27/camos/hardened_clay_stained_pink_chest.tx.json", "hardened_clay_stained_pink_cannon": "sind:mark27/camos/hardened_clay_stained_pink_cannon.tx.json", "hardened_clay_stained_pink_flaps": "sind:mark27/camos/hardened_clay_stained_pink_flaps.tx.json",
    "hardened_clay_stained_purple_suit": "sind:mark27/camos/hardened_clay_stained_purple_suit.tx.json", "hardened_clay_stained_purple_chest": "sind:mark27/camos/hardened_clay_stained_purple_chest.tx.json", "hardened_clay_stained_purple_cannon": "sind:mark27/camos/hardened_clay_stained_purple_cannon.tx.json", "hardened_clay_stained_purple_flaps": "sind:mark27/camos/hardened_clay_stained_purple_flaps.tx.json",
    "hardened_clay_stained_red_suit": "sind:mark27/camos/hardened_clay_stained_red_suit.tx.json", "hardened_clay_stained_red_chest": "sind:mark27/camos/hardened_clay_stained_red_chest.tx.json", "hardened_clay_stained_red_cannon": "sind:mark27/camos/hardened_clay_stained_red_cannon.tx.json", "hardened_clay_stained_red_flaps": "sind:mark27/camos/hardened_clay_stained_red_flaps.tx.json",
    "hardened_clay_stained_silver_suit": "sind:mark27/camos/hardened_clay_stained_silver_suit.tx.json", "hardened_clay_stained_silver_chest": "sind:mark27/camos/hardened_clay_stained_silver_chest.tx.json", "hardened_clay_stained_silver_cannon": "sind:mark27/camos/hardened_clay_stained_silver_cannon.tx.json", "hardened_clay_stained_silver_flaps": "sind:mark27/camos/hardened_clay_stained_silver_flaps.tx.json",
    "hardened_clay_stained_white_suit": "sind:mark27/camos/hardened_clay_stained_white_suit.tx.json", "hardened_clay_stained_white_chest": "sind:mark27/camos/hardened_clay_stained_white_chest.tx.json", "hardened_clay_stained_white_cannon": "sind:mark27/camos/hardened_clay_stained_white_cannon.tx.json", "hardened_clay_stained_white_flaps": "sind:mark27/camos/hardened_clay_stained_white_flaps.tx.json",
    "hardened_clay_stained_yellow_suit": "sind:mark27/camos/hardened_clay_stained_yellow_suit.tx.json", "hardened_clay_stained_yellow_chest": "sind:mark27/camos/hardened_clay_stained_yellow_chest.tx.json", "hardened_clay_stained_yellow_cannon": "sind:mark27/camos/hardened_clay_stained_yellow_cannon.tx.json", "hardened_clay_stained_yellow_flaps": "sind:mark27/camos/hardened_clay_stained_yellow_flaps.tx.json",
    "ice_packed_suit": "sind:mark27/camos/ice_packed_suit.tx.json", "ice_packed_chest": "sind:mark27/camos/ice_packed_chest.tx.json", "ice_packed_cannon": "sind:mark27/camos/ice_packed_cannon.tx.json", "ice_packed_flaps": "sind:mark27/camos/ice_packed_flaps.tx.json",
    "iron_block_suit": "sind:mark27/camos/iron_block_suit.tx.json", "iron_block_chest": "sind:mark27/camos/iron_block_chest.tx.json", "iron_block_cannon": "sind:mark27/camos/iron_block_cannon.tx.json", "iron_block_flaps": "sind:mark27/camos/iron_block_flaps.tx.json",
    "iron_ore_suit": "sind:mark27/camos/iron_ore_suit.tx.json", "iron_ore_chest": "sind:mark27/camos/iron_ore_chest.tx.json", "iron_ore_cannon": "sind:mark27/camos/iron_ore_cannon.tx.json", "iron_ore_flaps": "sind:mark27/camos/iron_ore_flaps.tx.json",
    "lapis_block_suit": "sind:mark27/camos/lapis_block_suit.tx.json", "lapis_block_chest": "sind:mark27/camos/lapis_block_chest.tx.json", "lapis_block_cannon": "sind:mark27/camos/lapis_block_cannon.tx.json", "lapis_block_flaps": "sind:mark27/camos/lapis_block_flaps.tx.json",
    "lapis_ore_suit": "sind:mark27/camos/lapis_ore_suit.tx.json", "lapis_ore_chest": "sind:mark27/camos/lapis_ore_chest.tx.json", "lapis_ore_cannon": "sind:mark27/camos/lapis_ore_cannon.tx.json", "lapis_ore_flaps": "sind:mark27/camos/lapis_ore_flaps.tx.json",
    "log_acacia_suit": "sind:mark27/camos/log_acacia_suit.tx.json", "log_acacia_chest": "sind:mark27/camos/log_acacia_chest.tx.json", "log_acacia_cannon": "sind:mark27/camos/log_acacia_cannon.tx.json", "log_acacia_flaps": "sind:mark27/camos/log_acacia_flaps.tx.json",
    "log_big_oak_suit": "sind:mark27/camos/log_big_oak_suit.tx.json", "log_big_oak_chest": "sind:mark27/camos/log_big_oak_chest.tx.json", "log_big_oak_cannon": "sind:mark27/camos/log_big_oak_cannon.tx.json", "log_big_oak_flaps": "sind:mark27/camos/log_big_oak_flaps.tx.json",
    "log_birch_suit": "sind:mark27/camos/log_birch_suit.tx.json", "log_birch_chest": "sind:mark27/camos/log_birch_chest.tx.json", "log_birch_cannon": "sind:mark27/camos/log_birch_cannon.tx.json", "log_birch_flaps": "sind:mark27/camos/log_birch_flaps.tx.json",
    "log_jungle_suit": "sind:mark27/camos/log_jungle_suit.tx.json", "log_jungle_chest": "sind:mark27/camos/log_jungle_chest.tx.json", "log_jungle_cannon": "sind:mark27/camos/log_jungle_cannon.tx.json", "log_jungle_flaps": "sind:mark27/camos/log_jungle_flaps.tx.json",
    "log_oak_suit": "sind:mark27/camos/log_oak_suit.tx.json", "log_oak_chest": "sind:mark27/camos/log_oak_chest.tx.json", "log_oak_cannon": "sind:mark27/camos/log_oak_cannon.tx.json", "log_oak_flaps": "sind:mark27/camos/log_oak_flaps.tx.json",
    "log_spruce_suit": "sind:mark27/camos/log_spruce_suit.tx.json", "log_spruce_chest": "sind:mark27/camos/log_spruce_chest.tx.json", "log_spruce_cannon": "sind:mark27/camos/log_spruce_cannon.tx.json", "log_spruce_flaps": "sind:mark27/camos/log_spruce_flaps.tx.json",
    "melon_side_suit": "sind:mark27/camos/melon_side_suit.tx.json", "melon_side_chest": "sind:mark27/camos/melon_side_chest.tx.json", "melon_side_cannon": "sind:mark27/camos/melon_side_cannon.tx.json", "melon_side_flaps": "sind:mark27/camos/melon_side_flaps.tx.json",
    "mushroom_block_skin_brown_suit": "sind:mark27/camos/mushroom_block_skin_brown_suit.tx.json", "mushroom_block_skin_brown_chest": "sind:mark27/camos/mushroom_block_skin_brown_chest.tx.json", "mushroom_block_skin_brown_cannon": "sind:mark27/camos/mushroom_block_skin_brown_cannon.tx.json", "mushroom_block_skin_brown_flaps": "sind:mark27/camos/mushroom_block_skin_brown_flaps.tx.json",
    "mushroom_block_skin_red_suit": "sind:mark27/camos/mushroom_block_skin_red_suit.tx.json", "mushroom_block_skin_red_chest": "sind:mark27/camos/mushroom_block_skin_red_chest.tx.json", "mushroom_block_skin_red_cannon": "sind:mark27/camos/mushroom_block_skin_red_cannon.tx.json", "mushroom_block_skin_red_flaps": "sind:mark27/camos/mushroom_block_skin_red_flaps.tx.json",
    "mushroom_block_skin_stem_suit": "sind:mark27/camos/mushroom_block_skin_stem_suit.tx.json", "mushroom_block_skin_stem_chest": "sind:mark27/camos/mushroom_block_skin_stem_chest.tx.json", "mushroom_block_skin_stem_cannon": "sind:mark27/camos/mushroom_block_skin_stem_cannon.tx.json", "mushroom_block_skin_stem_flaps": "sind:mark27/camos/mushroom_block_skin_stem_flaps.tx.json",
    "mycelium_top_suit": "sind:mark27/camos/mycelium_top_suit.tx.json", "mycelium_top_chest": "sind:mark27/camos/mycelium_top_chest.tx.json", "mycelium_top_cannon": "sind:mark27/camos/mycelium_top_cannon.tx.json", "mycelium_top_flaps": "sind:mark27/camos/mycelium_top_flaps.tx.json",
    "nether_brick_suit": "sind:mark27/camos/nether_brick_suit.tx.json", "nether_brick_chest": "sind:mark27/camos/nether_brick_chest.tx.json", "nether_brick_cannon": "sind:mark27/camos/nether_brick_cannon.tx.json", "nether_brick_flaps": "sind:mark27/camos/nether_brick_flaps.tx.json",
    "netherrack_suit": "sind:mark27/camos/netherrack_suit.tx.json", "netherrack_chest": "sind:mark27/camos/netherrack_chest.tx.json", "netherrack_cannon": "sind:mark27/camos/netherrack_cannon.tx.json", "netherrack_flaps": "sind:mark27/camos/netherrack_flaps.tx.json",
    "obsidian_suit": "sind:mark27/camos/obsidian_suit.tx.json", "obsidian_chest": "sind:mark27/camos/obsidian_chest.tx.json", "obsidian_cannon": "sind:mark27/camos/obsidian_cannon.tx.json", "obsidian_flaps": "sind:mark27/camos/obsidian_flaps.tx.json",
    "planks_acacia_suit": "sind:mark27/camos/planks_acacia_suit.tx.json", "planks_acacia_chest": "sind:mark27/camos/planks_acacia_chest.tx.json", "planks_acacia_cannon": "sind:mark27/camos/planks_acacia_cannon.tx.json", "planks_acacia_flaps": "sind:mark27/camos/planks_acacia_flaps.tx.json",
    "planks_big_oak_suit": "sind:mark27/camos/planks_big_oak_suit.tx.json", "planks_big_oak_chest": "sind:mark27/camos/planks_big_oak_chest.tx.json", "planks_big_oak_cannon": "sind:mark27/camos/planks_big_oak_cannon.tx.json", "planks_big_oak_flaps": "sind:mark27/camos/planks_big_oak_flaps.tx.json",
    "planks_birch_suit": "sind:mark27/camos/planks_birch_suit.tx.json", "planks_birch_chest": "sind:mark27/camos/planks_birch_chest.tx.json", "planks_birch_cannon": "sind:mark27/camos/planks_birch_cannon.tx.json", "planks_birch_flaps": "sind:mark27/camos/planks_birch_flaps.tx.json",
    "planks_jungle_suit": "sind:mark27/camos/planks_jungle_suit.tx.json", "planks_jungle_chest": "sind:mark27/camos/planks_jungle_chest.tx.json", "planks_jungle_cannon": "sind:mark27/camos/planks_jungle_cannon.tx.json", "planks_jungle_flaps": "sind:mark27/camos/planks_jungle_flaps.tx.json",
    "planks_oak_suit": "sind:mark27/camos/planks_oak_suit.tx.json", "planks_oak_chest": "sind:mark27/camos/planks_oak_chest.tx.json", "planks_oak_cannon": "sind:mark27/camos/planks_oak_cannon.tx.json", "planks_oak_flaps": "sind:mark27/camos/planks_oak_flaps.tx.json",
    "planks_spruce_suit": "sind:mark27/camos/planks_spruce_suit.tx.json", "planks_spruce_chest": "sind:mark27/camos/planks_spruce_chest.tx.json", "planks_spruce_cannon": "sind:mark27/camos/planks_spruce_cannon.tx.json", "planks_spruce_flaps": "sind:mark27/camos/planks_spruce_flaps.tx.json",
    "pumpkin_side_suit": "sind:mark27/camos/pumpkin_side_suit.tx.json", "pumpkin_side_chest": "sind:mark27/camos/pumpkin_side_chest.tx.json", "pumpkin_side_cannon": "sind:mark27/camos/pumpkin_side_cannon.tx.json", "pumpkin_side_flaps": "sind:mark27/camos/pumpkin_side_flaps.tx.json",
    "quartz_block_chiseled_suit": "sind:mark27/camos/quartz_block_chiseled_suit.tx.json", "quartz_block_chiseled_chest": "sind:mark27/camos/quartz_block_chiseled_chest.tx.json", "quartz_block_chiseled_cannon": "sind:mark27/camos/quartz_block_chiseled_cannon.tx.json", "quartz_block_chiseled_flaps": "sind:mark27/camos/quartz_block_chiseled_flaps.tx.json",
    "quartz_block_lines_suit": "sind:mark27/camos/quartz_block_lines_suit.tx.json", "quartz_block_lines_chest": "sind:mark27/camos/quartz_block_lines_chest.tx.json", "quartz_block_lines_cannon": "sind:mark27/camos/quartz_block_lines_cannon.tx.json", "quartz_block_lines_flaps": "sind:mark27/camos/quartz_block_lines_flaps.tx.json",
    "quartz_block_side_suit": "sind:mark27/camos/quartz_block_side_suit.tx.json", "quartz_block_side_chest": "sind:mark27/camos/quartz_block_side_chest.tx.json", "quartz_block_side_cannon": "sind:mark27/camos/quartz_block_side_cannon.tx.json", "quartz_block_side_flaps": "sind:mark27/camos/quartz_block_side_flaps.tx.json",
    "quartz_ore_suit": "sind:mark27/camos/quartz_ore_suit.tx.json", "quartz_ore_chest": "sind:mark27/camos/quartz_ore_chest.tx.json", "quartz_ore_cannon": "sind:mark27/camos/quartz_ore_cannon.tx.json", "quartz_ore_flaps": "sind:mark27/camos/quartz_ore_flaps.tx.json",
    "red_sand_suit": "sind:mark27/camos/red_sand_suit.tx.json", "red_sand_chest": "sind:mark27/camos/red_sand_chest.tx.json", "red_sand_cannon": "sind:mark27/camos/red_sand_cannon.tx.json", "red_sand_flaps": "sind:mark27/camos/red_sand_flaps.tx.json",
    "redstone_block_suit": "sind:mark27/camos/redstone_block_suit.tx.json", "redstone_block_chest": "sind:mark27/camos/redstone_block_chest.tx.json", "redstone_block_cannon": "sind:mark27/camos/redstone_block_cannon.tx.json", "redstone_block_flaps": "sind:mark27/camos/redstone_block_flaps.tx.json",
    "redstone_ore_suit": "sind:mark27/camos/redstone_ore_suit.tx.json", "redstone_ore_chest": "sind:mark27/camos/redstone_ore_chest.tx.json", "redstone_ore_cannon": "sind:mark27/camos/redstone_ore_cannon.tx.json", "redstone_ore_flaps": "sind:mark27/camos/redstone_ore_flaps.tx.json",
    "sand_suit": "sind:mark27/camos/sand_suit.tx.json", "sand_chest": "sind:mark27/camos/sand_chest.tx.json", "sand_cannon": "sind:mark27/camos/sand_cannon.tx.json", "sand_flaps": "sind:mark27/camos/sand_flaps.tx.json",
    "sandstone_carved_suit": "sind:mark27/camos/sandstone_carved_suit.tx.json", "sandstone_carved_chest": "sind:mark27/camos/sandstone_carved_chest.tx.json", "sandstone_carved_cannon": "sind:mark27/camos/sandstone_carved_cannon.tx.json", "sandstone_carved_flaps": "sind:mark27/camos/sandstone_carved_flaps.tx.json",
    "sandstone_normal_suit": "sind:mark27/camos/sandstone_normal_suit.tx.json", "sandstone_normal_chest": "sind:mark27/camos/sandstone_normal_chest.tx.json", "sandstone_normal_cannon": "sind:mark27/camos/sandstone_normal_cannon.tx.json", "sandstone_normal_flaps": "sind:mark27/camos/sandstone_normal_flaps.tx.json",
    "sandstone_smooth_suit": "sind:mark27/camos/sandstone_smooth_suit.tx.json", "sandstone_smooth_chest": "sind:mark27/camos/sandstone_smooth_chest.tx.json", "sandstone_smooth_cannon": "sind:mark27/camos/sandstone_smooth_cannon.tx.json", "sandstone_smooth_flaps": "sind:mark27/camos/sandstone_smooth_flaps.tx.json",
    "snow_suit": "sind:mark27/camos/snow_suit.tx.json", "snow_chest": "sind:mark27/camos/snow_chest.tx.json", "snow_cannon": "sind:mark27/camos/snow_cannon.tx.json", "snow_flaps": "sind:mark27/camos/snow_flaps.tx.json",
    "soul_sand_suit": "sind:mark27/camos/soul_sand_suit.tx.json", "soul_sand_chest": "sind:mark27/camos/soul_sand_chest.tx.json", "soul_sand_cannon": "sind:mark27/camos/soul_sand_cannon.tx.json", "soul_sand_flaps": "sind:mark27/camos/soul_sand_flaps.tx.json",
    "sponge_suit": "sind:mark27/camos/sponge_suit.tx.json", "sponge_chest": "sind:mark27/camos/sponge_chest.tx.json", "sponge_cannon": "sind:mark27/camos/sponge_cannon.tx.json", "sponge_flaps": "sind:mark27/camos/sponge_flaps.tx.json",
    "stone_suit": "sind:mark27/camos/stone_suit.tx.json", "stone_chest": "sind:mark27/camos/stone_chest.tx.json", "stone_cannon": "sind:mark27/camos/stone_cannon.tx.json", "stone_flaps": "sind:mark27/camos/stone_flaps.tx.json",
    "stonebrick_suit": "sind:mark27/camos/stonebrick_suit.tx.json", "stonebrick_chest": "sind:mark27/camos/stonebrick_chest.tx.json", "stonebrick_cannon": "sind:mark27/camos/stonebrick_cannon.tx.json", "stonebrick_flaps": "sind:mark27/camos/stonebrick_flaps.tx.json",
    "stonebrick_carved_suit": "sind:mark27/camos/stonebrick_carved_suit.tx.json", "stonebrick_carved_chest": "sind:mark27/camos/stonebrick_carved_chest.tx.json", "stonebrick_carved_cannon": "sind:mark27/camos/stonebrick_carved_cannon.tx.json", "stonebrick_carved_flaps": "sind:mark27/camos/stonebrick_carved_flaps.tx.json",
    "stonebrick_cracked_suit": "sind:mark27/camos/stonebrick_cracked_suit.tx.json", "stonebrick_cracked_chest": "sind:mark27/camos/stonebrick_cracked_chest.tx.json", "stonebrick_cracked_cannon": "sind:mark27/camos/stonebrick_cracked_cannon.tx.json", "stonebrick_cracked_flaps": "sind:mark27/camos/stonebrick_cracked_flaps.tx.json",
    "stonebrick_mossy_suit": "sind:mark27/camos/stonebrick_mossy_suit.tx.json", "stonebrick_mossy_chest": "sind:mark27/camos/stonebrick_mossy_chest.tx.json", "stonebrick_mossy_cannon": "sind:mark27/camos/stonebrick_mossy_cannon.tx.json", "stonebrick_mossy_flaps": "sind:mark27/camos/stonebrick_mossy_flaps.tx.json",
    "wool_colored_black_suit": "sind:mark27/camos/wool_colored_black_suit.tx.json", "wool_colored_black_chest": "sind:mark27/camos/wool_colored_black_chest.tx.json", "wool_colored_black_cannon": "sind:mark27/camos/wool_colored_black_cannon.tx.json", "wool_colored_black_flaps": "sind:mark27/camos/wool_colored_black_flaps.tx.json",
    "wool_colored_blue_suit": "sind:mark27/camos/wool_colored_blue_suit.tx.json", "wool_colored_blue_chest": "sind:mark27/camos/wool_colored_blue_chest.tx.json", "wool_colored_blue_cannon": "sind:mark27/camos/wool_colored_blue_cannon.tx.json", "wool_colored_blue_flaps": "sind:mark27/camos/wool_colored_blue_flaps.tx.json",
    "wool_colored_brown_suit": "sind:mark27/camos/wool_colored_brown_suit.tx.json", "wool_colored_brown_chest": "sind:mark27/camos/wool_colored_brown_chest.tx.json", "wool_colored_brown_cannon": "sind:mark27/camos/wool_colored_brown_cannon.tx.json", "wool_colored_brown_flaps": "sind:mark27/camos/wool_colored_brown_flaps.tx.json",
    "wool_colored_cyan_suit": "sind:mark27/camos/wool_colored_cyan_suit.tx.json", "wool_colored_cyan_chest": "sind:mark27/camos/wool_colored_cyan_chest.tx.json", "wool_colored_cyan_cannon": "sind:mark27/camos/wool_colored_cyan_cannon.tx.json", "wool_colored_cyan_flaps": "sind:mark27/camos/wool_colored_cyan_flaps.tx.json",
    "wool_colored_gray_suit": "sind:mark27/camos/wool_colored_gray_suit.tx.json", "wool_colored_gray_chest": "sind:mark27/camos/wool_colored_gray_chest.tx.json", "wool_colored_gray_cannon": "sind:mark27/camos/wool_colored_gray_cannon.tx.json", "wool_colored_gray_flaps": "sind:mark27/camos/wool_colored_gray_flaps.tx.json",
    "wool_colored_green_suit": "sind:mark27/camos/wool_colored_green_suit.tx.json", "wool_colored_green_chest": "sind:mark27/camos/wool_colored_green_chest.tx.json", "wool_colored_green_cannon": "sind:mark27/camos/wool_colored_green_cannon.tx.json", "wool_colored_green_flaps": "sind:mark27/camos/wool_colored_green_flaps.tx.json",
    "wool_colored_light_blue_suit": "sind:mark27/camos/wool_colored_light_blue_suit.tx.json", "wool_colored_light_blue_chest": "sind:mark27/camos/wool_colored_light_blue_chest.tx.json", "wool_colored_light_blue_cannon": "sind:mark27/camos/wool_colored_light_blue_cannon.tx.json", "wool_colored_light_blue_flaps": "sind:mark27/camos/wool_colored_light_blue_flaps.tx.json",
    "wool_colored_lime_suit": "sind:mark27/camos/wool_colored_lime_suit.tx.json", "wool_colored_lime_chest": "sind:mark27/camos/wool_colored_lime_chest.tx.json", "wool_colored_lime_cannon": "sind:mark27/camos/wool_colored_lime_cannon.tx.json", "wool_colored_lime_flaps": "sind:mark27/camos/wool_colored_lime_flaps.tx.json",
    "wool_colored_magenta_suit": "sind:mark27/camos/wool_colored_magenta_suit.tx.json", "wool_colored_magenta_chest": "sind:mark27/camos/wool_colored_magenta_chest.tx.json", "wool_colored_magenta_cannon": "sind:mark27/camos/wool_colored_magenta_cannon.tx.json", "wool_colored_magenta_flaps": "sind:mark27/camos/wool_colored_magenta_flaps.tx.json",
    "wool_colored_orange_suit": "sind:mark27/camos/wool_colored_orange_suit.tx.json", "wool_colored_orange_chest": "sind:mark27/camos/wool_colored_orange_chest.tx.json", "wool_colored_orange_cannon": "sind:mark27/camos/wool_colored_orange_cannon.tx.json", "wool_colored_orange_flaps": "sind:mark27/camos/wool_colored_orange_flaps.tx.json",
    "wool_colored_pink_suit": "sind:mark27/camos/wool_colored_pink_suit.tx.json", "wool_colored_pink_chest": "sind:mark27/camos/wool_colored_pink_chest.tx.json", "wool_colored_pink_cannon": "sind:mark27/camos/wool_colored_pink_cannon.tx.json", "wool_colored_pink_flaps": "sind:mark27/camos/wool_colored_pink_flaps.tx.json",
    "wool_colored_purple_suit": "sind:mark27/camos/wool_colored_purple_suit.tx.json", "wool_colored_purple_chest": "sind:mark27/camos/wool_colored_purple_chest.tx.json", "wool_colored_purple_cannon": "sind:mark27/camos/wool_colored_purple_cannon.tx.json", "wool_colored_purple_flaps": "sind:mark27/camos/wool_colored_purple_flaps.tx.json",
    "wool_colored_red_suit": "sind:mark27/camos/wool_colored_red_suit.tx.json", "wool_colored_red_chest": "sind:mark27/camos/wool_colored_red_chest.tx.json", "wool_colored_red_cannon": "sind:mark27/camos/wool_colored_red_cannon.tx.json", "wool_colored_red_flaps": "sind:mark27/camos/wool_colored_red_flaps.tx.json",
    "wool_colored_silver_suit": "sind:mark27/camos/wool_colored_silver_suit.tx.json", "wool_colored_silver_chest": "sind:mark27/camos/wool_colored_silver_chest.tx.json", "wool_colored_silver_cannon": "sind:mark27/camos/wool_colored_silver_cannon.tx.json", "wool_colored_silver_flaps": "sind:mark27/camos/wool_colored_silver_flaps.tx.json",
    "wool_colored_white_suit": "sind:mark27/camos/wool_colored_white_suit.tx.json", "wool_colored_white_chest": "sind:mark27/camos/wool_colored_white_chest.tx.json", "wool_colored_white_cannon": "sind:mark27/camos/wool_colored_white_cannon.tx.json", "wool_colored_white_flaps": "sind:mark27/camos/wool_colored_white_flaps.tx.json",
    "wool_colored_yellow_suit": "sind:mark27/camos/wool_colored_yellow_suit.tx.json", "wool_colored_yellow_chest": "sind:mark27/camos/wool_colored_yellow_chest.tx.json", "wool_colored_yellow_cannon": "sind:mark27/camos/wool_colored_yellow_cannon.tx.json", "wool_colored_yellow_flaps": "sind:mark27/camos/wool_colored_yellow_flaps.tx.json"
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/mk27_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var cannon, flaps;
var unibeam;
var jarvis = implement("sind:external/jarvis");
var hud, hud2, hud3;

var camoEffects = {};
var helmet;

var camos = [ "bedrock", "brick", "clay", "coal_block", "coal_ore", "cobblestone", "cobblestone_mossy", "diamond_block", "diamond_ore", "dirt", "dirt_podzol_top", 
    "emerald_block", "emerald_ore", "end_stone", "glowstone", "gold_block", "gold_ore", "gravel", "hardened_clay", "hardened_clay_stained_black", 
    "hardened_clay_stained_blue", "hardened_clay_stained_brown", "hardened_clay_stained_cyan", "hardened_clay_stained_gray", "hardened_clay_stained_green", 
    "hardened_clay_stained_light_blue", "hardened_clay_stained_lime", "hardened_clay_stained_magenta", "hardened_clay_stained_orange", "hardened_clay_stained_pink", 
    "hardened_clay_stained_purple", "hardened_clay_stained_red", "hardened_clay_stained_silver", "hardened_clay_stained_white", "hardened_clay_stained_yellow", 
    "ice_packed", "iron_block", "iron_ore", "lapis_block", "lapis_ore", "log_acacia", "log_big_oak", "log_birch", "log_jungle", "log_oak", "log_spruce", "melon_side", 
    "mushroom_block_skin_brown", "mushroom_block_skin_red", "mushroom_block_skin_stem", "mycelium_top", "nether_brick", "netherrack", "obsidian", "planks_acacia", 
    "planks_big_oak", "planks_birch", "planks_jungle", "planks_oak", "planks_spruce", "pumpkin_side", "quartz_block_chiseled", "quartz_block_lines", "quartz_block_side", 
    "quartz_ore", "red_sand", "redstone_block", "redstone_ore", "sand", "sandstone_carved", "sandstone_normal", "sandstone_smooth", "snow", "soul_sand", "sponge", "stone", 
    "stonebrick", "stonebrick_carved", "stonebrick_cracked", "stonebrick_mossy", "wool_colored_black", "wool_colored_blue", "wool_colored_brown", "wool_colored_cyan", 
    "wool_colored_gray", "wool_colored_green", "wool_colored_light_blue", "wool_colored_lime", "wool_colored_magenta", "wool_colored_orange", "wool_colored_pink", 
    "wool_colored_purple", "wool_colored_red", "wool_colored_silver", "wool_colored_white", "wool_colored_yellow" ];

function initEffects(renderer, entity) {
    parent.initEffects(renderer);
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.65);

    var flareModel = utils.createModel(renderer, "sind:flares", "layer2", null);
    flareModel.generateMirror();
    flares = renderer.createEffect("fiskheroes:model").setModel(flareModel);
    flares.anchor.set("rightLeg");
    flares.mirror = true;

    utils.bindParticles(renderer, "sind:flares").setCondition(entity => entity.getData("sind:dyn/flares"));

    var rock = utils.createModel(renderer, "sind:rockets", "rockets", null);
    rock.bindAnimation("sind:rockets").setData((entity, data) => {
        data.load(0, entity.getData("sind:dyn/srockets_cooldown") > 0.48);
        data.load(1, entity.getData("sind:dyn/srockets_cooldown") > 0.57);
        data.load(2, entity.getData("sind:dyn/srockets_cooldown") > 0.65);
    });

    rockets = renderer.createEffect("fiskheroes:model").setModel(rock);
    rockets.anchor.set("body");

    //base
    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    chest = makeChest(renderer, entity, utils, "chest");
    cannon = makeCannon(renderer, entity, utils, "cannon");
    flaps = makeFlaps(renderer, entity, utils, "flaps");
    //hell simplified
    var i, name;
    for (i = 0; i < camos.length; i++) {
        name = camos[i];
        camoEffects[name] = createCamoSet(renderer, entity, name);
    }
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    utils.bindParticles(renderer, "sind:mk7").setCondition(entity => entity.getData("fiskheroes:flying"));
    utils.bindBeam(renderer, "fiskheroes:energy_projection", "sind:rockets1", "head", 0xFFFFFF, [{
                "offset": [4.0, 0.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-4.0, 0.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [3.0, 0.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-3.0, 0.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [4.0, 1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-4.0, 1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [3.0, 1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-3.0, 1.0, 3.0],
                "size": [0.25, 0.25]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 2.75, -3],
                "size": [1.5, 1.5]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    utils.bindBeam(renderer, "fiskheroes:energy_manipulation", "sind:rockets", "rightArm", 0xFFFFFF, [{
                "offset": [-3.0, 2.0, 0.0],
                "size": [0.85, 0.85]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

    renderer.bindProperty("fiskheroes:opacity").setOpacity((entity) => {
        var cloaking = entity.getInterpolatedData("sind:dyn/night_timer");
        return 1 - cloaking;
    });
    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(
        helmet.effect, chest, cannon, rockets, flaps, flares,
        // EVIL INCLUDE EFFECTS from HELL
        camoEffects["bedrock"].suit, camoEffects["bedrock"].chest, camoEffects["bedrock"].cannon, camoEffects["bedrock"].flaps,
        camoEffects["brick"].suit, camoEffects["brick"].chest, camoEffects["brick"].cannon, camoEffects["brick"].flaps,
        camoEffects["clay"].suit, camoEffects["clay"].chest, camoEffects["clay"].cannon, camoEffects["clay"].flaps,
        camoEffects["coal_block"].suit, camoEffects["coal_block"].chest, camoEffects["coal_block"].cannon, camoEffects["coal_block"].flaps,
        camoEffects["coal_ore"].suit, camoEffects["coal_ore"].chest, camoEffects["coal_ore"].cannon, camoEffects["coal_ore"].flaps,
        camoEffects["cobblestone"].suit, camoEffects["cobblestone"].chest, camoEffects["cobblestone"].cannon, camoEffects["cobblestone"].flaps,
        camoEffects["cobblestone_mossy"].suit, camoEffects["cobblestone_mossy"].chest, camoEffects["cobblestone_mossy"].cannon, camoEffects["cobblestone_mossy"].flaps,
        camoEffects["diamond_block"].suit, camoEffects["diamond_block"].chest, camoEffects["diamond_block"].cannon, camoEffects["diamond_block"].flaps,
        camoEffects["diamond_ore"].suit, camoEffects["diamond_ore"].chest, camoEffects["diamond_ore"].cannon, camoEffects["diamond_ore"].flaps,
        camoEffects["dirt"].suit, camoEffects["dirt"].chest, camoEffects["dirt"].cannon, camoEffects["dirt"].flaps,
        camoEffects["dirt_podzol_top"].suit, camoEffects["dirt_podzol_top"].chest, camoEffects["dirt_podzol_top"].cannon, camoEffects["dirt_podzol_top"].flaps,
        camoEffects["emerald_block"].suit, camoEffects["emerald_block"].chest, camoEffects["emerald_block"].cannon, camoEffects["emerald_block"].flaps,
        camoEffects["emerald_ore"].suit, camoEffects["emerald_ore"].chest, camoEffects["emerald_ore"].cannon, camoEffects["emerald_ore"].flaps,
        camoEffects["end_stone"].suit, camoEffects["end_stone"].chest, camoEffects["end_stone"].cannon, camoEffects["end_stone"].flaps,
        camoEffects["glowstone"].suit, camoEffects["glowstone"].chest, camoEffects["glowstone"].cannon, camoEffects["glowstone"].flaps,
        camoEffects["gold_block"].suit, camoEffects["gold_block"].chest, camoEffects["gold_block"].cannon, camoEffects["gold_block"].flaps,
        camoEffects["gold_ore"].suit, camoEffects["gold_ore"].chest, camoEffects["gold_ore"].cannon, camoEffects["gold_ore"].flaps,
        camoEffects["gravel"].suit, camoEffects["gravel"].chest, camoEffects["gravel"].cannon, camoEffects["gravel"].flaps,
        camoEffects["hardened_clay"].suit, camoEffects["hardened_clay"].chest, camoEffects["hardened_clay"].cannon, camoEffects["hardened_clay"].flaps,
        camoEffects["hardened_clay_stained_black"].suit, camoEffects["hardened_clay_stained_black"].chest, camoEffects["hardened_clay_stained_black"].cannon, camoEffects["hardened_clay_stained_black"].flaps,
        camoEffects["hardened_clay_stained_blue"].suit, camoEffects["hardened_clay_stained_blue"].chest, camoEffects["hardened_clay_stained_blue"].cannon, camoEffects["hardened_clay_stained_blue"].flaps,
        camoEffects["hardened_clay_stained_brown"].suit, camoEffects["hardened_clay_stained_brown"].chest, camoEffects["hardened_clay_stained_brown"].cannon, camoEffects["hardened_clay_stained_brown"].flaps,
        camoEffects["hardened_clay_stained_cyan"].suit, camoEffects["hardened_clay_stained_cyan"].chest, camoEffects["hardened_clay_stained_cyan"].cannon, camoEffects["hardened_clay_stained_cyan"].flaps,
        camoEffects["hardened_clay_stained_gray"].suit, camoEffects["hardened_clay_stained_gray"].chest, camoEffects["hardened_clay_stained_gray"].cannon, camoEffects["hardened_clay_stained_gray"].flaps,
        camoEffects["hardened_clay_stained_green"].suit, camoEffects["hardened_clay_stained_green"].chest, camoEffects["hardened_clay_stained_green"].cannon, camoEffects["hardened_clay_stained_green"].flaps,
        camoEffects["hardened_clay_stained_light_blue"].suit, camoEffects["hardened_clay_stained_light_blue"].chest, camoEffects["hardened_clay_stained_light_blue"].cannon, camoEffects["hardened_clay_stained_light_blue"].flaps,
        camoEffects["hardened_clay_stained_lime"].suit, camoEffects["hardened_clay_stained_lime"].chest, camoEffects["hardened_clay_stained_lime"].cannon, camoEffects["hardened_clay_stained_lime"].flaps,
        camoEffects["hardened_clay_stained_magenta"].suit, camoEffects["hardened_clay_stained_magenta"].chest, camoEffects["hardened_clay_stained_magenta"].cannon, camoEffects["hardened_clay_stained_magenta"].flaps,
        camoEffects["hardened_clay_stained_orange"].suit, camoEffects["hardened_clay_stained_orange"].chest, camoEffects["hardened_clay_stained_orange"].cannon, camoEffects["hardened_clay_stained_orange"].flaps,
        camoEffects["hardened_clay_stained_pink"].suit, camoEffects["hardened_clay_stained_pink"].chest, camoEffects["hardened_clay_stained_pink"].cannon, camoEffects["hardened_clay_stained_pink"].flaps,
        camoEffects["hardened_clay_stained_purple"].suit, camoEffects["hardened_clay_stained_purple"].chest, camoEffects["hardened_clay_stained_purple"].cannon, camoEffects["hardened_clay_stained_purple"].flaps,
        camoEffects["hardened_clay_stained_red"].suit, camoEffects["hardened_clay_stained_red"].chest, camoEffects["hardened_clay_stained_red"].cannon, camoEffects["hardened_clay_stained_red"].flaps,
        camoEffects["hardened_clay_stained_silver"].suit, camoEffects["hardened_clay_stained_silver"].chest, camoEffects["hardened_clay_stained_silver"].cannon, camoEffects["hardened_clay_stained_silver"].flaps,
        camoEffects["hardened_clay_stained_white"].suit, camoEffects["hardened_clay_stained_white"].chest, camoEffects["hardened_clay_stained_white"].cannon, camoEffects["hardened_clay_stained_white"].flaps,
        camoEffects["hardened_clay_stained_yellow"].suit, camoEffects["hardened_clay_stained_yellow"].chest, camoEffects["hardened_clay_stained_yellow"].cannon, camoEffects["hardened_clay_stained_yellow"].flaps,
        camoEffects["ice_packed"].suit, camoEffects["ice_packed"].chest, camoEffects["ice_packed"].cannon, camoEffects["ice_packed"].flaps,
        camoEffects["iron_block"].suit, camoEffects["iron_block"].chest, camoEffects["iron_block"].cannon, camoEffects["iron_block"].flaps,
        camoEffects["iron_ore"].suit, camoEffects["iron_ore"].chest, camoEffects["iron_ore"].cannon, camoEffects["iron_ore"].flaps,
        camoEffects["lapis_block"].suit, camoEffects["lapis_block"].chest, camoEffects["lapis_block"].cannon, camoEffects["lapis_block"].flaps,
        camoEffects["lapis_ore"].suit, camoEffects["lapis_ore"].chest, camoEffects["lapis_ore"].cannon, camoEffects["lapis_ore"].flaps,
        camoEffects["log_acacia"].suit, camoEffects["log_acacia"].chest, camoEffects["log_acacia"].cannon, camoEffects["log_acacia"].flaps,
        camoEffects["log_big_oak"].suit, camoEffects["log_big_oak"].chest, camoEffects["log_big_oak"].cannon, camoEffects["log_big_oak"].flaps,
        camoEffects["log_birch"].suit, camoEffects["log_birch"].chest, camoEffects["log_birch"].cannon, camoEffects["log_birch"].flaps,
        camoEffects["log_jungle"].suit, camoEffects["log_jungle"].chest, camoEffects["log_jungle"].cannon, camoEffects["log_jungle"].flaps,
        camoEffects["log_oak"].suit, camoEffects["log_oak"].chest, camoEffects["log_oak"].cannon, camoEffects["log_oak"].flaps,
        camoEffects["log_spruce"].suit, camoEffects["log_spruce"].chest, camoEffects["log_spruce"].cannon, camoEffects["log_spruce"].flaps,
        camoEffects["melon_side"].suit, camoEffects["melon_side"].chest, camoEffects["melon_side"].cannon, camoEffects["melon_side"].flaps,
        camoEffects["mushroom_block_skin_brown"].suit, camoEffects["mushroom_block_skin_brown"].chest, camoEffects["mushroom_block_skin_brown"].cannon, camoEffects["mushroom_block_skin_brown"].flaps,
        camoEffects["mushroom_block_skin_red"].suit, camoEffects["mushroom_block_skin_red"].chest, camoEffects["mushroom_block_skin_red"].cannon, camoEffects["mushroom_block_skin_red"].flaps,
        camoEffects["mushroom_block_skin_stem"].suit, camoEffects["mushroom_block_skin_stem"].chest, camoEffects["mushroom_block_skin_stem"].cannon, camoEffects["mushroom_block_skin_stem"].flaps,
        camoEffects["mycelium_top"].suit, camoEffects["mycelium_top"].chest, camoEffects["mycelium_top"].cannon, camoEffects["mycelium_top"].flaps,
        camoEffects["nether_brick"].suit, camoEffects["nether_brick"].chest, camoEffects["nether_brick"].cannon, camoEffects["nether_brick"].flaps,
        camoEffects["netherrack"].suit, camoEffects["netherrack"].chest, camoEffects["netherrack"].cannon, camoEffects["netherrack"].flaps,
        camoEffects["obsidian"].suit, camoEffects["obsidian"].chest, camoEffects["obsidian"].cannon, camoEffects["obsidian"].flaps,
        camoEffects["planks_acacia"].suit, camoEffects["planks_acacia"].chest, camoEffects["planks_acacia"].cannon, camoEffects["planks_acacia"].flaps,
        camoEffects["planks_big_oak"].suit, camoEffects["planks_big_oak"].chest, camoEffects["planks_big_oak"].cannon, camoEffects["planks_big_oak"].flaps,
        camoEffects["planks_birch"].suit, camoEffects["planks_birch"].chest, camoEffects["planks_birch"].cannon, camoEffects["planks_birch"].flaps,
        camoEffects["planks_jungle"].suit, camoEffects["planks_jungle"].chest, camoEffects["planks_jungle"].cannon, camoEffects["planks_jungle"].flaps,
        camoEffects["planks_oak"].suit, camoEffects["planks_oak"].chest, camoEffects["planks_oak"].cannon, camoEffects["planks_oak"].flaps,
        camoEffects["planks_spruce"].suit, camoEffects["planks_spruce"].chest, camoEffects["planks_spruce"].cannon, camoEffects["planks_spruce"].flaps,
        camoEffects["pumpkin_side"].suit, camoEffects["pumpkin_side"].chest, camoEffects["pumpkin_side"].cannon, camoEffects["pumpkin_side"].flaps,
        camoEffects["quartz_block_chiseled"].suit, camoEffects["quartz_block_chiseled"].chest, camoEffects["quartz_block_chiseled"].cannon, camoEffects["quartz_block_chiseled"].flaps,
        camoEffects["quartz_block_lines"].suit, camoEffects["quartz_block_lines"].chest, camoEffects["quartz_block_lines"].cannon, camoEffects["quartz_block_lines"].flaps,
        camoEffects["quartz_block_side"].suit, camoEffects["quartz_block_side"].chest, camoEffects["quartz_block_side"].cannon, camoEffects["quartz_block_side"].flaps,
        camoEffects["quartz_ore"].suit, camoEffects["quartz_ore"].chest, camoEffects["quartz_ore"].cannon, camoEffects["quartz_ore"].flaps,
        camoEffects["red_sand"].suit, camoEffects["red_sand"].chest, camoEffects["red_sand"].cannon, camoEffects["red_sand"].flaps,
        camoEffects["redstone_block"].suit, camoEffects["redstone_block"].chest, camoEffects["redstone_block"].cannon, camoEffects["redstone_block"].flaps,
        camoEffects["redstone_ore"].suit, camoEffects["redstone_ore"].chest, camoEffects["redstone_ore"].cannon, camoEffects["redstone_ore"].flaps,
        camoEffects["sand"].suit, camoEffects["sand"].chest, camoEffects["sand"].cannon, camoEffects["sand"].flaps,
        camoEffects["sandstone_carved"].suit, camoEffects["sandstone_carved"].chest, camoEffects["sandstone_carved"].cannon, camoEffects["sandstone_carved"].flaps,
        camoEffects["sandstone_normal"].suit, camoEffects["sandstone_normal"].chest, camoEffects["sandstone_normal"].cannon, camoEffects["sandstone_normal"].flaps,
        camoEffects["sandstone_smooth"].suit, camoEffects["sandstone_smooth"].chest, camoEffects["sandstone_smooth"].cannon, camoEffects["sandstone_smooth"].flaps,
        camoEffects["snow"].suit, camoEffects["snow"].chest, camoEffects["snow"].cannon, camoEffects["snow"].flaps,
        camoEffects["soul_sand"].suit, camoEffects["soul_sand"].chest, camoEffects["soul_sand"].cannon, camoEffects["soul_sand"].flaps,
        camoEffects["sponge"].suit, camoEffects["sponge"].chest, camoEffects["sponge"].cannon, camoEffects["sponge"].flaps,
        camoEffects["stone"].suit, camoEffects["stone"].chest, camoEffects["stone"].cannon, camoEffects["stone"].flaps,
        camoEffects["stonebrick"].suit, camoEffects["stonebrick"].chest, camoEffects["stonebrick"].cannon, camoEffects["stonebrick"].flaps,
        camoEffects["stonebrick_carved"].suit, camoEffects["stonebrick_carved"].chest, camoEffects["stonebrick_carved"].cannon, camoEffects["stonebrick_carved"].flaps,
        camoEffects["stonebrick_cracked"].suit, camoEffects["stonebrick_cracked"].chest, camoEffects["stonebrick_cracked"].cannon, camoEffects["stonebrick_cracked"].flaps,
        camoEffects["stonebrick_mossy"].suit, camoEffects["stonebrick_mossy"].chest, camoEffects["stonebrick_mossy"].cannon, camoEffects["stonebrick_mossy"].flaps,
        camoEffects["wool_colored_black"].suit, camoEffects["wool_colored_black"].chest, camoEffects["wool_colored_black"].cannon, camoEffects["wool_colored_black"].flaps,
        camoEffects["wool_colored_blue"].suit, camoEffects["wool_colored_blue"].chest, camoEffects["wool_colored_blue"].cannon, camoEffects["wool_colored_blue"].flaps,
        camoEffects["wool_colored_brown"].suit, camoEffects["wool_colored_brown"].chest, camoEffects["wool_colored_brown"].cannon, camoEffects["wool_colored_brown"].flaps,
        camoEffects["wool_colored_cyan"].suit, camoEffects["wool_colored_cyan"].chest, camoEffects["wool_colored_cyan"].cannon, camoEffects["wool_colored_cyan"].flaps,
        camoEffects["wool_colored_gray"].suit, camoEffects["wool_colored_gray"].chest, camoEffects["wool_colored_gray"].cannon, camoEffects["wool_colored_gray"].flaps,
        camoEffects["wool_colored_green"].suit, camoEffects["wool_colored_green"].chest, camoEffects["wool_colored_green"].cannon, camoEffects["wool_colored_green"].flaps,
        camoEffects["wool_colored_light_blue"].suit, camoEffects["wool_colored_light_blue"].chest, camoEffects["wool_colored_light_blue"].cannon, camoEffects["wool_colored_light_blue"].flaps,
        camoEffects["wool_colored_lime"].suit, camoEffects["wool_colored_lime"].chest, camoEffects["wool_colored_lime"].cannon, camoEffects["wool_colored_lime"].flaps,
        camoEffects["wool_colored_magenta"].suit, camoEffects["wool_colored_magenta"].chest, camoEffects["wool_colored_magenta"].cannon, camoEffects["wool_colored_magenta"].flaps,
        camoEffects["wool_colored_orange"].suit, camoEffects["wool_colored_orange"].chest, camoEffects["wool_colored_orange"].cannon, camoEffects["wool_colored_orange"].flaps,
        camoEffects["wool_colored_pink"].suit, camoEffects["wool_colored_pink"].chest, camoEffects["wool_colored_pink"].cannon, camoEffects["wool_colored_pink"].flaps,
        camoEffects["wool_colored_purple"].suit, camoEffects["wool_colored_purple"].chest, camoEffects["wool_colored_purple"].cannon, camoEffects["wool_colored_purple"].flaps,
        camoEffects["wool_colored_red"].suit, camoEffects["wool_colored_red"].chest, camoEffects["wool_colored_red"].cannon, camoEffects["wool_colored_red"].flaps,
        camoEffects["wool_colored_silver"].suit, camoEffects["wool_colored_silver"].chest, camoEffects["wool_colored_silver"].cannon, camoEffects["wool_colored_silver"].flaps,
        camoEffects["wool_colored_white"].suit, camoEffects["wool_colored_white"].chest, camoEffects["wool_colored_white"].cannon, camoEffects["wool_colored_white"].flaps,
        camoEffects["wool_colored_yellow"].suit, camoEffects["wool_colored_yellow"].chest, camoEffects["wool_colored_yellow"].cannon, camoEffects["wool_colored_yellow"].flaps
    );

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF, 20);
    hud2 = jarvis.createComponent(renderer, utils, "cannons", "h_cannons", 1);
    hud3 = jarvis.createComponent(renderer, utils, "bulkchest", "h_bulkchest", 1);
}

function render(entity, renderLayer, isFirstPersonArm) {
    parent.render(entity, renderLayer, isFirstPersonArm);
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "CHESTPLATE") {
            if (entity.getInterpolatedData("sind:dyn/srockets_cooldown") >= 0.35 && entity.getData("sind:dyn/srockets")) {
                rockets.render()
            }
            chest.render();
            cannon.render();
            flaps.render();
        } else if (renderLayer == "LEGGINGS" && entity.getData("fiskheroes:suit_open_timer") == 0 && entity.getData("sind:dyn/flares_timer") > 0) {
            flares.setOffset(-2*(1-Math.min(5*entity.getInterpolatedData("sind:dyn/flares_timer"), 1)) - 2, -12, -0.1);
            flares.render();
        }
    }

    if (entity.getInterpolatedData("sind:dyn/camo_timer") > 0) {
        renderAllCamos(entity, renderLayer, isFirstPersonArm);
    }
    if (renderLayer == "CHESTPLATE") {
        unibeam.render(entity, isFirstPersonArm);
    }
    if(renderLayer == "HELMET") {
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud2.render(entity, renderLayer, isFirstPersonArm);
        hud3.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}

//helper functions because wtf was the original code
function makeChest(renderer, entity, utils, texture) {
    var bulkModel = utils.createModel(renderer, "sind:bulkchest", texture, null);
    bulkModel.bindAnimation("sind:flaps").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        var inv = 1 - entity.getInterpolatedData("sind:dyn/flight_boost_timer");
        var eq = Math.sin(Math.PI*inv); 
        var eq2 = -2*inv + 2
        var timer = inv > 0.5 ? eq2 : eq; 
        data.load(1, (entity.getData("fiskheroes:flying") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"))) ? timer : 0);
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(3, entity.loop(50));
    });
    var model = renderer.createEffect("fiskheroes:model").setModel(bulkModel);
    model.anchor.set("body");

    return model;
}

function makeCannon(renderer, entity, utils, texture) {
    var cannonModel = utils.createModel(renderer, "sind:cannons", texture, null);
    cannonModel.bindAnimation("sind:cannons").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/srockets_timer"));
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
    });
    returncannon = renderer.createEffect("fiskheroes:model").setModel(cannonModel);
    returncannon.anchor.set("body");

    return returncannon;
}
function makeChestLight(renderer, entity, utils, texture) {
    var bulkModel = utils.createModel(renderer, "sind:bulkchest", null, texture);
    bulkModel.bindAnimation("sind:flaps").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        var inv = 1 - entity.getInterpolatedData("sind:dyn/flight_boost_timer");
        var eq = Math.sin(Math.PI*inv); 
        var eq2 = -2*inv + 2
        var timer = inv > 0.5 ? eq2 : eq; 
        data.load(1, (entity.getData("fiskheroes:flying") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"))) ? timer : 0);
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(3, entity.loop(50));
    });
    var model = renderer.createEffect("fiskheroes:model").setModel(bulkModel);
    model.anchor.set("body");

    return model;
}

function makeCannonLight(renderer, entity, utils, texture) {
    var cannonModel = utils.createModel(renderer, "sind:cannons", null, texture);
    cannonModel.bindAnimation("sind:cannons").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
    });
    returncannon = renderer.createEffect("fiskheroes:model").setModel(cannonModel);
    returncannon.anchor.set("body");

    return returncannon;
}
function makeFlaps(renderer, entity, utils, texture) {
    var flapmodel = utils.createModel(renderer, "sind:flaps", texture, null);
    flapmodel.bindAnimation("sind:mk7_flaps").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        var inv = 1 - entity.getInterpolatedData("sind:dyn/flight_boost_timer");
        var eq = Math.sin(Math.PI*inv); 
        var eq2 = -2*inv + 2
        var timer = inv > 0.5 ? eq2 : eq; 
        data.load(1, Math.max(entity.getInterpolatedData("sind:dyn/superhero_landing_timer"), (entity.getData("fiskheroes:flying") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"))) ? timer : 0));
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(3, entity.loop(50));
    });
    flap = renderer.createEffect("fiskheroes:model").setModel(flapmodel);
    flap.anchor.set("body");
    return flap;
}
function makeFlapsLight(renderer, entity, utils, texture) {
    var flapmodel = utils.createModel(renderer, "sind:flaps", null, texture);
    flapmodel.bindAnimation("sind:mk7_flaps").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        var inv = 1 - entity.getInterpolatedData("sind:dyn/flight_boost_timer");
        var eq = Math.sin(Math.PI*inv); 
        var eq2 = -2*inv + 2
        var timer = inv > 0.5 ? eq2 : eq; 
        data.load(1, Math.max(entity.getInterpolatedData("sind:dyn/superhero_landing_timer"), (entity.getData("fiskheroes:flying") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"))) ? timer : 0));
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(3, entity.loop(50));
    });
    flap = renderer.createEffect("fiskheroes:model").setModel(flapmodel);
    flap.anchor.set("body");
    return flap;
}
function renderCamo(entity, renderLayer, isFirstPersonArm, overlayIn, chestIn, cannonIn, flapsIn, timer) {
    overlayIn.opacity = entity.getInterpolatedData(timer) * entity.getInterpolatedData("sind:dyn/camo_timer");
    chestIn.opacity = entity.getInterpolatedData(timer) * entity.getInterpolatedData("sind:dyn/camo_timer");
    cannonIn.opacity = entity.getInterpolatedData(timer) * entity.getInterpolatedData("sind:dyn/camo_timer");
    flapsIn.opacity = entity.getInterpolatedData(timer) * entity.getInterpolatedData("sind:dyn/camo_timer");
    if (entity.getInterpolatedData(timer) > 0) {
        overlayIn.render();
        chestIn.render();
        cannonIn.render();
        flapsIn.render();
    }
}

function createCamoSet(renderer, entity, name) {
    var set = {};
    var isGlowstone = name == "glowstone";
    set.suit = renderer.createEffect("fiskheroes:overlay");

    if (isGlowstone) {
        set.suit.texture.set(null, name + "_suit");
        set.chest = makeChestLight(renderer, entity, utils, name + "_chest");
        set.cannon = makeCannonLight(renderer, entity, utils, name + "_cannon");
        set.flaps = makeFlapsLight(renderer, entity, utils, name + "_flaps");
    } else {
        set.suit.texture.set(name + "_suit");
        set.chest = makeChest(renderer, entity, utils, name + "_chest");
        set.cannon = makeCannon(renderer, entity, utils, name + "_cannon");
        set.flaps = makeFlaps(renderer, entity, utils, name + "_flaps");
    }
    return set;
}

function renderAllCamos(entity, renderLayer, isFirstPersonArm) {
    var i, name, set;
    for (i = 0; i < camos.length; i++) {
        name = camos[i];
        set = camoEffects[name];
        renderCamo(entity, renderLayer, isFirstPersonArm, set.suit, set.chest, set.cannon, set.flaps, "sind:dyn/" + name + "_timer");
    }
}