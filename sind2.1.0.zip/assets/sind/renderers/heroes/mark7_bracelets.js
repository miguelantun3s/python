extend("sind:external/iron_man_base");
loadTextures({
    "suit": "sind:mark7/mark7_suit2.tx.json",
    "suit1": "sind:mark7/mark7_suit1.tx.json",
    "mask": "sind:mark3/mark3_mask.tx.json",
    "chin": "sind:mark4/mark4_chin",
    "rocket": "sind:mark7/mark7_rocket.tx.json",
    "chest": "sind:mark7/mark7_chest",
    "chest_br_noflaps": "sind:mark7/mark7br_chest.tx.json",
    "chest_br_flaps": "sind:mark7/mark7br_chest",
    "cannons": "sind:mark7/mark7_cannon",
    "flaps": "sind:mark7/mark7_flaps.tx.json",
    "laser": "sind:mark7/mark7_laser",
    "lights_noeyes": "sind:lights/lights_noeyes",
    "legflap_bottom": "sind:mark7/mark7_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark7/mark7_legflaps_top.tx.json",

    "mk7": "sind:tony/mark7",
    "mk7_lights": "sind:tony/mark7_lights",
    "mk7_plates": "sind:tony/mark7_plates",
    "fire": "sind:repulsor_layer.tx.json",
    "bracelets": "sind:tony/mark7_bracelets",

    "display_chest_br": "sind:anim/mark7_chest/5",
    "display_space_suit": "sind:anim/mark7_animation/5",

    //jarvis stuff
    "player": "sind:null",
    "player_mh": "sind:null",
    "player0": "sind:null",
    "player1": "sind:null",
    "player2": "sind:null",
    "player3": "sind:null",
    "h_cannons": "sind:hud/mark7/cannon",
    "h_cannons1": "sind:hud/mark7/w_cannon",
    "h_cannons_mh": "sind:hud/mark7/mh_cannon",
    "h_bulkchest": "sind:hud/mark7/chest",
    "h_bulkchest1": "sind:hud/mark7/w_chest",
    "h_bulkchest_mh": "sind:hud/mark7/mh_chest",

    "h2_bulkchest": "sind:hud/mark7/chest2",
    "h2_bulkchest1": "sind:hud/mark7/w_chest2",
    "h2_bulkchest_mh": "sind:hud/mark7/mh_chest2",

    "h_norm": "sind:hud/mark7/full",
    "h_norm_mh": "sind:hud/mark7/mh",
    "h_norm1": "sind:hud/mark7/stitch.tx.json",

    "h_space": "sind:hud/mark7/full2",
    "h_space_mh": "sind:hud/mark7/mh2",
    "h_space1": "sind:hud/mark7/w2"
});

var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/mk7_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");

var flares;
var rockets2;
var cannon;
var helmet, chin;
var chest;
var laser;
var jarvisdome;
var unibeam;
var metal_heat;
var jarvis = implement("sind:external/jarvis");
var hud, hud2, hud3, hud4, hud5, hud6;
var bracelets;
var mk7, mk7plates, mk7fire;
var display, displayplates;
var overlay, display_chestbr;

var chestbr, chestbrflaps;
var legflapsbottom, legflapstop;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (entity.getData("sind:dyn/space7_timer") > 0 && entity.getData("sind:dyn/summon7_timer") == 1 ) {
            return "suit1";
        } else {
            return entity.getData("sind:dyn/summon7_timer") < 1 ? "null" : "suit";
        }
    });
    renderer.setLights((entity, renderLayer) => {
        return entity.getData("sind:dyn/summon7_timer") < 1 ? "null" : 
            entity.getData('fiskheroes:mask_open_timer') == 0 ? "lights" : "lights_noeyes";
    });
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.65);
    
    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    chin = iron_man_utils.createChinplate(renderer, "chin", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    cannon = iron_man_utils.createShoulderCannon(renderer, utils, "cannons", null);
    flares = iron_man_utils.createFlares(renderer, utils, "layer2", null);
    rockets2 = iron_man_utils.createArmRocket(renderer, utils, "rocket", null, 7);
    chest = iron_man_utils.createBulkChest(renderer, utils, "chest", null);
    flaps = iron_man_utils.createFlaps(renderer, utils, "flaps", null, 7);
    laser = iron_man_utils.createLaserEmitter(renderer, utils, "laser", null);

    legflapsbottom = iron_man_utils.createLegFlaps(renderer, utils, "legflap_bottom", null);
    legflapstop = iron_man_utils.createLegFlaps(renderer, utils, "legflap_top", null);

    jarvisdome = renderer.bindProperty("fiskheroes:shadowdome");
    jarvisdome.texture.set("null");
    jarvisdome.setShape(0, 0);

    utils.bindParticles(renderer, "sind:mk7").setCondition(entity => entity.getData("fiskheroes:flying"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
            "firstPerson": [0, 6, -3],
            "offset": [0, 2.75, -3],
            "size": [1.5, 1.5]
        }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    chestbr = iron_man_utils.createBulkChest(renderer, utils, "chest_br_noflaps", null);
    chestbrflaps = iron_man_utils.createBulkChest(renderer, utils, "chest_br_flaps", null);chestbrflaps = iron_man_utils.createBulkChest(renderer, utils, "chest_br_flaps", null);

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, chin.effect, cannon.rockets, cannon.cannon, chest.chest, chestbr.chest, chestbrflaps.chest, laser.laser, rockets2.rockets2, flaps.flaps, flares.flares,
        legflapsbottom.legflapsleft, legflapsbottom.legflapsright, legflapstop.legflapsleft, legflapstop.legflapsright
    );
    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF);
    hud2 = jarvis.createComponent(renderer, utils, "cannons", "h_cannons", 1);
    hud3 = jarvis.createComponent(renderer, utils, "bulkchest", "h_bulkchest", 1);

    hud4 = jarvis.createComponent(renderer, utils, "player", "h_norm", 1); 
    hud5 = jarvis.createComponent(renderer, utils, "player", "h_space", 1);
    hud6 = jarvis.createComponent(renderer, utils, "bulkchest", "h2_bulkchest", 1);

    //transform stuff
    var mk7Model = renderer.createResource("MODEL", "sind:tony/mk7transformation");
    mk7Model.bindAnimation("sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    });
    mk7Model.texture.set("mk7", "mk7_lights");
    mk7 = renderer.createEffect("fiskheroes:model").setModel(mk7Model);
    mk7.anchor.set("body");
    mk7.anchor.ignoreAnchor(true);

    var mk7PlatesModel = renderer.createResource("MODEL", "sind:tony/mk7transformation");
    mk7PlatesModel.bindAnimation("sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    });
    mk7PlatesModel.texture.set("mk7_plates", null);
    mk7plates = renderer.createEffect("fiskheroes:model").setModel(mk7PlatesModel);
    mk7plates.anchor.set("body");
    mk7plates.anchor.ignoreAnchor(true);

    var mk7FireModel = renderer.createResource("MODEL", "sind:tony/mk7fire");
    mk7FireModel.bindAnimation("sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    });
    mk7FireModel.texture.set(null, "fire");
    mk7fire = renderer.createEffect("fiskheroes:model").setModel(mk7FireModel);
    mk7fire.anchor.set("body");
    mk7fire.anchor.ignoreAnchor(true);

    var braceletsModel = renderer.createResource("MODEL", "sind:tony/tony_rightarm");
    braceletsModel.texture.set("bracelets", null);
    braceletsModel.generateMirror();
    bracelets = renderer.createEffect("fiskheroes:model").setModel(braceletsModel);
    bracelets.anchor.set("rightArm");
    bracelets.setOffset(-5, -2, 0);
    bracelets.mirror = true;

    var displayModel = renderer.createResource("MODEL", "sind:tony/mk7transformation");
    displayModel.bindAnimation("sind:mk7_pod").setData((entity, data) => {
        data.load(1);
    });
    displayModel.texture.set("mk7", "mk7_lights");
    display = renderer.createEffect("fiskheroes:model").setModel(displayModel);
    display.anchor.set("body");
    display.setOffset(0, 0, -6);

    var displayPlatesModel = renderer.createResource("MODEL", "sind:tony/mk7transformation");
    displayPlatesModel.bindAnimation("sind:mk7_pod").setData((entity, data) => {
        data.load(1);
    });
    displayPlatesModel.texture.set("mk7_plates", null);
    displayplates = renderer.createEffect("fiskheroes:model").setModel(displayPlatesModel);
    displayplates.anchor.set("body");
    displayplates.setOffset(0, 0, -6);

    overlay = renderer.createEffect("fiskheroes:overlay");
    display_chestbr = iron_man_utils.createBulkChest(renderer, utils, "display_chest_br", null);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimationWithData(renderer, "iron_man.LAND", "fiskheroes:superhero_landing", "sind:dyn/superhero_landing_timer")
    .priority = -8;

    addAnimationWithData(renderer, "iron_man.ROLL", "fiskheroes:flight/barrel_roll", "fiskheroes:barrel_roll_timer")
    .priority = 16;

    addAnimationWithData(renderer, "sind.LASERS", "fiskheroes:aiming", "fiskheroes:heat_vision_timer")
    .priority = 12;

    addAnimation(renderer, "iron_man.ROCKET", "sind:rocket_aiming").setData((entity, data) => {
        data.load(Math.min(entity.getInterpolatedData("sind:dyn/armgun_timer"), 1));
    }).priority = 13;

    addAnimation(renderer, "summonpose", "sind:summon_pose_mk7").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
        data.load(1, entity.getInterpolatedData("sind:dyn/hulkbuster_arm_timer"));
    }).priority = -11;
    addAnimation(renderer, "mk7", "sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    }).setCondition(entity => entity.getData("sind:dyn/summon7_timer") < 1).priority = 14;
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (entity.getData("sind:dyn/summon7_timer") == 1) {
        parent.render(entity, renderLayer, isFirstPersonArm);
        boosters.render(entity, renderLayer, isFirstPersonArm, true);
        if (!isFirstPersonArm) {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            chin.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            legflapstop.render(entity, renderLayer, isFirstPersonArm);
            legflapsbottom.render(entity, renderLayer, isFirstPersonArm);
            
            if (entity.getData("fiskheroes:suit_open_timer") == 0 && entity.getData("sind:dyn/flares_timer") > 0) {
                flares.render(entity, renderLayer, isFirstPersonArm);
            }
            if (entity.getData("sind:dyn/space7_timer") == 0) {
                chest.render(entity, renderLayer, isFirstPersonArm);
            }
            else {
                chestbr.render(entity, renderLayer, isFirstPersonArm);
                if (entity.getData("sind:dyn/space7_timer") < 1){
                    chestbrflaps.chest.opacity = Math.min(1, -5 * entity.getInterpolatedData("sind:dyn/space7_timer") + 5);
                    chestbrflaps.render(entity, renderLayer, isFirstPersonArm);
                }
            }

            if (entity.getData("sind:dyn/space7_timer") < 1){
                flaps.flaps.opacity = Math.min(1, -5 * entity.getInterpolatedData("sind:dyn/space7_timer") + 5);
                flaps.render(entity, renderLayer, isFirstPersonArm);
                cannon.cannon.opacity = Math.min(1, -5 * entity.getInterpolatedData("sind:dyn/space7_timer") + 5);
                cannon.render(entity, renderLayer, isFirstPersonArm);
            }
        }
        unibeam.render(entity, isFirstPersonArm);
        if(entity.getData("sind:dyn/space7_timer") < 0.8){
            rockets2.render(entity, renderLayer, isFirstPersonArm);
        }
        if (entity.getData("fiskheroes:suit_open_timer") == 0 && entity.getData("fiskheroes:heat_vision_timer") > 0) {
            laser.render(entity, renderLayer, isFirstPersonArm);
        }
    } else if (entity.getData("sind:dyn/summon7_timer") < 1) {
        if (!entity.is("DISPLAY")) {
            bracelets.render();
        }
        if (entity.getData("sind:dyn/summon7_timer") > 0 && !isFirstPersonArm) {
            mk7.render();
            if (entity.getData("sind:dyn/summon7_timer") < 0.65 / 4) {
                mk7plates.opacity = 1 - Math.min(1, Math.max(0, (80 * entity.getInterpolatedData("sind:dyn/summon7_timer") - 12)));
                mk7plates.render();
            }
            if (entity.getData("sind:dyn/summon7_timer") < 1.1 / 4) {
                mk7fire.render();
            }
        }
    }
    hud.render(entity, renderLayer, isFirstPersonArm);
    if (entity.getData("sind:dyn/space7_timer") < 1){
        hud2.render(entity, renderLayer, isFirstPersonArm);
        hud3.render(entity, renderLayer, isFirstPersonArm);
        hud4.render(entity, renderLayer, isFirstPersonArm);
    } else {
        hud5.render(entity, renderLayer, isFirstPersonArm);
        hud6.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
    if (entity.is("DISPLAY")) {
        var block = entity.world().blockAt(entity.pos().subtract(0, 1, 0)).name();
        if (block == "minecraft:gold_block") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            chin.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            chest.render(entity, renderLayer, isFirstPersonArm);
            cannon.render(entity, renderLayer, isFirstPersonArm);
            flaps.render(entity, renderLayer, isFirstPersonArm);
            rockets2.render(entity, renderLayer, isFirstPersonArm);
            legflapstop.render(entity, renderLayer, isFirstPersonArm);
            legflapsbottom.render(entity, renderLayer, isFirstPersonArm);
            overlay.texture.set("suit", entity.getData('fiskheroes:mask_open_timer') == 0 ? "lights" : "lights_noeyes");
            overlay.render();
        } else if (block == "minecraft:diamond_block") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            chin.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            legflapstop.render(entity, renderLayer, isFirstPersonArm);
            legflapsbottom.render(entity, renderLayer, isFirstPersonArm);
            display_chestbr.render(entity, renderLayer, isFirstPersonArm);
            overlay.texture.set("display_space_suit", entity.getData('fiskheroes:mask_open_timer') == 0 ? "lights" : "lights_noeyes");
            overlay.render();
        } else if (block == "minecraft:iron_block" || entity.as("DISPLAY").getDisplayType() != "HOLOGRAM" ) {
            bracelets.render();
        } else {
            display.render();
            displayplates.render();
        }
    }
}




