extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark25/mark25_layer1",
    "layer2": "sind:mark25/mark25_layer2",
    "hammer": "sind:mark25/mark25_hammers",
    "lights": "sind:lights/lights_rectangle",
    "suit": "sind:mark25/mark25_suit.tx.json",
    "mask": "sind:mark25/mark25_mask.tx.json",
    "flaps": "sind:mark25/mark25_flaps.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark25/full",
    "player_mh": "sind:hud/mark25/mh",
    "player0": "sind:hud/mark25/0",
    "player1": "sind:hud/mark25/1",
    "player2": "sind:hud/mark25/2",
    "player3": "sind:hud/mark25/3",
    "h_hammer": "sind:hud/mark25/hammers",
    "h_hammer1": "sind:hud/mark25/w_hammers",
    "h_hammer_mh": "sind:hud/mark25/mh_hammers",
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("fiskheroes:external/iron_man_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var metal_heat;
var helmet;
var reactor, reactor2, reactor1;
var accessories;
var rh;
var lh;
var unibeam;
var flaps;

var jarvis = implement("sind:external/jarvis");
var hud, hud2, hud3, hud4;

function initEffects(renderer) {
    parent.initEffects(renderer);
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.35);
    
    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    var rh = utils.createModel(renderer, "sind:mk25/jackhammer", "hammer", null);
    rh.bindAnimation("sind:hammers").setData((entity, data) => {
        var eq = Math.max(0, Math.max(entity.getInterpolatedData("fiskheroes:aiming_timer"), (Math.min(1, 2*entity.getInterpolatedData("fiskheroes:flight_timer")))) - Math.max(entity.getInterpolatedData("sind:dyn/ground_smash_timer"), entity.getInterpolatedData("sind:dyn/ground_smash_use_timer")));
        data.load(0, eq);
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(10, 1); // 1 for Right, -1 for Left
    });

    var lh = utils.createModel(renderer, "sind:mk29/jackhammer", "hammer", null);
    lh.bindAnimation("sind:hammers").setData((entity, data) => {
        var eq = Math.max(0, Math.min(1, 2*entity.getInterpolatedData("fiskheroes:flight_timer")) - Math.max(entity.getInterpolatedData("sind:dyn/ground_smash_timer"), entity.getInterpolatedData("sind:dyn/ground_smash_use_timer")));
        data.load(0, eq);
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(10, -1); // 1 for Right, -1 for Left
    });

    reactor = renderer.createEffect("fiskheroes:model").setModel(rh);
    reactor.anchor.set("rightArm");
    reactor.setOffset(-5, -2, 0);

    reactor2 = renderer.createEffect("fiskheroes:model").setModel(lh);
    reactor2.anchor.set("leftArm");
    reactor2.setOffset(5, -2, 0);

    reactor1 = renderer.createEffect("fiskheroes:model");
    reactor1.setModel(utils.createModel(renderer, "sind:mk25/reactor", "layer1", null));
    reactor1.anchor.set("body");

    var flapmodel = utils.createModel(renderer, "sind:flaps25", "flaps", null);
    flapmodel.bindAnimation("sind:mk25_flaps").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        var inv = 1 - entity.getInterpolatedData("sind:dyn/flight_boost_timer");
        var eq = Math.sin(Math.PI*inv); 
        var eq2 = -2*inv + 2
        var timer = inv > 0.5 ? eq2 : eq; 
        data.load(1, Math.max(entity.getInterpolatedData("sind:dyn/superhero_landing_timer"), (entity.getData("fiskheroes:flying") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"))) ? timer : 0));
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(3, entity.loop(50));
    });
    flaps = renderer.createEffect("fiskheroes:model").setModel(flapmodel);
    flaps.anchor.set("body");

    var shake2 = renderer.bindProperty("fiskheroes:camera_shake").setCondition(entity => {
        shake2.factor = 4.0 * entity.getInterpolatedData("sind:dyn/ground_smash_use_timer");
        shake2.intensity = 0;
        return true;
    });
    utils.bindParticles(renderer, "fiskheroes:iron_man").setCondition(entity => entity.getData("fiskheroes:flying"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 3.0, -3],
                "size": [0.75, 1.75]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));
    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, reactor1, reactor, reactor2, flaps);

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF, 20);
    hud2 = jarvis.createComponent(renderer, utils, "mk25reactor", "player", 1);
    hud3 = jarvis.createComponent(renderer, utils, "mk25righthammer", "h_hammer", 1);
    hud4 = jarvis.createComponent(renderer, utils, "mk25lefthammer", "h_hammer", 1);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("iron_man.LAND");
    addAnimationWithData(renderer, "iron_man.LAND3", "sind:ironman_landing", "sind:dyn/superhero_landing_timer")
    .priority = -8;
    addAnimation(renderer, "sind.GROUND_SMASH", "sind:ground_smash").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/ground_smash_timer"));
        data.load(1, Math.min(entity.getInterpolatedData("sind:dyn/ground_smash_use_timer") * 4, 1));
    });
    addAnimation(renderer, "dual.PUNCH", "sind:dual_punch")
        .setData((entity, data) => {
            data.load(entity.isPunching() ? 1 : 0);
        })
        .priority = -8;
    addAnimationWithData(renderer, "clamping", "sind:feetlock", "sind:dyn/clamp_timer")
        .priority = -7;
}

function render(entity, renderLayer, isFirstPersonArm) {
    parent.render(entity, renderLayer, isFirstPersonArm);
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "CHESTPLATE") {
            reactor1.render();
            flaps.render();
        }
    }
    if(renderLayer == "CHESTPLATE"){
        reactor.render();
        reactor2.render();
        unibeam.render(entity, isFirstPersonArm);
    }
    if(renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud2.render(entity, renderLayer, isFirstPersonArm);
        hud3.render(entity, renderLayer, isFirstPersonArm);
        hud4.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}
