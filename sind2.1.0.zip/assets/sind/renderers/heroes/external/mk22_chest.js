var utils;
var metal_heat;
function create(renderer, texture, lights) {
    var gun = renderer.createResource("MODEL", "sind:wm2/gun")
    gun.bindAnimation("sind:wm2").setData((entity, data) => {
        data.load(0, 1-entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        data.load(1, entity.getInterpolatedData("sind:dyn/sentry_timer"));
    });
    gun.texture.set(texture, lights);

    var gunsEffect = renderer.createEffect("fiskheroes:model").setModel(gun);
    gunsEffect.anchor.set("body");

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(gunsEffect);
    return {
        gunsEffect: gunsEffect,
        render: (entity) => {
            gunsEffect.render();
        
            metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
            metal_heat.render();
        }
    };

}


