extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark33/mark33_layer1",
    "layer2": "sind:mark33/mark33_layer2",
    "lights": "sind:lights/lights_triangle",
    "suit": "sind:mark33/mark33_suit.tx.json",
    "blade": "sind:mark33/blade",
    "mask": "sind:mark33/mark33_mask.tx.json",
    "shoulder": "sind:mark33/mark33_shoulder.tx.json",
    "flaps": "sind:mark33/mark33_flaps.tx.json",
    "legflap_bottom": "sind:mark33/mark33_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark33/mark33_legflaps_top.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark33/full",
    "player_mh": "sind:hud/mark33/mh",
    "player0": "sind:hud/mark33/0",
    "player1": "sind:hud/mark33/1",
    "player2": "sind:hud/mark33/2",
    "player3": "sind:hud/mark33/3",

    "h_shoulders": "sind:hud/mark33/shoulder",
    "h_shoulders1": "sind:hud/mark33/w_shoulder",
    "h_shoulders_mh": "sind:hud/mark33/mh_shoulder",
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("fiskheroes:external/iron_man_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var unibeam;

var helmet;
var reactor;
var reactor1;
var accessories;
var rshoulder;
var metal_heat;
var leftArm;
var repulsor;
var flaps;

var jarvis = implement("sind:external/jarvis");
var hud, hud2, hud3;

var legflapsbottom, legflapstop;

var blade;

function range(){
    return 25;
}

function initEffects(renderer) {
    repulsor = renderer.createEffect("fiskheroes:overlay");
    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.35);
    
    flares = iron_man_utils.createFlares(renderer, utils, "layer2", null);

    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    reactor = renderer.createEffect("fiskheroes:model");
    reactor.setModel(utils.createModel(renderer, "sind:mk33/reactor", "layer1", null));
    reactor.anchor.set("body");

    var shoulderr = utils.createModel(renderer, "sind:mk33/shoulderright", "shoulder", null);
    shoulderr.generateMirror();

    rshoulder = renderer.createEffect("fiskheroes:model").setModel(shoulderr);
    rshoulder.anchor.set("rightArm");
    rshoulder.mirror = true;
    rshoulder.setOffset(-5, -2, 0);

    blade = renderer.createEffect("fiskheroes:shield");
    blade.texture.set("blade");
    blade.anchor.set("rightArm");
    blade.mirror = true;

    var leftArmModel = utils.createModel(renderer, "sind:leftArm", "layer1", null);
    leftArm = renderer.createEffect("fiskheroes:model").setModel(leftArmModel);
    leftArm.anchor.ignoreAnchor(true);
    leftArm.anchor.set("rightArm");
    leftArm.setRotation(-90, 90, 0);

    var flapmodel = utils.createModel(renderer, "sind:flaps25", "flaps", null);
    flapmodel.bindAnimation("sind:mk45_flaps").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        var inv = 1 - entity.getInterpolatedData("sind:dyn/flight_boost_timer");
        var eq = Math.sin(Math.PI*inv); 
        var eq2 = -2*inv + 2
        var timer = inv > 0.5 ? eq2 : eq; 
        data.load(1, Math.max(entity.getInterpolatedData("sind:dyn/superhero_landing_timer"), (entity.getData("fiskheroes:flying") && !(entity.isSprinting() && entity.getData("fiskheroes:flying"))) ? timer : 0));
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(3, entity.loop(50));
    });
    flaps = renderer.createEffect("fiskheroes:model").setModel(flapmodel);
    flaps.anchor.set("body");

    legflapsbottom = iron_man_utils.createLegFlaps(renderer, utils, "legflap_bottom", null);
    legflapstop = iron_man_utils.createLegFlaps(renderer, utils, "legflap_top", null);

    utils.bindParticles(renderer, "fiskheroes:iron_man").setCondition(entity => entity.getData("fiskheroes:flying"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 2.75, -3],
                "size": [1.5, 1.5]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -7.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]).setCondition(entity => entity.getData("sind:dyn/punch_decider") == 0 || entity.getData("sind:dyn/punch_decider") == 2);

    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "leftArm", 0xFFC462, [
        { "firstPerson": [4.5, 3.75, -7.0], "offset": [0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]).setCondition(entity => entity.getData("sind:dyn/punch_decider") == 1 || entity.getData("sind:dyn/punch_decider") == 2);

    utils.bindBeam(renderer, "fiskheroes:energy_projection", "sind:rockets1", "head", 0xFFFFFF, [{
            "offset": [4.0, 0.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [-4.0, 0.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [3.0, 0.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [-3.0, 0.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [4.0, 1.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [-4.0, 1.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [3.0, 1.0, 3.0],
            "size": [0.25, 0.25]
        }, {
            "offset": [-3.0, 1.0, 3.0],
            "size": [0.25, 0.25]
        }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
    
    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, rshoulder, blade, reactor, flares.flares, leftArm, flaps,
        legflapsbottom.legflapsleft, legflapsbottom.legflapsright, legflapstop.legflapsleft, legflapstop.legflapsright
    );

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF, range());
    hud2 = jarvis.createComponent(renderer, utils, "mk33reactor", "player", 1);
    hud3 = jarvis.createComponent(renderer, utils, "mk33shoulders", "h_shoulders", 1);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("iron_man.LAND");
    renderer.removeCustomAnimation("basic.BLOCKING");
    renderer.removeCustomAnimation("basic.AIMING");
    addAnimationWithData(renderer, "sentry.AIMING", "fiskheroes:aiming", "fiskheroes:aiming_timer")
        .setCondition(entity => !entity.getHeldItem().doesNeedTwoHands() && !entity.getHeldItem().isRifle() && entity.is("OWNABLE"))
        .priority = 10;
    addAnimationWithData(renderer, "basic.AIMING", "fiskheroes:aiming", "sind:dyn/punch_right_timer")
        .setCondition(entity => !entity.getHeldItem().doesNeedTwoHands() && !entity.getHeldItem().isRifle())
        .priority = 10;
    addAnimationWithData(renderer, "basic.AIMING2", "sind:left_aiming", "sind:dyn/punch_left_timer")
        .setCondition(entity => !entity.getHeldItem().doesNeedTwoHands() && !entity.getHeldItem().isRifle())
        .priority = 10;
    addAnimationWithData(renderer, "iron_man.LAND3", "fiskheroes:superhero_landing", "sind:dyn/superhero_landing_timer").setCondition(entity => !entity.getData("fiskheroes:blade"))
    .priority = -8;
    addAnimationWithData(renderer, "iron_man.LAND2", "sind:ironman_landing", "sind:dyn/superhero_landing_timer").setCondition(entity => entity.getData("fiskheroes:blade"))
    .priority = -8;

    addAnimation(renderer, "dual.PUNCH", "sind:dual_punch")
        .setData((entity, data) => {
            data.load(entity.isPunching() ? entity.getInterpolatedData("fiskheroes:blade_timer") : 0);
        })
        .priority = -8;
}

function render(entity, renderLayer, isFirstPersonArm) {
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "CHESTPLATE") {
            rshoulder.render();
            reactor.render();
            flaps.render();
            if (entity.is("OWNABLE")) {
                repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
            } else{
                repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("sind:dyn/punch_right_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
            }
            repulsor.texture.set(null, "repulsor");
            repulsor.render();
            repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("sind:dyn/punch_left_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer"));
            repulsor.texture.set(null, "repulsor_left");
            repulsor.render();
        } else if (renderLayer == "LEGGINGS"){
            legflapstop.render(entity, renderLayer, isFirstPersonArm);
            if (entity.getData("fiskheroes:suit_open_timer") == 0 && entity.getData("sind:dyn/flares_timer") > 0) {
                flares.render(entity, renderLayer, isFirstPersonArm);
            }
        } else if( renderLayer == "BOOTS"){
            legflapsbottom.render(entity, renderLayer, isFirstPersonArm);
            repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
            repulsor.texture.set(null, "repulsor_boots");
            repulsor.render();
        }
    }
    if(renderLayer == "CHESTPLATE"){
        blade.unfold = entity.getInterpolatedData("fiskheroes:blade_timer");
        var f = Math.min(blade.unfold * 5, 1);
        blade.setOffset(2.9 + 0.1 * f, 3.0 + 7.0 * f, 0.0);
        blade.render();
        unibeam.render(entity, isFirstPersonArm);

        if (entity.getData("sind:dyn/punch_left_timer") > 0 && isFirstPersonArm) {
            leftArm.setOffset(-9, 13.9, 15 - Math.min(1, entity.getInterpolatedData("sind:dyn/punch_left_timer")) * 15);
            leftArm.render();
        }
    }
    if(renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud2.render(entity, renderLayer, isFirstPersonArm);
        hud3.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}
