extend("sind:mark26");
loadTextures({
    "lights": "sind:lights/lights_g_rectangle",
    "mask": "sind:mark26/mark26_g_mask.tx.json"
});

