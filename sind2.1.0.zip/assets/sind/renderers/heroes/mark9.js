extend("sind:external/advanced_lasers");
loadTextures({
    "layer1": "sind:mark9/mark9_layer1.tx.json",
    "layer2": "sind:mark9/mark9_layer2",
    "suit": "sind:mark9/mark9_suit.tx.json",
    "mask": "sind:mark9/mark9_mask.tx.json",
    "chin": "sind:null",
    "rocket": "sind:mark7/mark7_rocket.tx.json",
    "chest": "sind:mark7/mark7_chest",
    "cannons": "sind:mark9/mark9_cannon",
    "flaps": "sind:mark9/mark9_flaps.tx.json",
    "laser": "sind:mark7/mark7_laser",

    //jarvis stuff
    "player": "sind:hud/mark9/full",
    "player_mh": "sind:hud/mark9/mh",
    "player0": "sind:hud/mark33/0",
    "player1": "sind:hud/mark9/1",
    "player2": "sind:hud/mark17/2",
    "player3": "sind:hud/mark17/3",
});
