extend("sind:mark46");
loadTextures({
    "layer1": "sind:mark46/mark46_concept_layer1",
    "layer2": "sind:mark46/mark46_concept_layer2",
    "suit": "sind:mark46/mark46_concept_suit.tx.json",
    "mask": "sind:mark46/mark46_concept_helmet.tx.json",

    "rocket": "sind:mark46/mark46_concept_rocket.tx.json",
    "flaps": "sind:mark46/mark46_concept_flaps.tx.json"
});