extend("sind:mark8");
loadTextures({
    "layer1": "sind:mark31/mark31_layer1.tx.json",
    "layer2": "sind:mark31/mark31_layer2",
    "suit": "sind:mark31/mark31_suit.tx.json",
    "mask": "sind:mark33/mark33_mask.tx.json",
    "chin": "sind:null",
    "rocket": "sind:mark31/mark31_rocket.tx.json",
    "chest": "sind:mark31/mark31_chest",
    "cannons": "sind:mark31/mark31_cannon",
    "flaps": "sind:mark31/mark31_flaps.tx.json",
    "laser": "sind:mark31/mark31_laser",
    "legflap_bottom": "sind:mark31/mark31_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark31/mark31_legflaps_top.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark31/full",
    "player_mh": "sind:hud/mark31/mh",
    "player0": "sind:hud/mark33/0",
});

function range(){
    return 20;
}



