extend("sind:equip_mind_stone");
