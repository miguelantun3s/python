extend("sind:external/advanced_lasers");
loadTextures({
    "layer1": "sind:mark12/mark12_layer1",
    "layer2": "sind:mark12/mark12_layer2",
    "suit": "sind:mark12/mark12_suit.tx.json",
    "mask": "sind:mark22/mark22_mask.tx.json",
    "chin": "sind:null",
    "rocket": "sind:null",
    "chest": "sind:mark12/mark12_chest",
    "cannons": "sind:mark12/mark12_cannon",
    "flaps": "sind:mark12/mark12_flaps.tx.json",

    //jarvis stuff
    "player": "sind:hud/mark12/full",
    "player_mh": "sind:hud/mark12/mh",
    "player0": "sind:hud/wm2/0",
    "player1": "sind:hud/mark12/1",
    "player2": "sind:hud/mark12/2",
    "player3": "sind:hud/mark40/3"
});