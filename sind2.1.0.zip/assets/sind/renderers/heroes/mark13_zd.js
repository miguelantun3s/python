extend("sind:mark13");
loadTextures({
    "layer1": "sind:mark13/mark13_zd_layer1",
    "layer2": "sind:mark13/mark13_zd_layer2",
    "suit": "sind:mark13/mark13_zd_suit.tx.json",
    "mask": "sind:mark13/mark13_zd_mask.tx.json",
    "chin": "sind:mark13/mark13_zd_chin",
    "chest": "sind:mark13/mark13_zd_chest",
    "cannons": "sind:mark13/mark13_zd_cannon",
    "flaps": "sind:mark13/mark13_zd_flaps.tx.json",
    "legflap_bottom": "sind:mark13/mark13_zd_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark13/mark13_zd_legflaps_top.tx.json",
});