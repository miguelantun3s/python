extend("sind:mark37");
loadTextures({
    "layer1": "sind:mark37/mark37_concept_layer1.tx.json",
    "layer2": "sind:mark37/mark37_concept_layer2",
    "chest": "sind:mark37/mark37_concept_chest",
    "chest2": "sind:mark37/mark37_concept_chest2",
    "gauntlets": "sind:mark37/mark37_concept_gauntlets",
    "suit": "sind:mark37/mark37_concept_suit.tx.json",
    "back": "sind:mark37/mark37_concept_back.tx.json",
    "mask": "sind:mark37/mark37_concept_mask.tx.json",
});