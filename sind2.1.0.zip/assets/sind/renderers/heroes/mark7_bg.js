extend("sind:mark7");
loadTextures({
    "layer1": "sind:mark7/mark7_bg_layer1.tx.json",
    "layer2": "sind:mark7/mark7_bg_layer2",
    "suit": "sind:mark7/mark7_bg_suit.tx.json",
    "chin": "sind:mark5/mark5_ev_chin",
    "rocket": "sind:mark7/mark7_bg_rocket.tx.json",
    "chest": "sind:mark7/mark7_bg_chest",
    "cannons": "sind:mark7/mark7_bg_cannon",
    "flaps": "sind:mark12/mark12_flaps.tx.json",
    "laser": "sind:mark20/mark20_laser",
    "legflap_bottom": "sind:mark7/mark7_bg_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark7/mark7_bg_legflaps_top.tx.json",
});





