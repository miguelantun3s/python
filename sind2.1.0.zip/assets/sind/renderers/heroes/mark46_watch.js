extend("sind:external/hero_basic");
loadTextures({
    "watch_base": "sind:mark46_watch/watch_base",
    "watch_complete": "sind:mark46_watch/watch_complete",
    "watch_anim": "sind:mark46_watch/watch.tx.json",
    "watch_lights": "sind:mark46_watch/watch_lights",
    "null": "sind:null"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") {
            var timer = entity.getInterpolatedData("sind:dyn/nanite_timer");
            return timer == 0 ? "watch_base" : timer < 1 ? "watch_anim" : "watch_complete";
        }
        return "watch_complete";
    });
    renderer.setLights((entity, renderLayer) => {
        if ((Math.ceil(8 * entity.getInterpolatedData('sind:dyn/nanite_timer')) | 0) > 0) {
            return "watch_lights";
        }
        return "null";
    });
}

function initAnimations(renderer) {
    addAnimation(renderer, "iron_man.ROCKET", "sind:rocket_aiming").setData((entity, data) => {
        data.load(Math.min(entity.getInterpolatedData("sind:dyn/beam_charging_timer2"), 1));
    }).priority = 14;
    addAnimationWithData(renderer, "sind.QUANTUM", "sind:watch", "sind:dyn/nanite_timer").priority = 11;
}