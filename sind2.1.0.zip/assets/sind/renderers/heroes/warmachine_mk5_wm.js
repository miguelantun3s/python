extend("sind:warmachine_mk5_r");
loadTextures({
    "layer1": "sind:wm5_wm/wm_layer1",
    "layer2": "sind:wm5_wm/wm_layer2",
    "suit": "sind:wm5_wm/wm_suit.tx.json",
    "mask": "sind:wm5_wm/wm_helmet.tx.json",
    "armgun": "sind:wm5_wm/wm_armgun.tx.json",
    "chest": "sind:wm5_wm/wm_chest.tx.json"
});