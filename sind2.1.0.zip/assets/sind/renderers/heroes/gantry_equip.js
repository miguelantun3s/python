extend("sind:tony_equip");
