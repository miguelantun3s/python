extend("sind:mark25");
loadTextures({
    "lights": "sind:lights/lights_g_rectangle",
    "mask": "sind:mark25/mark25_g_mask.tx.json"
});

