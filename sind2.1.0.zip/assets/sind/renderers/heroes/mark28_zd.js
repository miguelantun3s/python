extend("sind:mark28");
loadTextures({
    "layer1": "sind:mark28/mark28_zd_layer1",
    "layer2": "sind:mark28/mark28_zd_layer2",
    "suit": "sind:mark28/mark28_zd_suit.tx.json",
    "mask": "sind:mark28/mark28_zd_mask.tx.json",
    "chest": "sind:mark28/mark28_zd_chest",
    "cannons": "sind:mark28/mark28_zd_cannon",
});