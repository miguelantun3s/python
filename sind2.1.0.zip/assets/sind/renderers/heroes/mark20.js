extend("sind:mark9");
loadTextures({
    "layer1": "sind:mark20/mark20_layer1.tx.json",
    "layer2": "sind:mark20/mark20_layer2",
    "suit": "sind:mark20/mark20_suit.tx.json",
    "rocket": "sind:mark20/mark20_rocket.tx.json",
    "chest": "sind:mark20/mark20_chest",
    "cannons": "sind:mark20/mark20_cannon",
    "flaps": "sind:mark12/mark12_flaps.tx.json",
    "laser": "sind:mark20/mark20_laser",

    //jarvis stuff
    "player": "sind:hud/mark20/full",
    "player_mh": "sind:hud/mark20/mh",
    "player1": "sind:hud/mark7/1"
});
function range(){
    return 20;
}

