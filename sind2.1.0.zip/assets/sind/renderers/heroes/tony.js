extend("sind:external/hero_basic");
loadTextures({
    "null": "sind:null",
    //tony textures
    "tony_layer1": "sind:tony/tony_layer1",
    "tony_layer2": "sind:tony/tony_layer2",
    "glasses": "sind:tony/glasses",
    "glasses_lights": "sind:tony/glasses_lights",
    "bracelets": "sind:tony/mark7_bracelets",
    //hud stuff
    "hud": "sind:hud/hud",
    "radar": "sind:hud/hud_radar",
    "radius": "sind:hud/hud_overlay",
    "warning": "sind:hud/hud_warning",
    "hud_mask": "sind:null",
    "player": "sind:null",
    "player_mh": "sind:null",
    "player0": "sind:null",
    "player1": "sind:null",
    "player2": "sind:null",
    "player3": "sind:null",

    //mark1
    "mk1": "sind:tony/mark1",
    "mk1_lights": "sind:tony/mark1_lights",
    "mk1_gold": "sind:tony/mark1_gold",
    "stanlee": "sind:tony/stanlee",

    //mark7
    "mk7": "sind:tony/mark7",
    "mk7_lights": "sind:tony/mark7_lights",
    "mk7_plates": "sind:tony/mark7_plates",

    //suit textures
    "fire": "sind:repulsor_layer.tx.json",
    "repulsor": "fiskheroes:iron_man_repulsor",
    "repulsor_left": "fiskheroes:iron_man_repulsor_left",
    "repulsor_boots": "fiskheroes:iron_man_repulsor_boots",
    //lights
    "lights": "sind:lights/lights",
    "lights_rectangle": "sind:lights/lights_rectangle",
    "lights_g_rectangle": "sind:lights/lights_g_rectangle",
    "lights_triangle": "sind:lights/lights_triangle",
    "lights_mk16": "sind:mark16/mark16_lights.tx.json",
    "lights_mk22": "sind:mark22/mark22_lights",
    "lights_mk35": "sind:mark35/mark35_lights",
    "lights_mk37": "sind:mark37/mark37_lights",
    "lights_mk46": "sind:lights/lights.tx.json",
    "lights_mk49": "sind:mark49/mark49_lights_suit.tx.json",
    "lights_wm2": "sind:wm2/wm_lights",
    "lights_wm2_r": "sind:wm2_r/wm_lights",
    "lights_wm2_aou": "sind:wm2_r/wm_aou_lights",
    "lights_mk40h": "sind:mark40/harley/mark40_lights",
    "lights_wm3": "sind:wm3/wm_lights",
    "lights_wm3h": "sind:wm3_h/wm_lights",
    "lights_wm3s": "sind:wm3_s/wm_lights.tx.json",
    "lights_wm4": "sind:wm4/wm_lights.tx.json",
    "lights_wm4r": "sind:wm4_r/wm_lights.tx.json",
    "lights_wm5": "sind:wm5/wm_lights.tx.json",
    "lights_wm5r": "sind:wm5_r/wm_lights.tx.json",
    "lights_wm6": "sind:wm6/wm_lights.tx.json",
    //suits
    "mark7": "sind:mark7/mark7_suit.tx.json", "mark7_mask": "sind:mark3/mark3_mask_false", "mark7_chest": "sind:mark7/mark7_chest", "mark7_cannon": "sind:mark7/mark7_cannon", "mark7_flaps": "sind:mark7/mark7_flaps.tx.json", "mark7_chin": "sind:mark4/mark4_chin", "mark7_legflap_bottom": "sind:mark7/mark7_legflaps_bottom.tx.json", "mark7_legflap_top": "sind:mark7/mark7_legflaps_top.tx.json",
    "mark8": "sind:mark8/mark8_suit.tx.json", "mark8_mask": "sind:mark3/mark3_mask_false", "mark8_chest": "sind:mark8/mark8_chest", "mark8_cannon": "sind:mark8/mark8_cannon", "mark8_flaps": "sind:mark8/mark8_flaps.tx.json", "mark8_chin": "sind:mark4/mark4_chin", "mark8_legflap_bottom": "sind:mark33/mark33_legflaps_bottom.tx.json", "mark8_legflap_top": "sind:mark8/mark8_legflaps_top.tx.json",
    "mark9": "sind:mark9/mark9_suit.tx.json", "mark9_mask": "sind:mark9/mark9_mask_false", "mark9_chest": "sind:mark7/mark7_chest", "mark9_cannon": "sind:mark9/mark9_cannon", "mark9_flaps": "sind:mark9/mark9_flaps.tx.json", 
    "mark10": "sind:mark10/mark10_suit.tx.json", "mark10_mask": "sind:mark3/mark3_mask_false", "mark10_chest": "sind:mark10/mark10_chest", "mark10_flaps": "sind:mark9/mark9_flaps.tx.json", "mark10_chin": "sind:mark4/mark4_chin",
    "mark11": "sind:mark11/mark11_suit.tx.json", "mark11_mask": "sind:mark17/mark17_mask_false", "mark11_chest": "sind:mark11/mark11_chest", "mark11_cannon" : "sind:mark7/mark7_cannon" , "mark11_flaps": "sind:mark11/mark11_flaps.tx.json",
    "mark12": "sind:mark12/mark12_suit.tx.json", "mark12_mask": "sind:mark22/mark22_mask_false", "mark12_chest": "sind:mark12/mark12_chest", "mark12_cannon": "sind:mark12/mark12_cannon", "mark12_flaps": "sind:mark12/mark12_flaps.tx.json",
    "mark13": "sind:mark13/mark13_suit.tx.json", "mark13_mask": "sind:mark2/mark2_mask_false", "mark13_chest": "sind:mark13/mark13_chest", "mark13_cannon": "sind:mark13/mark13_cannon", "mark13_flaps": "sind:mark13/mark13_flaps.tx.json", "mark13_chin": "sind:mark13/mark13_chin", "mark13_legflap_bottom": "sind:mark13/mark13_legflaps_bottom.tx.json", "mark13_legflap_top": "sind:mark13/mark13_legflaps_top.tx.json",
    "mark14": "sind:mark14/mark14_suit.tx.json", "mark14_mask": "sind:mark14/mark14_mask_false", "mark14_chest": "sind:mark14/mark14_chest", "mark14_cannon": "sind:mark13/mark13_cannon", "mark14_flaps": "sind:mark14/mark14_flaps.tx.json", 
    "mark15": "sind:mark15/mark15_suit.tx.json", "mark15_mask": "sind:mark15/mark15_mask_false", "mark15_reactor": "sind:mark15/mark15_chest",
    "mark16": "sind:mark16/mark16_suit.tx.json", "mark16_mask": "sind:mark16/mark16_mask_false", "mark16_fins": "sind:mark16/mark16_fins",
    "mark17": "sind:mark17/mark17_suit.tx.json", "mark17_mask": "sind:mark17/mark17_mask_false", "mark17_reactor": "sind:mark17/mark17_chest", "mark17_reactor_lights": "sind:mark17/mark17_chest_lights",
    "mark18": "sind:mark18/mark18_suit.tx.json", "mark18_mask": "sind:mark3/mark3_mask_false", "mark18_reactor": "sind:mark18/mark18_chest", "mark18_chest2": "sind:mark18/mark18_chest2", "mark18_cannon": "sind:mark7/mark7_cannon", "mark18_flaps": "sind:mark8/mark8_flaps.tx.json", "mark18_chin": "sind:mark4/mark4_chin",
    "mark19": "sind:mark19/mark19_suit.tx.json", "mark19_mask": "sind:mark19/mark19_mask_false", "mark19_chest": "sind:mark19/mark19_chest", "mark19_flaps": "sind:mark9/mark9_flaps.tx.json", "mark19_chin": "sind:mark19/mark19_chin",
    "mark20": "sind:mark20/mark20_suit.tx.json", "mark20_mask": "sind:mark9/mark9_mask_false", "mark20_chest": "sind:mark20/mark20_chest", "mark20_cannon": "sind:mark20/mark20_cannon", "mark20_flaps": "sind:mark12/mark12_flaps.tx.json",
    "mark21": "sind:mark21/mark21_suit.tx.json", "mark21_mask": "sind:mark21/mark21_mask_false", "mark21_chest": "sind:mark21/mark21_chest", "mark21_cannon": "sind:mark21/mark21_cannon", "mark21_flaps": "sind:mark21/mark21_flaps.tx.json", "mark21_chin": "sind:mark21/mark21_chin", "mark21_legflap_bottom": "sind:mark21/mark21_legflaps_bottom.tx.json", "mark21_legflap_top": "sind:mark21/mark21_legflaps_top.tx.json",
    "mark22": "sind:mark22/mark22_suit.tx.json", "mark22_mask": "sind:mark22/mark22_mask_false", "mark22_chest": "sind:mark22/mark22_chest.tx.json",
    "mark23": "sind:mark23/mark23_suit.tx.json", "mark23_mask": "sind:mark23/mark23_mask_false",
    "mark24": "sind:mark24/mark24_suit.tx.json", "mark24_mask": "sind:mark24/mark24_mask_false", "mark24_reactor": "sind:mark24/mark24_chest",
    "mark25": "sind:mark25/mark25_suit.tx.json", "mark25_mask": "sind:mark25/mark25_mask_false", "mark25_hammer": "sind:mark25/mark25_hammers", "mark25_flaps": "sind:mark25/mark25_flaps.tx.json",
    "mark26": "sind:mark26/mark26_suit.tx.json", "mark26_mask": "sind:mark26/mark26_mask_false", "mark26_hammer": "sind:mark26/mark26_hammers", "mark26_flaps": "sind:mark26/mark26_flaps.tx.json",
    "mark27": "sind:mark27/mark27_suit.tx.json", "mark27_mask": "sind:mark27/mark27_mask_false", "mark27_chest": "sind:mark27/mark27_chest", "mark27_cannon": "sind:mark27/mark27_cannon", "mark27_flaps": "sind:mark27/mark27_flaps.tx.json",
    "mark28": "sind:mark28/mark28_suit.tx.json", "mark28_mask": "sind:mark28/mark28_mask_false", "mark28_chest": "sind:mark28/mark28_chest", "mark28_cannon": "sind:mark28/mark28_cannon", "mark28_flaps": "sind:mark28/mark28_flaps.tx.json",
    "mark29": "sind:mark29/mark29_suit.tx.json", "mark29_mask": "sind:mark2/mark2_mask_false", "mark29_reactor": "sind:mark29/mark29_chest", "mark29_hammer": "sind:mark29/mark29_hammers", "mark29_chin": "sind:mark13/mark13_chin",
    "mark30": "sind:mark30/mark30_suit.tx.json", "mark30_mask": "sind:mark33/mark33_mask_false", "mark30_shoulder": "sind:mark30/mark30_shoulder.tx.json", "mark30_flaps": "sind:mark30/mark30_flaps.tx.json", "mark30_legflap_bottom": "sind:mark30/mark30_legflaps_bottom.tx.json", "mark30_legflap_top": "sind:mark30/mark30_legflaps_top.tx.json",
    "mark31": "sind:mark31/mark31_suit.tx.json", "mark31_mask": "sind:mark33/mark33_mask_false", "mark31_chest": "sind:mark31/mark31_chest", "mark31_cannon": "sind:mark31/mark31_cannon", "mark31_flaps": "sind:mark31/mark31_flaps.tx.json", "mark31_legflap_bottom": "sind:mark31/mark31_legflaps_bottom.tx.json", "mark31_legflap_top": "sind:mark31/mark31_legflaps_top.tx.json",
    "mark32": "sind:mark32/mark32_suit.tx.json", "mark32_mask": "sind:mark32/mark32_mask_false", "mark32_reactor": "sind:mark32/mark32_chest", "mark32_legflap_bottom": "sind:mark32/mark32_legflaps_bottom.tx.json", "mark32_legflap_top": "sind:mark32/mark32_legflaps_top.tx.json",
    "mark33": "sind:mark33/mark33_suit.tx.json", "mark33_mask": "sind:mark33/mark33_mask_false", "mark33_shoulder": "sind:mark33/mark33_shoulder.tx.json", "mark33_flaps": "sind:mark33/mark33_flaps.tx.json", "mark33_legflap_bottom": "sind:mark33/mark33_legflaps_bottom.tx.json", "mark33_legflap_top": "sind:mark33/mark33_legflaps_top.tx.json",
    "mark34": "sind:mark34/mark34_suit.tx.json", "mark34_mask": "sind:mark2/mark2_mask_false", "mark34_chest": "sind:mark34/mark34_chest", "mark34_shoulder": "sind:mark34/mark34_shoulder", "mark34_back"  : "sind:mark34/mark34_back", "mark34_claw": "sind:mark34/mark34_claw", "mark34_chin": "sind:mark34/mark34_chin",
    "mark35": "sind:mark35/mark35_suit.tx.json", "mark35_mask": "sind:mark35/mark35_mask_false", "mark35_shoulder": "sind:mark35/mark35_shoulder", "mark35_back" : "sind:mark35/mark35_back", "mark35_claw": "sind:mark35/mark35_claw", "mark35_claw_lights": "sind:mark35/mark35_claw_lights", "mark35_claw_repulsor": "sind:mark35/repulsor",
    "mark36": "sind:mark36/mark36_suit.tx.json", "mark36_mask": "sind:mark36/mark36_mask_false", "mark36_shoulder": "sind:mark36/mark36_shoulder.tx.json", "mark36_back": "sind:mark36/mark36_back",
    "mark37": "sind:mark37/mark37_suit.tx.json", "mark37_mask": "sind:mark37/mark37_mask_false", "mark37_chest": "sind:mark37/mark37_chest", "mark37_back": "sind:mark37/mark37_back.tx.json", "mark37_gauntlets": "sind:mark37/mark37_gauntlets",
    //skip 38
    "mark39": "sind:mark39/mark39_suit.tx.json", "mark39_mask": "sind:mark39/mark39_mask_false", "mark39_backpack": "sind:mark39/mark39_jetpack",
    "mark40": "sind:mark40/mark40_suit.tx.json", "mark40_mask": "sind:mark40/mark40_mask_false",
    "mark41": "sind:mark41/mark41_suit.tx.json", "mark41_mask": "sind:mark41/mark41_mask_false",
    "mark42": "sind:mark42/mark42_suit.tx.json", "mark42_mask": "sind:mark42/mark42_mask_false", "mark42_flaps": "sind:mark42/mark42_flaps.tx.json",
    "mark43": "sind:mark43/mark43_suit.tx.json", "mark43_mask": "sind:mark42/mark42_mask_false", "mark43_flaps": "sind:mark43/mark43_flaps.tx.json",
    //skip 44
    "mark45": "sind:mark45/mark45_suit.tx.json", "mark45_mask": "sind:mark45/mark45_mask_false", "mark45_flaps": "sind:mark45/mark45_flaps.tx.json", "mark45_legflap_bottom": "sind:mark45/mark45_legflaps_bottom.tx.json", "mark45_legflap_top": "sind:mark45/mark45_legflaps_top.tx.json",
    "mark46": "sind:mark46/mark46_suit.tx.json", "mark46_mask": "sind:null", "mark46_flaps": "sind:mark46/mark46_flaps.tx.json", "mark46_legflap_bottom": "sind:mark46/mark46_legflaps_bottom.tx.json", "mark46_legflap_top": "sind:mark46/mark46_legflaps_top.tx.json",
    "mark47": "sind:mark47/mark47_suit.tx.json", "mark47_mask": "sind:mark47/mark47_mask_false", "mark47_flaps": "sind:mark47/mark47_flaps.tx.json", "mark47_legflap_bottom": "sind:mark47/mark47_legflaps_bottom.tx.json", "mark47_legflap_top": "sind:mark47/mark47_legflaps_top.tx.json",
    //skip 48
    "mark49" : "sind:mark49/mark49_suit.tx.json", "mark49_mask": "sind:null", "mark49_backpack": "sind:mark49/mark49_backpack.tx.json", "mark49_backpack_lights": "sind:mark49/mark49_backpack_lights.tx.json",
    //alts
    "mark7/sz": "sind:mark7/mark7_sz_suit.tx.json", "mark7/sz_mask": "sind:mark7/mark7_sz_mask_false", "mark7/sz_chest": "sind:mark7/mark7_sz_chest", "mark7/sz_cannon": "sind:mark7/mark7_sz_cannon", "mark7/sz_flaps": "sind:mark7/mark7_sz_flaps.tx.json", "mark7/sz_chin": "sind:mark7/mark7_sz_chin", "mark7/sz_legflap_bottom": "sind:mark7/mark7_sz_legflaps_bottom.tx.json", "mark7/sz_legflap_top": "sind:mark7/mark7_sz_legflaps_top.tx.json",
    "mark7/d100": "sind:mark7/mark7_d100_suit.tx.json", "mark7/d100_mask": "sind:mark2/mark2_mask_false", "mark7/d100_chest": "sind:mark7/mark7_d100_chest", "mark7/d100_cannon": "sind:mark7/mark7_cannon", "mark7/d100_flaps": "sind:mark7/mark7_d100_flaps.tx.json", "mark7/d100_chin": "sind:mark5/mark5_chin", "mark7/d100_legflap_bottom": "sind:mark7/mark7_legflaps_bottom.tx.json", "mark7/d100_legflap_top": "sind:mark7/mark7_d100_legflaps_top.tx.json",
    "mark7/bg": "sind:mark7/mark7_bg_suit.tx.json", "mark7/bg_mask": "sind:mark3/mark3_mask_false", "mark7/bg_chest": "sind:mark7/mark7_bg_chest", "mark7/bg_cannon": "sind:mark7/mark7_bg_cannon", "mark7/bg_flaps": "sind:mark12/mark12_flaps.tx.json", "mark7/bg_chin": "sind:mark5/mark5_ev_chin", "mark7/bg_legflap_bottom": "sind:mark7/mark7_bg_legflaps_bottom.tx.json", "mark7/bg_legflap_top": "sind:mark7/mark7_bg_legflaps_top.tx.json",
    "mark13/zd": "sind:mark13/mark13_zd_suit.tx.json", "mark13/zd_mask": "sind:mark13/mark13_zd_mask_false", "mark13/zd_chest": "sind:mark13/mark13_zd_chest", "mark13/zd_cannon": "sind:mark13/mark13_zd_cannon", "mark13/zd_flaps": "sind:mark13/mark13_zd_flaps.tx.json", "mark13/zd_chin": "sind:mark13/mark13_zd_chin", "mark13/zd_legflap_bottom": "sind:mark13/mark13_zd_legflaps_bottom.tx.json", "mark13/zd_legflap_top": "sind:mark13/mark13_zd_legflaps_top.tx.json",
    "mark22/c": "sind:mark22/mark22_c_suit.tx.json", "mark22/c_mask": "sind:mark22/mark22_mask_false", "mark22/c_chest": "sind:mark22/mark22_chest.tx.json",
    "mark25/g": "sind:mark25/mark25_suit.tx.json", "mark25/g_mask": "sind:mark25/mark25_g_mask_false", "mark25/g_hammer": "sind:mark25/mark25_hammers", "mark25/g_flaps": "sind:mark25/mark25_flaps.tx.json",
    "mark26/g": "sind:mark26/mark26_suit.tx.json", "mark26/g_mask": "sind:mark26/mark26_g_mask_false", "mark26/g_hammer": "sind:mark26/mark26_hammers", "mark26/g_flaps": "sind:mark26/mark26_flaps.tx.json",
    "mark28/zd": "sind:mark28/mark28_zd_suit.tx.json", "mark28/zd_mask": "sind:mark28/mark28_zd_mask_false", "mark28/zd_chest": "sind:mark28/mark28_zd_chest", "mark28/zd_cannon": "sind:mark28/mark28_zd_cannon", "mark28/zd_flaps": "sind:mark28/mark28_flaps.tx.json",
    "mark32/zd": "sind:mark32/mark32_suit.tx.json", "mark32/zd_mask": "sind:mark32/mark32_zd_mask_false", "mark32/zd_reactor": "sind:mark32/mark32_chest",
    "mark34/zd": "sind:mark34/mark34_zd_suit.tx.json", "mark34/zd_mask": "sind:mark2/mark2_mask_false", "mark34/zd_chest": "sind:mark34/mark34_zd_chest", "mark34/zd_shoulder": "sind:mark34/mark34_zd_shoulder", "mark34/zd_back"  : "sind:mark34/mark34_zd_back", "mark34/zd_claw": "sind:mark34/mark34_zd_claw", "mark34/zd_chin": "sind:mark34/mark34_zd_chin",
    "mark37/concept": "sind:mark37/mark37_concept_suit.tx.json", "mark37/concept_mask": "sind:mark37/mark37_concept_mask_false", "mark37/concept_chest": "sind:mark37/mark37_concept_chest", "mark37/concept_back": "sind:mark37/mark37_concept_back.tx.json", "mark37/concept_gauntlets": "sind:mark37/mark37_concept_gauntlets",
    "mark40/h": "sind:mark40/harley/mark40_suit.tx.json", "mark40/h_mask": "sind:mark40/harley/mark40_mask_false",
    "mark41/retro": "sind:mark41/mark41_retro_suit.tx.json", "mark41/retro_mask": "sind:mark41/mark41_retro_mask_false",
    "mark42/sdca": "sind:mark42/mark42_sdca_suit.tx.json", "mark42/sdca_mask": "sind:mark42/mark42_mask_false", "mark42/sdca_flaps": "sind:mark42/mark42_sdca_flaps.tx.json",
    "mark46/ip": "sind:mark46/mark46_ip_suit.tx.json", "mark46/ip_mask": "sind:mark46/mark46_ip_mask_false", "mark46/ip_flaps": "sind:mark46/mark46_ip_flaps.tx.json",  "mark46/ip_legflap_bottom": "sind:mark46/mark46_legflaps_bottom.tx.json", "mark46/ip_legflap_top": "sind:mark46/mark46_legflaps_top.tx.json",
    "mark46/concept": "sind:mark46/mark46_concept_suit.tx.json", "mark46/concept_mask": "sind:null", "mark46/concept_flaps": "sind:mark46/mark46_concept_flaps.tx.json",  "mark46/concept_legflap_bottom": "sind:mark46/mark46_legflaps_bottom.tx.json", "mark46/concept_legflap_top": "sind:mark46/mark46_legflaps_top.tx.json",
    //war machines
    "warmachine_mk2": "sind:wm2/wm_suit.tx.json", "warmachine_mk2_mask": "sind:wm2/wm_mask_false", "warmachine_mk2_chest": "sind:wm2/wm_chest.tx.json",
    "warmachine_mk2/r": "sind:wm2_r/wm_suit.tx.json", "warmachine_mk2/r_mask": "sind:wm2_r/wm_mask_false", "warmachine_mk2/r_chest": "sind:wm2_r/wm_chest.tx.json",
    "warmachine_mk2/aou": "sind:wm2_r/wm_aou_suit.tx.json", "warmachine_mk2/aou_mask": "sind:wm2_r/wm_aou_mask_false", "warmachine_mk2/aou_chest": "sind:wm2_r/wm_aou_chest.tx.json",
    "warmachine_mk2/ip": "sind:wm2_ip/wm_suit.tx.json", "warmachine_mk2/ip_mask": "sind:wm2_ip/wm_mask_false", "warmachine_mk2/ip_chest": "sind:wm2_ip/wm_chest.tx.json",
    "warmachine_mk2/ip_r": "sind:wm2_r/wm_ip_suit.tx.json", "warmachine_mk2/ip_r_mask": "sind:wm2_r/wm_mask_false", "warmachine_mk2/ip_r_chest": "sind:wm2_r/wm_ip_chest.tx.json",
    "warmachine_mk2/ip_r_blue": "sind:wm2_r/wm_ip_suit.tx.json", "warmachine_mk2/ip_r_blue_mask": "sind:wm2_r/wm_mask_false", "warmachine_mk2/ip_r_blue_chest": "sind:wm2_r/wm_ip_chest.tx.json",
    "warmachine_mk3": "sind:wm3/wm_suit.tx.json", "warmachine_mk3_mask": "sind:wm3/wm_mask_false", "warmachine_mk3_chest": "sind:wm3/wm_chest.tx.json", "warmachine_mk3_arm": "sind:wm3/wm_armgun", "warmachine_mk3_chest2": "sind:wm3/wm_bulkchest",
    "warmachine_mk3/r": "sind:wm3_r/wm_suit.tx.json", "warmachine_mk3/r_mask": "sind:wm3_r/wm_mask_false", "warmachine_mk3/r_chest": "sind:wm3_r/wm_chest.tx.json", "warmachine_mk3/r_arm": "sind:wm3_r/wm_armgun", "warmachine_mk3/r_chest2": "sind:wm3_r/wm_bulkchest",
    "warmachine_mk3/p": "sind:wm3_r/wm_p_suit.tx.json", "warmachine_mk3/p_mask": "sind:wm3_r/wm_p_mask_false", "warmachine_mk3/p_chest": "sind:wm3_r/wm_p_chest.tx.json", "warmachine_mk3/p_arm": "sind:wm3_r/wm_armgun", "warmachine_mk3/p_chest2": "sind:wm3_r/wm_p_bulkchest",
    "warmachine_mk3/h": "sind:wm3_h/wm_suit.tx.json", "warmachine_mk3/h_mask": "sind:wm3_h/wm_mask_false", "warmachine_mk3/h_chest": "sind:wm3_h/wm_chest.tx.json", "warmachine_mk3/h_arm": "sind:wm3_h/wm_armgun", "warmachine_mk3/h_chest2": "sind:wm3_h/wm_bulkchest",
    "warmachine_mk3/s": "sind:wm3_s/wm_suit.tx.json", "warmachine_mk3/s_mask": "sind:wm3_h/wm_mask_false", "warmachine_mk3/s_chest": "sind:wm3_s/wm_chest.tx.json", "warmachine_mk3/s_arm": "sind:wm3_s/wm_armgun", "warmachine_mk3/s_arm2": "sind:wm3_s/wm_armgunleft", "warmachine_mk3/s_shawarma_chest": "sind:wm3_s/shawarma_chest", "warmachine_mk3/s_shawarma_chest_lights": "sind:wm3_s/shawarma_chest_lights", "warmachine_mk3/s_shawarma_shoulder": "sind:wm3_s/shawarma_shoulder", "warmachine_mk3/s_shawarma_shoulder_lights": "sind:wm3_s/shawarma_shoulder_lights",
    "warmachine_mk4": "sind:wm4/wm_suit.tx.json", "warmachine_mk4_mask": "sind:null", "warmachine_mk4_chest": "sind:wm4/wm_chest.tx.json", "warmachine_mk4_chest_lights": "sind:wm4/wm_chest_lights.tx.json", "warmachine_mk4_arm": "sind:wm4/wm_armgun", "warmachine_mk4_chest2": "sind:wm4/wm_bulkchest",
    "warmachine_mk4/r": "sind:wm4_r/wm_suit.tx.json", "warmachine_mk4/r_mask": "sind:null", "warmachine_mk4/r_chest": "sind:wm4_r/wm_chest.tx.json", "warmachine_mk4/r_chest_lights": "sind:wm4_r/wm_chest_lights.tx.json", "warmachine_mk4/r_arm": "sind:wm3_r/wm_armgun", "warmachine_mk4/r_chest2": "sind:wm4_r/wm_bulkchest",
    "warmachine_mk5": "sind:wm5/wm_suit.tx.json", "warmachine_mk5_mask": "sind:null", "warmachine_mk5_chest": "sind:wm5/wm_chest.tx.json", "warmachine_mk5_chest_lights": "sind:wm5/wm_chest_lights", "warmachine_mk5_arm": "sind:wm5/wm_armgun.tx.json",
    "warmachine_mk5/r": "sind:wm5_r/wm_suit.tx.json", "warmachine_mk5/r_mask": "sind:null", "warmachine_mk5/r_chest": "sind:wm5_r/wm_chest.tx.json", "warmachine_mk5/r_chest_lights": "sind:wm5_r/wm_chest_lights", "warmachine_mk5/r_arm": "sind:wm5_r/wm_armgun.tx.json",
    "warmachine_mk5/wm": "sind:wm5_wm/wm_suit.tx.json", "warmachine_mk5/wm_mask": "sind:null", "warmachine_mk5/wm_chest": "sind:wm5_wm/wm_chest.tx.json", "warmachine_mk5_r/chest_lights": "sind:wm5_r/wm_chest_lights", "warmachine_mk5/wm_arm": "sind:wm5_wm/wm_armgun.tx.json",
    "warmachine_mk6": "sind:wm6/wm_suit.tx.json", "warmachine_mk6_mask": "sind:null", "warmachine_mk6_chest": "sind:wm6/wm_chest", 
    //iron legion drone
    "ironlegiondrone": "sind:ironlegiondrone/ironlegiondrone_suit.tx.json", "ironlegiondrone_launcher": "sind:ironlegiondrone/ironlegiondrone_launcher",
    "ironlegiondrone/r1": "sind:ironlegiondrone/ironlegiondrone_r1_suit.tx.json", "ironlegiondrone/r1_launcher": "sind:ironlegiondrone/ironlegiondrone_launcher",
    "ironlegiondrone/r2": "sind:ironlegiondrone/ironlegiondrone_r2_suit.tx.json", "ironlegiondrone/r2_launcher": "sind:ironlegiondrone/ironlegiondrone_launcher",
    "ironlegiondrone/r4": "sind:ironlegiondrone/ironlegiondrone_r4_suit.tx.json", "ironlegiondrone/r4_launcher": "sind:ironlegiondrone/ironlegiondrone_launcher",
    "ironlegiondrone/r5": "sind:ironlegiondrone/ironlegiondrone_r5_suit.tx.json", "ironlegiondrone/r5_launcher": "sind:ironlegiondrone/ironlegiondrone_launcher",
    //mark38
    "mark38": "sind:tony/mark38.tx.json", "mark38_lights": "sind:tony/mark38_lights", "mark38_repulsor": "sind:tony/mark38_repulsor",
    "mark38/rg": "sind:tony/mark38_rg.tx.json", 
});
var jarvis = implement("sind:external/jarvis");
var utils = implement("fiskheroes:external/utils");
var hud;
var glasses;
var night_vision;
var overlay;
var head, body, rightArm, rightLeg, rightBoot;
var mk7, mk7fire, mk7plates, bracelets;
var mk1Model, mk1, stanLee;

var suitModel, maskModel, suit, mask, suitModelAssymetrical, suitAssymetrical, chinModel, chin;
var bulk, chest, flaps, flapmodel, flaps42, flapmodel42, can, cannon, reactorModel40, reactor40, reactorModel15, reactor15, reactorModel17, reactor17;
var reactorModel25, reactor25, wm2ChestModel, wm2Chest, hammerRightModel, hammerRight, hammerLeftModel, hammerLeft, reactorModel33, reactor33, shoulderRightModel33, shoulderRight33, shoulderLeftModel33, shoulderLeft33;
var backModel35, back35, shoulderModel35, shoulder35, clawLeftModel, clawLeft, clawRightModel, clawRight;
var backModel37, back37, gauntletRightModel, gauntletRight, gauntletLeftModel, gauntletLeft, chestModel37, chest37;
var jetpackModel39, jetpack39, reactorModel39, reactor39, reactorLightModel39, reactorLight39;
var backModel49, back49, ilmLauncherRightModel, ilmLauncherRight, ilmLauncherLeftModel, ilmLauncherLeft;
var wm3ChestModel, wm3Chest, wm3ArmRightModel, wm3ArmRight, wm3ArmLeftModel, wm3ArmLeft;
var wm4ChestModel, wm4Chest;
var fireLeft, fireRight, fireBoots, fireClawLeft, fireClawRight, repulsor, repulsorModel, repulsorClawLeft, repulsorClawRight;
var suit38Model, suit38, repulsor38, fire38, tony38, tony38Model;
var shawarmaChest, shawarmaChestModel, shawarmaShoulderRight, shawarmaShoulderRightModel, shawarmaShoulderLeft, shawarmaShoulderLeftModel;
var wm5ChestModel, wm5Chest, wm5ArmRightModel, wm5ArmRight, wm5ArmLeftModel, wm5ArmLeft;
var wm6ChestModel, wm6Chest;
var flaps25, flapmodel25, flaps45, flapmodel45;
var fins16, finsModel16;
var legFlapsBottomLeftModel, legFlapsBottomLeft, legFlapsBottomRightModel, legFlapsBottomRight, legFlapsTopLeftModel, legFlapsTopLeft, legFlapsTopRightModel, legFlapsTopRight;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return "null";
    });
    renderer.bindProperty("fiskheroes:opacity").setOpacity((entity, renderLayer) => {
        return entity.getData("sind:dyn/tony") ? 1 : 0.99999;
    });
}

function initEffects(renderer){
    //original glasses animation credit to galad
    glasses = renderer.createResource("MODEL", "sind:tony/helmet");
    glasses.bindAnimation("sind:glasses").setData((entity, data) => {
        var f = 1-entity.getInterpolatedData("sind:dyn/edith_timer");
        data.load(f < 1 ? f : 0);
    });
    glasses.texture.set("glasses", "glasses_lights");
    glasses = renderer.createEffect("fiskheroes:model").setModel(glasses);
    glasses.anchor.set("head");
    hud = jarvis.create(renderer, utils, "edith", 0x59D7FF);

    night_vision = renderer.bindProperty("fiskheroes:night_vision");
    night_vision.factor = 0.5;
    night_vision.setCondition(entity => entity.getData("sind:dyn/edith_timer") == 1);
    night_vision.firstPersonOnly = false;

    overlay = renderer.createEffect("fiskheroes:overlay");
    
    //mk1 models
    mk1Model = renderer.createResource("MODEL", "sind:tony/mk1transformation");
    mk1Model.bindAnimation("sind:summon_mk1").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    mk1 = renderer.createEffect("fiskheroes:model").setModel(mk1Model);
    mk1.anchor.set("body");
    mk1.anchor.ignoreAnchor(true);

    var stanLeeModel = renderer.createResource("MODEL", "sind:tony/stanlee");
    stanLeeModel.bindAnimation("sind:summon_mk1").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    stanLeeModel.texture.set("stanlee");
    stanLee = renderer.createEffect("fiskheroes:model").setModel(stanLeeModel);
    stanLee.anchor.set("body");
    stanLee.anchor.ignoreAnchor(true);
    
    //mk7 models
    var mk7Model = renderer.createResource("MODEL", "sind:tony/mk7transformation");
    mk7Model.bindAnimation("sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    });
    mk7Model.texture.set("mk7", "mk7_lights");
    mk7 = renderer.createEffect("fiskheroes:model").setModel(mk7Model);
    mk7.anchor.set("body");
    mk7.anchor.ignoreAnchor(true);

    var mk7PlatesModel = renderer.createResource("MODEL", "sind:tony/mk7transformation");
    mk7PlatesModel.bindAnimation("sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    });
    mk7PlatesModel.texture.set("mk7_plates", null);
    mk7plates = renderer.createEffect("fiskheroes:model").setModel(mk7PlatesModel);
    mk7plates.anchor.set("body");
    mk7plates.anchor.ignoreAnchor(true);

    var mk7FireModel = renderer.createResource("MODEL", "sind:tony/mk7fire");
    mk7FireModel.bindAnimation("sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    });
    mk7FireModel.texture.set(null, "fire");
    mk7fire = renderer.createEffect("fiskheroes:model").setModel(mk7FireModel);
    mk7fire.anchor.set("body");
    mk7fire.anchor.ignoreAnchor(true);

    var braceletsModel = renderer.createResource("MODEL", "sind:tony/tony_rightarm");
    braceletsModel.texture.set("bracelets", null);
    braceletsModel.generateMirror();
    bracelets = renderer.createEffect("fiskheroes:model").setModel(braceletsModel);
    bracelets.anchor.set("rightArm");
    bracelets.setOffset(-5, -2, 0);
    bracelets.mirror = true;

    //fake tony models
    var headModel = renderer.createResource("MODEL", "sind:tony/tony_head");
    headModel.texture.set("tony_layer1", null);
    head = renderer.createEffect("fiskheroes:model").setModel(headModel);
    head.anchor.set("head");

    var bodyModel = renderer.createResource("MODEL", "sind:tony/tony_body");
    bodyModel.texture.set("tony_layer1", null);
    body = renderer.createEffect("fiskheroes:model").setModel(bodyModel);
    body.anchor.set("body");

    var rightArmModel = renderer.createResource("MODEL", "sind:tony/tony_rightarm");
    rightArmModel.texture.set("tony_layer1", null);
    rightArmModel.generateMirror();
    rightArm = renderer.createEffect("fiskheroes:model").setModel(rightArmModel);
    rightArm.anchor.set("rightArm");
    rightArm.setOffset(-5, -2, 0);
    rightArm.mirror = true;

    var rightLegModel = renderer.createResource("MODEL", "sind:tony/tony_rightleg");
    rightLegModel.texture.set("tony_layer2", null);
    rightLegModel.generateMirror();
    rightLeg = renderer.createEffect("fiskheroes:model").setModel(rightLegModel);
    rightLeg.anchor.set("rightLeg");
    rightLeg.setOffset(-2, -12, -0.1);
    rightLeg.mirror = true;

    var rightBootModel = renderer.createResource("MODEL", "sind:tony/tony_rightleg");
    rightBootModel.texture.set("tony_layer1", null);
    rightBootModel.generateMirror();
    rightBoot = renderer.createEffect("fiskheroes:model").setModel(rightBootModel);
    rightBoot.anchor.set("rightLeg");
    rightBoot.setOffset(-2, -12, -0.1);
    rightBoot.mirror = true;

    //38 stuff
    tony38Model = renderer.createResource("MODEL", "sind:tony/tony_full");
    tony38Model.bindAnimation("sind:summonigor").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    tony38 = renderer.createEffect("fiskheroes:model").setModel(tony38Model);
    tony38.anchor.set("body");

    suit38Model = renderer.createResource("MODEL", "sind:tony/suit38");
    suit38Model.bindAnimation("sind:summonigor").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    suit38 = renderer.createEffect("fiskheroes:model").setModel(suit38Model);
    suit38.anchor.set("body");
    suit38.setScale(2);

    var repulsor38Model = renderer.createResource("MODEL", "sind:tony/suit38");
    repulsor38Model.bindAnimation("sind:summonigor").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    repulsor38Model.texture.set(null, "mark38_repulsor");
    repulsor38 = renderer.createEffect("fiskheroes:model").setModel(repulsor38Model);
    repulsor38.anchor.set("body");
    repulsor38.setScale(2);

    var fireModel38 = renderer.createResource("MODEL", "sind:tony/suit38fire");
    fireModel38.bindAnimation("sind:summonigor").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    });
    fireModel38.texture.set(null, "fire");
    fire38 = renderer.createEffect("fiskheroes:model").setModel(fireModel38);
    fire38.anchor.set("body");
    fire38.setScale(2);

    //suit models
    suitModel = createModel(renderer, "sind:tony/suit");
    suit = createEffect(renderer, suitModel);

    suitModelAssymetrical = createModel(renderer, "sind:tony/suit2");
    suitAssymetrical = createEffect(renderer, suitModelAssymetrical);

    maskModel = createModel(renderer, "sind:tony/mask");
    mask = createEffect(renderer, maskModel);

    chinModel = createModel(renderer, "sind:tony/mask");
    chin = createEffect(renderer, chinModel);

    repulsorModel = createModel(renderer, "sind:tony/suit_repulsor");
    repulsor = createEffect(renderer, repulsorModel);

    var repulsorClawRightModel = createModel(renderer, "sind:mk35/armright");
    repulsorClawRightModel.texture.set(null, "mark35_claw_repulsor");
    repulsorClawRight = createEffect(renderer, repulsorClawRightModel);

    var repulsorClawLeftModel = createModel(renderer, "sind:mk35/armleft");
    repulsorClawLeftModel.texture.set(null, "mark35_claw_repulsor");
    repulsorClawLeft = createEffect(renderer, repulsorClawLeftModel);

    var fireModelBoots = createModel(renderer, "sind:tony/suit_fire_feet");
    fireModelBoots.texture.set(null, "fire");
    fireBoots = createEffect(renderer, fireModelBoots);

    var fireModelRight = createModel(renderer, "sind:tony/suit_fire_right");
    fireModelRight.texture.set(null, "fire");
    fireRight = createEffect(renderer, fireModelRight);

    var fireModelLeft = createModel(renderer, "sind:tony/suit_fire_left");
    fireModelLeft.texture.set(null, "fire");
    fireLeft = createEffect(renderer, fireModelLeft);

    var fireModelClawRight = createModel(renderer, "sind:tony/suit_fire_right_claw");
    fireModelClawRight.texture.set(null, "fire");
    fireClawRight = createEffect(renderer, fireModelClawRight);

    var fireModelClawLeft = createModel(renderer, "sind:tony/suit_fire_left_claw");
    fireModelClawLeft.texture.set(null, "fire");
    fireClawLeft = createEffect(renderer, fireModelClawLeft);

    // extra models
    bulk = createModel(renderer, "sind:bulkchest");
    bulk.bindAnimation("sind:flaps").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    chest = createEffect(renderer, bulk);

    flapmodel = createModel(renderer, "sind:flaps");
    flapmodel.bindAnimation("sind:mk45_flaps").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    flaps = createEffect(renderer, flapmodel);

    flapmodel25 = createModel(renderer, "sind:flaps25");
    flapmodel25.bindAnimation("sind:mk25_flaps").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    flaps25 = createEffect(renderer, flapmodel25);

    flapmodel42 = createModel(renderer, "sind:flaps");
    flapmodel42.bindAnimation("sind:mk3_flaps").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    flaps42 = createEffect(renderer, flapmodel42);

    flapmodel45 = createModel(renderer, "sind:flaps25");
    flapmodel45.bindAnimation("sind:mk45_flaps").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    flaps45 = createEffect(renderer, flapmodel45);

    can = createModel(renderer, "sind:cannons");
    can.bindAnimation("sind:cannons").setData((entity, data) => {
        data.load(2, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    cannon = createEffect(renderer, can);

    reactorModel40 = createModel(renderer, "sind:mk40/reactor");
    reactor40 = createEffect(renderer, reactorModel40);

    reactorModel15 = createModel(renderer, "sind:mk15/chest");
    reactor15 = createEffect(renderer, reactorModel15);

    finsModel16 = createModel(renderer, "sind:mk16/fins");
    fins16 = createEffect(renderer, finsModel16);
    
    reactorModel17 = createModel(renderer, "sind:mk17/reactor");
    reactorModel17.bindAnimation("sind:arcpack").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    reactor17 = createEffect(renderer, reactorModel17);

    wm2ChestModel = createModel(renderer, "sind:wm2/gun");
    wm2ChestModel.bindAnimation("sind:wm2").setData((entity, data) => {
        data.load(1, entity.getInterpolatedData('sind:dyn/sentry_timer'));
        data.load(3, 1);
    });
    wm2Chest = createEffect(renderer, wm2ChestModel);

    reactorModel25 = createModel(renderer, "sind:mk25/reactor");
    reactor25 = createEffect(renderer, reactorModel25);

    hammerRightModel = createModel(renderer, "sind:mk25/jackhammer");
    hammerRightModel.bindAnimation("sind:hammers").setData((entity, data) => {
        var eq = Math.min(1, Math.max(0, (-20 * entity.getData("sind:dyn/summon_timer") + 14)));
        data.load(0, eq);
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(10, 1); // 1 for Right, -1 for Left
    });
    hammerRight = createEffect(renderer, hammerRightModel);
    
    hammerLeftModel = createModel(renderer, "sind:mk29/jackhammer");
    hammerLeftModel.bindAnimation("sind:hammers").setData((entity, data) => {
        var eq = Math.min(1, Math.max(0, (-20 * entity.getData("sind:dyn/summon_timer") + 14)));
        data.load(0, eq);
        data.load(2, entity.getInterpolatedData("sind:dyn/sentry_timer"));
        data.load(10, -1); // 1 for Right, -1 for Left
    });
    hammerLeft = createEffect(renderer, hammerLeftModel);
    
    reactorModel33 = createModel(renderer, "sind:mk33/reactor");
    reactor33 = createEffect(renderer, reactorModel33);
    
    shoulderRightModel33 = createModel(renderer, "sind:mk33/shoulderright");
    shoulderRight33 = createEffect(renderer, shoulderRightModel33);
    
    shoulderLeftModel33 = createModel(renderer, "sind:mk33/shoulderleft");
    shoulderLeft33 = createEffect(renderer, shoulderLeftModel33);
    
    backModel35 = createModel(renderer, "sind:mk35/back");
    backModel35.bindAnimation("sind:clawbackpack").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    back35 = createEffect(renderer, backModel35);

    shoulderModel35 = createModel(renderer, "sind:mk35/shoulders");
    shoulder35 = createEffect(renderer, shoulderModel35);

    clawLeftModel = createModel(renderer, "sind:mk35/armleft");
    clawLeftModel.bindAnimation("sind:claws").setData((entity, data) => {
        data.load(5, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    clawLeft = createEffect(renderer, clawLeftModel);

    clawRightModel = createModel(renderer, "sind:mk35/armright");
    clawRightModel.bindAnimation("sind:claws").setData((entity, data) => {
        data.load(5, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    clawRight = createEffect(renderer, clawRightModel);

    chestModel37 = createModel(renderer, "sind:mk37/chest");
    chest37 = createEffect(renderer, chestModel37);

    backModel37 = createModel(renderer, "sind:mk37/back");
    backModel37.bindAnimation("sind:torpedobackpack").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    back37 = createEffect(renderer, backModel37);

    gauntletRightModel = createModel(renderer, "sind:mk37/gauntlet");
    gauntletRightModel.bindAnimation("sind:gauntlets").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    gauntletRight = createEffect(renderer, gauntletRightModel);

    gauntletLeftModel = createModel(renderer, "sind:mk37/gauntletleft");
    gauntletLeftModel.bindAnimation("sind:gauntlets").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    gauntletLeft = createEffect(renderer, gauntletLeftModel);

    jetpackModel39 = createModel(renderer, "sind:mk39/backpack");
    jetpackModel39.bindAnimation("sind:mk39_jetpack").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    jetpack39 = createEffect(renderer, jetpackModel39);

    reactorModel39 = createModel(renderer, "sind:mk39/reactor1");
    reactor39 = createEffect(renderer, reactorModel39);

    reactorLightModel39 = createModel(renderer, "sind:mk39/reactor");
    reactorLight39 = createEffect(renderer, reactorLightModel39);
    
    backModel49 = createModel(renderer, "sind:mk49/backpack");
    back49 = createEffect(renderer, backModel49);
    
    ilmLauncherRightModel = createModel(renderer, "sind:ironlegiondrones/launcher");
    ilmLauncherRight = createEffect(renderer, ilmLauncherRightModel);

    ilmLauncherLeftModel = createModel(renderer, "sind:ironlegiondrones/launcherleft");
    ilmLauncherLeft = createEffect(renderer, ilmLauncherLeftModel);

    wm3ChestModel = createModel(renderer, "sind:wm3/gun");
    wm3Chest = createEffect(renderer, wm3ChestModel);

    wm3ArmRightModel = createModel(renderer, "sind:wm3/armright");
    wm3ArmRight = createEffect(renderer, wm3ArmRightModel);

    wm3ArmLeftModel = createModel(renderer, "sind:wm3/armleft");
    wm3ArmLeft = createEffect(renderer, wm3ArmLeftModel);

    shawarmaChestModel = createModel(renderer, "sind:shawarma/chest");
    shawarmaChestModel.bindAnimation("sind:shawarma_spin").setData((entity, data) => {
        data.load(0, entity.loop(400));
        data.load(1, 1);
    });
    shawarmaChest = createEffect(renderer, shawarmaChestModel);

    shawarmaShoulderRightModel = createModel(renderer, "sind:shawarma/shoulderright");
    shawarmaShoulderRightModel.bindAnimation("sind:shawarma_spin").setData((entity, data) => {
        data.load(0, entity.loop(400));
        data.load(1, 1);
    });
    shawarmaShoulderRight = createEffect(renderer, shawarmaShoulderRightModel);


    shawarmaShoulderLeftModel = createModel(renderer, "sind:shawarma/shoulderleft");
    shawarmaShoulderLeftModel.bindAnimation("sind:shawarma_spin").setData((entity, data) => {
        data.load(0, entity.loop(400));
        data.load(1, -1);
    });
    shawarmaShoulderLeft = createEffect(renderer, shawarmaShoulderLeftModel);

    wm4ChestModel = createModel(renderer, "sind:wm4/gun");
    wm4ChestModel.bindAnimation("sind:wm4").setData((entity, data) => {
        data.load(0, 0);
        data.load(3, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    wm4Chest = createEffect(renderer, wm4ChestModel);

    wm5ChestModel = createModel(renderer, "sind:wm5/gun");
    wm5ChestModel.bindAnimation("sind:wm5").setData((entity, data) => {
        data.load(0, 0);
        data.load(3, entity.getInterpolatedData('sind:dyn/sentry_timer'));
    });
    wm5Chest = createEffect(renderer, wm5ChestModel);

    wm5ArmRightModel = createModel(renderer, "sind:wm5/armright");
    wm5ArmRight = createEffect(renderer, wm5ArmRightModel);

    wm5ArmLeftModel = createModel(renderer, "sind:wm5/armleft");
    wm5ArmLeft = createEffect(renderer, wm5ArmLeftModel);

    wm6ChestModel = createModel(renderer, "sind:wm6/gun");
    wm6ChestModel.bindAnimation("sind:wm6").setData((entity, data) => {
        data.load(3, 1);
    });
    wm6Chest = createEffect(renderer, wm6ChestModel);

    legFlapsBottomLeftModel = createModel(renderer, "sind:legflapleft");
    legFlapsBottomLeft = createEffect(renderer, legFlapsBottomLeftModel);
    legFlapsBottomRightModel = createModel(renderer, "sind:legflapright");
    legFlapsBottomRight = createEffect(renderer, legFlapsBottomRightModel);

    legFlapsTopLeftModel = createModel(renderer, "sind:legflapleft");
    legFlapsTopLeft = createEffect(renderer, legFlapsTopLeftModel);
    legFlapsTopRightModel = createModel(renderer, "sind:legflapright");
    legFlapsTopRight = createEffect(renderer, legFlapsTopRightModel);
}

function initAnimations(renderer){
    addAnimation(renderer, "summonpose", "sind:summon_pose").setData((entity, data) => {
        data.load(0, Math.max(entity.getInterpolatedData("sind:dyn/summon7_timer"), entity.getInterpolatedData("sind:dyn/summon_timer")));
    }).priority = -11;
    addAnimation(renderer, "summon", "sind:summon").setData((entity, data) => {
        var nbt = entity.getWornChestplate().nbt();
        var pick = nbt.getString("Pick").split("sind:")[1];
        data.load(0, (pick == "mark38" || pick == "mark38/rg") ? 0 : entity.getInterpolatedData("sind:dyn/summon_timer"));
        data.load(1, (pick == "mark34" || pick == "mark34/zd"|| pick == "mark35" || pick == "mark36") ? 1 : 0);
    }).setCondition((entity) => {
        var nbt = entity.getWornChestplate().nbt();
        var pick = nbt.getString("Pick").split("sind:")[1];
        return pick != "mark1" && pick != "mark1/gold";
    }).priority = 14;
    addAnimation(renderer, "summon_mk1", "sind:summon_mk1").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
    }).setCondition((entity) => {
        var nbt = entity.getWornChestplate().nbt();
        var pick = nbt.getString("Pick").split("sind:")[1];
        return pick == "mark1" || pick == "mark1/gold";
    }).priority = 14;
    addAnimation(renderer, "mk7", "sind:mk7_transformation").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/summon7_timer"));
    }).priority = 14;
    addAnimation(renderer, "glasses", "sind:glasses").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/edith_timer"));
    }).priority = 1;
    addAnimation(renderer, "armbeGONE", "fiskheroes:ocular_beam").setData((entity, data) => {
        data.load(Math.min(1, entity.getInterpolatedData("sind:dyn/summon_timer") * 20));
    }).priority = -11;
    addAnimationWithData(renderer, "tony_suit", "sind:cancel", "sind:dyn/tony_to_suit").priority = -11;
}
function render(entity, renderLayer, isFirstPersonArm) {
    if ((entity.is("DISPLAY") && entity.as("DISPLAY").getDisplayType() != "HOLOGRAM") || !entity.isWearingFullSuit()) {
        if (renderLayer == "LEGGINGS") {
            overlay.texture.set("tony_layer2");
            overlay.render();
        } else {
            overlay.texture.set("tony_layer1");
            overlay.render();
        }
        //beginning of the actual WORST render function in all of fiskheroes history
    } else {
        if (entity.getData("sind:dyn/summon_timer") > 0) {
            var nbt = entity.getWornChestplate().nbt();
            var pick = nbt.getString("Pick").split("sind:")[1];

            if (pick == "mark1" || pick == "mark1/gold"){
                if (isFirstPersonArm) {
                    stanLee.anchor.set("rightArm");
                    stanLee.setOffset(0, 4, 4);
                    mk1.anchor.set("rightArm");
                    mk1.setOffset(0, 4, 4);
                } else{ 
                    stanLee.anchor.set("body");
                    stanLee.setOffset(0, 0, 0);
                    mk1.anchor.set("body");
                    mk1.setOffset(0, 0, 0);
                }
                stanLee.render();
                mk1Model.texture.set(pick == "mark1/gold" ? "mk1_gold" : "mk1", "mk1_lights");
                mk1.render();
            } else if (pick != "mark38" && pick != "mark38/rg") {
                var mk13 = pick == "mark13" || pick == "mark13/zd";
                var mk33 = pick == "mark30" || pick == "mark33";
                var triangle = mk33 || pick == "mark39";
                var ild = pick == "ironlegiondrone" || pick == "ironlegiondrone/r1" || pick == "ironlegiondrone/r2" || pick == "ironlegiondrone/r4" || pick == "ironlegiondrone/r5";
                var rectangle = pick == "mark25" || pick == "mark26" || pick == "mark40" || pick == "mark23" || mk13 || ild;
                var green_rectangle = pick == "mark25/g" || pick == "mark26/g";
                var mk35 = pick == "mark35" || pick == "mark36";
                var mk37 = pick == "mark37" || pick == "mark37/concept";
                var mk16 = pick == "mark16";
                var mk22 = pick == "mark22" || pick == "mark22/c" || pick == "warmachine_mk2/ip_r_blue";
                var mk46 = pick == "mark46" || pick == "mark47" || pick == "mark46/ip" || pick == "mark46/concept";
                var wm2 = pick == "warmachine_mk2" || pick == "warmachine_mk2/ip";
                var wm2r = pick == "warmachine_mk2/r" || pick == "warmachine_mk2/ip_r";
                var wm2aou = pick == "warmachine_mk2/aou";
                var wm3 = pick == "warmachine_mk3";
                var wm3h = pick == "warmachine_mk3/h";
                var wm3s = pick == "warmachine_mk3/s";
                var wm3r = pick == "warmachine_mk3/r" || pick == "warmachine_mk3/p";
                var wm4 = pick == "warmachine_mk4";
                var wm4r = pick == "warmachine_mk4/r";
                var wm5 = pick == "warmachine_mk5";
                var wm5r = pick == "warmachine_mk5/r" || pick == "warmachine_mk5/wm";
                var wm6 = pick == "warmachine_mk6";
                var mk40h = pick == "mark40/h";
                var mk49 = pick == "mark49";
                var mk28 = pick == "mark28" || pick == "mark28/zd";
                var mk32 = pick == "mark32" || pick == "mark32/zd";
                var mk34 = pick == "mark34" || pick == "mark34/zd";
                var isMk7 = pick == "mark7" || pick == "mark7/sz" || pick == "mark7/d100" || pick == "mark7/bg";
                var hasBulk = isMk7 || pick == "mark8" || pick == "mark9" || pick == "mark10" || pick == "mark11" || pick == "mark12" || mk13 || pick == "mark14" || pick == "mark18" || pick == "mark19" || pick == "mark20" || pick == "mark21" || pick == "mark27" || mk28 || pick == "mark31" || mk34 ||
                    wm3 || wm3h || wm3r || wm4 || wm4r;
                var hasFlaps = isMk7 || pick == "mark8" || pick == "mark9" || pick == "mark10" || pick == "mark11" || pick == "mark12" || mk13 || pick == "mark14" || pick == "mark18" || pick == "mark19" || pick == "mark20" ||
                    pick == "mark21" || pick == "mark27" || mk28 || pick == "mark31" ||
                    pick == "mark46" || pick == "mark47" || pick == "mark46/ip";
                var hasFlaps25 = pick == "mark25" || pick == "mark26" || pick == "mark25/g" || pick == "mark26/g";
                var hasFlaps42 = pick == "mark42" || pick == "mark42/sdca" || pick == "mark43";
                var hasCannon = isMk7 || pick == "mark8" || pick == "mark9" || pick == "mark11" || pick == "mark12" || mk13 || pick == "mark14" || pick == "mark18" || pick == "mark20" ||
                    pick == "mark21" || pick == "mark27" || mk28 || pick == "mark31";
                var hasMk40Reactor = pick == "mark40" || mk40h || pick == "mark23" || mk13;
                var hasMk17Reactor = pick == "mark17" || pick == "mark18" || pick == "mark24" || pick == "mark29" || mk32;
                var hasWm2Chest = wm2 || wm2r || wm2aou || mk22;
                var hasWm3Chest = wm3 || wm3r || wm3h || wm3s;

                var hasRightHammer = pick == "mark25" || pick == "mark26" || pick == "mark25/g" || pick == "mark26/g";
                var hasLeftHammer = hasRightHammer || pick == "mark29";
                var hasMk25Reactor = hasRightHammer || ild;

                var lighttexture = rectangle ? "lights_rectangle" : triangle ? "lights_triangle" : mk35 ? "lights_mk35" :
                    mk16 ? "lights_mk16" : mk46 ? "lights_mk46" : mk22 ? "lights_mk22" : mk37 ? "lights_mk37" :
                        wm2 ? "lights_wm2" : (wm2r || wm3r) ? "lights_wm2_r" : wm2aou ? "lights_wm2_aou" :
                            wm3 ? "lights_wm3" : wm3h ? "lights_wm3h" : wm3s ? "lights_wm3s" : 
                                wm4 ? "lights_wm4" : wm4r ? "lights_wm4r" :
                                    wm5 ? "lights_wm5" : wm5r ? "lights_wm5r" : 
                                        wm6 ? "lights_wm6" :
                                            mk40h ? "lights_mk40h" : mk49 ? "lights_mk49" : 
                                                green_rectangle ? "lights_g_rectangle" : "lights";
                var assymetrical = pick == "mark29" || mk34 || ild || wm3s;
                var hasChin = isMk7 || pick == "mark8" || pick == "mark10" || mk13 || pick == "mark18" || pick == "mark19" || pick == "mark21" || 
                    pick == "mark29" || mk34;
                var hasLegFlaps = isMk7 || pick == "mark8" || mk13 || pick == "mark21" || pick == "mark31" || mk32 || mk33 || pick == "mark45" || mk46; // 42, 43
                if (assymetrical) {
                    suitModelAssymetrical.texture.set(pick, lighttexture);
                    renderEffect(suitAssymetrical, entity, isFirstPersonArm);
                } else {
                    suitModel.texture.set(pick, lighttexture);
                    renderEffect(suit, entity, isFirstPersonArm);
                }
                if (!ild) {
                    maskModel.texture.set(pick + "_mask", lighttexture);
                    renderEffect(mask, entity, isFirstPersonArm);
                }
                if (hasChin) {
                    chinModel.texture.set(pick + "_chin");
                    renderEffect(chin, entity, isFirstPersonArm);
                }
                if (entity.getData("sind:dyn/summon_timer") < 0.7) {
                    var op = Math.min(1, Math.max(0, (-20 * entity.getData("sind:dyn/summon_timer") + 14)));
                    repulsorModel.texture.set(null, "repulsor_boots");
                    repulsor.opacity = op;
                    renderEffect(repulsor, entity, isFirstPersonArm);
                    renderEffect(fireBoots, entity, isFirstPersonArm);
                    if (mk34 || pick == "mark35") {
                        renderEffect(fireClawLeft, entity, isFirstPersonArm);
                        repulsorClawLeft.opacity = op;
                        renderEffect(repulsorClawLeft, entity, isFirstPersonArm);
                    } else {
                        renderEffect(fireLeft, entity, isFirstPersonArm);
                        repulsorModel.texture.set(null, "repulsor_left");
                        repulsor.opacity = op;
                        renderEffect(repulsor, entity, isFirstPersonArm);
                    }
                    if (pick == "mark35") {
                        renderEffect(fireClawRight, entity, isFirstPersonArm);
                        repulsorClawRight.opacity = op;
                        renderEffect(repulsorClawRight, entity, isFirstPersonArm);
                    } else {
                        renderEffect(fireRight, entity, isFirstPersonArm);
                        repulsorModel.texture.set(null, "repulsor");
                        repulsor.opacity = op;
                        renderEffect(repulsor, entity, isFirstPersonArm);
                    }
                }

                if (hasBulk) {
                    if (wm3 || wm3h || wm3r || wm4 || wm4r) {
                        bulk.texture.set(pick + "_chest2");
                    } else{
                        bulk.texture.set(pick + "_chest");
                    }
                    renderEffect(chest, entity, isFirstPersonArm);
                }
                if (hasFlaps) {
                    flapmodel.texture.set(pick + "_flaps");
                    renderEffect(flaps, entity, isFirstPersonArm);
                } else if (hasFlaps42) {
                    flapmodel42.texture.set(pick + "_flaps");
                    renderEffect(flaps42, entity, isFirstPersonArm);
                } else if (hasFlaps25) {
                    flapmodel25.texture.set(pick + "_flaps");
                    renderEffect(flaps25, entity, isFirstPersonArm);
                } else if (pick == "mark45" || mk33) {
                    flapmodel45.texture.set(pick + "_flaps");
                    renderEffect(flaps45, entity, isFirstPersonArm);
                }
                if (hasLegFlaps) {
                    legFlapsBottomLeftModel.texture.set(pick + "_legflap_bottom");
                    renderEffect(legFlapsBottomLeft, entity, isFirstPersonArm);
                    legFlapsBottomRightModel.texture.set(pick + "_legflap_bottom");
                    renderEffect(legFlapsBottomRight, entity, isFirstPersonArm);
                    legFlapsTopLeftModel.texture.set(pick + "_legflap_top");
                    renderEffect(legFlapsTopLeft, entity, isFirstPersonArm);
                    legFlapsTopRightModel.texture.set(pick + "_legflap_top");
                    renderEffect(legFlapsTopRight, entity, isFirstPersonArm);
                }
                if (hasCannon) {
                    can.texture.set(pick + "_cannon");
                    renderEffect(cannon, entity, isFirstPersonArm);
                }
                if (hasMk40Reactor) {
                    reactorModel40.texture.set(pick);
                    renderEffect(reactor40, entity, isFirstPersonArm);
                }
                if (pick == "mark15") {
                    reactorModel15.texture.set(pick + "_reactor");
                    renderEffect(reactor15, entity, isFirstPersonArm);
                }
                if (mk16) {
                    finsModel16.texture.set(pick + "_fins");
                    renderEffect(fins16, entity, isFirstPersonArm);
                }
                if (hasMk17Reactor) {
                    reactorModel17.texture.set(pick + "_reactor", "mark17_reactor_lights");
                    renderEffect(reactor17, entity, isFirstPersonArm);
                }
                if (hasWm2Chest) {
                    wm2ChestModel.texture.set(pick + "_chest");
                    renderEffect(wm2Chest, entity, isFirstPersonArm);
                }
                if (hasWm3Chest) {
                    wm3ChestModel.texture.set(pick + "_chest");
                    renderEffect(wm3Chest, entity, isFirstPersonArm);
                    wm3ArmRightModel.texture.set(pick + "_arm");
                    renderEffect(wm3ArmRight, entity, isFirstPersonArm);
                    if (wm3s) {
                        wm3ArmLeftModel.texture.set(pick + "_arm2");
                        renderEffect(wm3ArmLeft, entity, isFirstPersonArm);
                        shawarmaChestModel.texture.set(pick + "_shawarma_chest", pick + "_shawarma_chest_lights");
                        renderEffect(shawarmaChest, entity, isFirstPersonArm);
                        shawarmaShoulderRightModel.texture.set(pick + "_shawarma_shoulder", pick + "_shawarma_shoulder_lights");
                        renderEffect(shawarmaShoulderRight, entity, isFirstPersonArm);
                        shawarmaShoulderLeftModel.texture.set(pick + "_shawarma_shoulder", pick + "_shawarma_shoulder_lights");
                        renderEffect(shawarmaShoulderLeft, entity, isFirstPersonArm);
                    } else{
                        wm3ArmLeftModel.texture.set(pick + "_arm");
                        renderEffect(wm3ArmLeft, entity, isFirstPersonArm);
                    }
                }
                if (wm4 || wm4r) {
                    wm4ChestModel.texture.set(pick + "_chest", pick + "_chest_lights");
                    renderEffect(wm4Chest, entity, isFirstPersonArm);
                    wm3ArmRightModel.texture.set(pick + "_arm");
                    renderEffect(wm3ArmRight, entity, isFirstPersonArm);
                    wm3ArmLeftModel.texture.set(pick + "_arm");
                    renderEffect(wm3ArmLeft, entity, isFirstPersonArm);
                }
                if (wm5 || wm5r) {
                    wm5ChestModel.texture.set(pick + "_chest", pick + "_chest_lights");
                    renderEffect(wm5Chest, entity, isFirstPersonArm);
                    wm5ArmRightModel.texture.set(pick + "_arm");
                    renderEffect(wm5ArmRight, entity, isFirstPersonArm);
                    wm5ArmLeftModel.texture.set(pick + "_arm");
                    renderEffect(wm5ArmLeft, entity, isFirstPersonArm);
                }
                if (wm6) {
                    wm6ChestModel.texture.set(pick + "_chest");
                    renderEffect(wm6Chest, entity, isFirstPersonArm);
                }
                if (hasMk25Reactor) {
                    reactorModel25.texture.set(pick);
                    renderEffect(reactor25, entity, isFirstPersonArm);
                }
                if (hasRightHammer) {
                    hammerRightModel.texture.set(pick + "_hammer");
                    renderEffect(hammerRight, entity, isFirstPersonArm);
                }
                if (hasLeftHammer) {
                    hammerLeftModel.texture.set(pick + "_hammer");
                    renderEffect(hammerLeft, entity, isFirstPersonArm);
                }
                if (mk33) {
                    reactorModel33.texture.set(pick);
                    renderEffect(reactor33, entity, isFirstPersonArm);
                    shoulderRightModel33.texture.set(pick + "_shoulder");
                    renderEffect(shoulderRight33, entity, isFirstPersonArm);
                    shoulderLeftModel33.texture.set(pick + "_shoulder");
                    renderEffect(shoulderLeft33, entity, isFirstPersonArm);
                }
                if (mk34 || mk35 || pick == "mark36") {
                    backModel35.texture.set(pick + "_back");
                    renderEffect(back35, entity, isFirstPersonArm);
                    shoulderModel35.texture.set(pick + "_shoulder");
                    renderEffect(shoulder35, entity, isFirstPersonArm);
                }
                if (mk34 || pick == "mark35") {
                    clawLeftModel.texture.set(pick + "_claw", "mark35_claw_lights");
                    renderEffect(clawLeft, entity, isFirstPersonArm);
                }
                if (pick == "mark35") {
                    clawRightModel.texture.set(pick + "_claw", "mark35_claw_lights");
                    renderEffect(clawRight, entity, isFirstPersonArm);
                }
                if (mk37) {
                    chestModel37.texture.set(pick + "_chest");
                    renderEffect(chest37, entity, isFirstPersonArm);
                    backModel37.texture.set(pick + "_back");
                    renderEffect(back37, entity, isFirstPersonArm);
                    gauntletRightModel.texture.set(pick + "_gauntlets");
                    renderEffect(gauntletRight, entity, isFirstPersonArm);
                    gauntletLeftModel.texture.set(pick + "_gauntlets");
                    renderEffect(gauntletLeft, entity, isFirstPersonArm);
                }
                if (pick == "mark39") {
                    jetpackModel39.texture.set(pick + "_backpack");
                    renderEffect(jetpack39, entity, isFirstPersonArm);
                    reactorModel39.texture.set(pick);
                    renderEffect(reactor39, entity, isFirstPersonArm);
                    reactorLightModel39.texture.set(null, "lights_triangle");
                    renderEffect(reactorLight39, entity, isFirstPersonArm);
                }
                if (mk49) {
                    backModel49.texture.set(pick + "_backpack", pick + "_backpack_lights");
                    renderEffect(back49, entity, isFirstPersonArm);
                }
                if (ild) {
                    ilmLauncherRightModel.texture.set(pick + "_launcher");
                    renderEffect(ilmLauncherRight, entity, isFirstPersonArm);
                    ilmLauncherLeftModel.texture.set(pick + "_launcher");
                    renderEffect(ilmLauncherLeft, entity, isFirstPersonArm);
                }

            } else { //mark38 special case
                if (entity.getData("sind:dyn/summon_timer") >= 0.05) {
                    tony38Model.texture.set("tony_layer1", null);
                    tony38.render();
                    tony38Model.texture.set("tony_layer2", null);
                    tony38.render();
                }
                suit38Model.texture.set(pick, "mark38_lights");
                renderIgorEffect(suit38, entity, isFirstPersonArm);
                if (entity.getData("sind:dyn/summon_timer") < 0.7) {
                    var op = Math.min(1, Math.max(0, (-20 * entity.getData("sind:dyn/summon_timer") + 14)));
                    repulsor38.opacity = op;
                    renderIgorEffect(repulsor38, entity, isFirstPersonArm);
                    renderIgorEffect(fire38, entity, isFirstPersonArm);
                }
            }
        } else if (entity.getData("sind:dyn/summon7_timer") > 0 && !isFirstPersonArm) {
            mk7.render();
            if (entity.getData("sind:dyn/summon7_timer") < 0.65/4) {
                mk7plates.opacity = 1 - Math.min(1, Math.max(0, (80 * entity.getInterpolatedData("sind:dyn/summon7_timer") - 12)));
                mk7plates.render();
            }
            if (entity.getData("sind:dyn/summon7_timer") < 1.1/4) {
                mk7fire.render();
            }
            
        }
        var pick = entity.getWornChestplate().nbt().getString("Pick").split("sind:")[1];
        if (!entity.getData("sind:dyn/tony") && ((pick == "mark38" || pick == "mark38/rg") ? entity.getData("sind:dyn/summon_timer") < 0.05 : true)) {
            if (renderLayer == "HELMET") {
                head.render();
            } else if (renderLayer == "CHESTPLATE") {
                body.render();
                rightArm.render();
            } else if (renderLayer == "LEGGINGS") {
                rightLeg.render();
            } else if (renderLayer == "BOOTS") {
                rightBoot.render();
            }
        } else if (renderLayer == "CHESTPLATE" && isFirstPersonArm && !entity.getData("sind:dyn/tony")) {
            rightArm.render();
        } 
        if (renderLayer== "CHESTPLATE" && pick == "mark7"){
            bracelets.render();
        }
        if(renderLayer == "HELMET"){
            hud.render(entity, renderLayer, isFirstPersonArm);
            if (entity.getData("sind:dyn/edith_timer") > 0.2) {
                glasses.render();
            }
        }
    }
}
// helpers
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

function createModel(renderer, modelPath){
    var model = renderer.createResource("MODEL", modelPath);
    model.bindAnimation("sind:summon").setData((entity, data) => {
        var nbt = entity.getWornChestplate().nbt();
        var pick = nbt.getString("Pick").split("sind:")[1];
        data.load(0, entity.getInterpolatedData("sind:dyn/summon_timer"));
        data.load(1, (pick == "mark34" || pick == "mark34/zd" || pick == "mark35" || pick == "mark36") ? 1 : 0);
    });
    
    return model;
}

function createEffect(renderer, modelPointer){
    var effect = renderer.createEffect("fiskheroes:model").setModel(modelPointer);
    effect.anchor.set("body");
    effect.anchor.ignoreAnchor(true);

    return effect;
}

function renderEffect(effectPointer, entity, isFirstPersonArm){
    var eq = clamp( (-1000/75) * (entity.getInterpolatedData("sind:dyn/summon_timer")) + (32/3), 0, 1);
    var eq2 = clamp( (-1000/75) * (entity.getInterpolatedData("sind:dyn/summon_timer")) + (38/3), 0, 1);
    if (isFirstPersonArm) {
        effectPointer.anchor.set("rightArm");
        effectPointer.setOffset(0, 4, 4 + (-8 * eq) + (-8 * eq2));
    } else{ 
        effectPointer.anchor.set("body");
        effectPointer.setOffset(0, 0, 0);
    }
    effectPointer.render();
}

function renderIgorEffect(effectPointer, entity, isFirstPersonArm){
    var eq = clamp( (-1000/75) * (entity.getInterpolatedData("sind:dyn/summon_timer")) + (32/3), 0, 1);
    var eq2 = clamp( (-1000/75) * (entity.getInterpolatedData("sind:dyn/summon_timer")) + (38/3), 0, 1);
    if (isFirstPersonArm) {
        effectPointer.anchor.set("rightArm");
        effectPointer.setOffset(0, -20, 4 + (-8 * eq) + (-8 * eq2));
        effectPointer.anchor.ignoreAnchor(true);
    } else{ 
        effectPointer.anchor.set("body");
        effectPointer.setOffset(0, -24, 0);
        effectPointer.anchor.ignoreAnchor(false);
    }
    effectPointer.render();
}