extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark2/mft_layer1",
    "layer2": "sind:mark2/mft_layer2",
    "lights": "sind:lights/lights_noeyes",
    "headset": "sind:mark2/mft_headset",
    "headset_full": "sind:mark2/mft_headset_full",
    "eyepiece": "sind:mark2/mft_eyepiece",
    
    "hud_mask": "sind:null",
    "player": "sind:hud/mark2/full_mft",
    "player_mh": "sind:hud/mark2/mh_mft",
    "player0": "sind:hud/mark2/0_mft",
    "player1": "sind:hud/mark2/1_mft",
    "player2": "sind:hud/mark2/2_mft",
    "player3": "sind:hud/mark2/3_mft"
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/early_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var lightsoff, metal_heat;
var glasses, glassesModel;
var unibeam;
var jarvis = implement("sind:external/jarvis");
var hud;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
    renderer.setLights((entity, renderLayer) => {
        if (entity.getData("sind:dyn/icing")) {
            return null;
        }
        return !entity.isInWater() ? "lights" : null;
    });
}
function initEffects(renderer) {
    parent.initEffects(renderer);
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.35);

    lightsoff = renderer.createEffect("fiskheroes:overlay");
    lightsoff.texture.set("lights");

    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    glassesModel = renderer.createResource("MODEL", "sind:tony/helmet");
    glassesModel.bindAnimation("sind:glasses").setData((entity, data) => {
        var f = 1-(Math.min(1, 6*entity.getInterpolatedData("sind:dyn/jarvis_timer")));
        data.load(f < 1 ? f : 0);
    });
    glasses = renderer.createEffect("fiskheroes:model").setModel(glassesModel);
    glasses.anchor.set("head");

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");

    utils.bindParticles(renderer, "sind:early_suits").setCondition(entity => entity.getData("fiskheroes:flying"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
            "firstPerson": [0, 6, -3],
            "offset": [0, 2.75, -3],
            "size": [1.5, 1.5]
        }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimationWithData(renderer, "blah.BLah", "sind:iron_man_erectile_dysfunction", "sind:dyn/falling")
    .priority = -10;

    addAnimation(renderer, "armbeGONE", "fiskheroes:ocular_beam").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/icing_cooldown") * 1.35);
    }).priority = -11;

    addAnimation(renderer, "glasses", "sind:glasses").setData((entity, data) => {
        data.load(Math.min(1, 6*entity.getInterpolatedData("sind:dyn/jarvis_timer")));
    }).priority = 1;
}


function render(entity, renderLayer, isFirstPersonArm) {
    parent.render(entity, renderLayer, isFirstPersonArm);
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET" && Math.min(1, 6*entity.getInterpolatedData("sind:dyn/jarvis_timer")) > 0.2) {
            if (entity.isInWater() || entity.getData("sind:dyn/icing")) {
                glassesModel.texture.set("headset_full", null);
            } else {
                glassesModel.texture.set("headset", "eyepiece");
            }
            glasses.render();
        }
    }
    
    if (entity.isInWater() || entity.getData("sind:dyn/icing")) {
        lightsoff.render();
    } 
    if(renderLayer == "CHESTPLATE"){
        unibeam.render(entity, isFirstPersonArm);
    }
    if(renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
    }

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}
