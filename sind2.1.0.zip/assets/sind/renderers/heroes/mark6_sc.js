extend("sind:mark6");
loadTextures({
    "layer1": "sind:mark6/mark6_sc_layer1.tx.json",
    "layer2": "sind:mark6/mark6_sc_layer2",
    "mask": "sind:mark2/mark2_mask.tx.json",
    "chin": "sind:mark5/mark5_chin",
    "layer1gauntlet": "sind:mark6/mark6_sc_layer1_gauntlet.tx.json",
});