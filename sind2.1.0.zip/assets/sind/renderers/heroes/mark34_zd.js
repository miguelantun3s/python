extend("sind:mark34");
loadTextures({
    "layer1": "sind:mark34/mark34_zd_layer1",
    "layer2": "sind:mark34/mark34_zd_layer2",
    "back": "sind:mark34/mark34_zd_back",
    "suit": "sind:mark34/mark34_zd_suit.tx.json",
    "chin": "sind:mark34/mark34_zd_chin",
    "claw": "sind:mark34/mark34_zd_claw",
    "shoulder": "sind:mark34/mark34_zd_shoulder",
    "chest": "sind:mark34/mark34_zd_chest",
});