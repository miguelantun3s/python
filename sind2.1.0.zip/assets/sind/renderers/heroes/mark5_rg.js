extend("sind:mark5");
loadTextures({
    "complete": "sind:mark5/mark5_rg_complete",
    "suit": "sind:mark5/mark5_rg_suit.tx.json",
    "briefcase": "sind:mark5/mark5_rg_briefcase",
    "mask": "sind:mark5/mark5_ev_mask.tx.json",
    "chin": "sind:mark5/mark5_rg_chin.tx.json"
});
