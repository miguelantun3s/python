extend("sind:mark33");
loadTextures({
    "layer1": "sind:mark30/mark30_layer1",
    "layer2": "sind:mark30/mark30_layer2",
    "suit": "sind:mark30/mark30_suit.tx.json",
    "shoulder": "sind:mark30/mark30_shoulder.tx.json",
    "flaps": "sind:mark30/mark30_flaps.tx.json",
    "legflap_bottom": "sind:mark30/mark30_legflaps_bottom.tx.json",
    "legflap_top": "sind:mark30/mark30_legflaps_top.tx.json",
});

function range(){
    return 20;
}