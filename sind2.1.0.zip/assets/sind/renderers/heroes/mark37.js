extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark37/mark37_layer1.tx.json",
    "layer2": "sind:mark37/mark37_layer2",
    "lights": "sind:mark37/mark37_lights",
    "chest": "sind:mark37/mark37_chest",
    "chest2": "sind:mark37/mark37_chest2",
    "gauntlets": "sind:mark37/mark37_gauntlets",
    "suit": "sind:mark37/mark37_suit.tx.json",
    "back": "sind:mark37/mark37_back.tx.json",
    "mask": "sind:mark37/mark37_mask.tx.json",
    "rope": "sind:mark37/mark37_rope",
    "hook": "sind:mark37/mark37_hook",

    //jarvis stuff
    "player": "sind:hud/mark37/full",
    "player_mh": "sind:hud/mark37/mh",
    "player0": "sind:hud/mark37/0",
    "player1": "sind:hud/mark37/1",
    "player2": "sind:hud/mark37/2",
    "player3": "sind:hud/mark37/3",
    "h_chest": "sind:hud/mark37/chest",
    "h_chest1": "sind:hud/mark37/w_chest",
    "h_chest_mh": "sind:hud/mark37/mh_chest",
    "h_back": "sind:hud/mark37/back",
    "h_back1": "sind:hud/mark37/w_back",
    "h_back_mh": "sind:hud/mark37/mh_back",
    "h_gauntlet": "sind:hud/mark37/gauntlets",
    "h_gauntlet1": "sind:hud/mark37/w_gauntlets",
    "h_gauntlet_mh": "sind:hud/mark37/mh_gauntlets",
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/mk37_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var reactor1;
var reactor2;
var helmet;
var chest;
var rec;
var unibeam;
var boosters;
var rh;

var jarvis = implement("sind:external/jarvis");
var hud, hud2, hud3, hud4;

var chest37;
var chestLauncher37;
var rightmissile;

function initEffects(renderer, entity) {
    parent.initEffects(renderer);
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.65);
    
    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);

    var nv = renderer.bindProperty("fiskheroes:night_vision");
    nv.factor = 1
    nv.setCondition(entity => entity.getInterpolatedData("fiskheroes:mask_open_timer2") == 0 && entity.isInWater());

    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    var chestModel37 = utils.createModel(renderer, "sind:mk37/chest", "chest", null);
    chestModel37.bindAnimation("sind:mk37chest").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/srockets_timer"));
    });
    chest37 = renderer.createEffect("fiskheroes:model").setModel(chestModel37);
    chest37.anchor.set("body");

    var chestLauncherModel37 = utils.createModel(renderer, "sind:mk37/chest_launcher", "chest2", null);
    chestLauncherModel37.bindAnimation("sind:mk37chest").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/srockets_timer"));
    });
    chestLauncherModel37.generateMirror();
    chestLauncher37 = renderer.createEffect("fiskheroes:model").setModel(chestLauncherModel37);
    chestLauncher37.anchor.set("body");
    chestLauncher37.mirror = true;

    var rock = utils.createModel(renderer, "sind:mk37/torpedoes", "rockets", null);
    rock.generateMirror();
    rock.bindAnimation("sind:trockets").setData((entity, data) => {
        data.load(0, entity.getData("sind:dyn/srockets_cooldown") > 0.48);
        data.load(1, entity.getData("sind:dyn/srockets_cooldown") > 0.57);
        data.load(2, entity.getData("sind:dyn/srockets_cooldown") > 0.65);
    });
    rightmissile = renderer.createEffect("fiskheroes:model").setModel(rock);
    rightmissile.anchor.set("body");
    rightmissile.mirror = true;

    var rec = utils.createModel(renderer, "sind:mk37/back", "back", null);
    rec.bindAnimation("sind:torpedobackpack").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/sentry_timer"));
    });

    var rh1 = utils.createModel(renderer, "sind:mk37/gauntlet", "gauntlets", null);
    rh1.bindAnimation("sind:gauntlets").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/sentry_timer"));
    });
    rh1.generateMirror();

    rh = renderer.createEffect("fiskheroes:model").setModel(rh1);
    rh.anchor.set("rightArm");
    rh.mirror = true;
    rh.setOffset(-5, -2, 0);

    reactor1 = renderer.createEffect("fiskheroes:model").setModel(rec);
    reactor1.anchor.set("body");

    utils.bindParticles(renderer, "sind:mk37").setCondition(entity => entity.getData("fiskheroes:flying") && !entity.isInWater());
    utils.bindParticles(renderer, "sind:underwater").setCondition(entity => entity.getData("fiskheroes:flying") && entity.isInWater());

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 2.75, -3],
                "size": [1.5, 1.5]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    utils.bindBeam(renderer, "fiskheroes:energy_projection", "sind:rockets1", "body", 0xFFFFFF, [{
                "offset": [-3.5, 5.5, 1.0],
                "size": [0.75, 0.75]
            }, {
                "offset": [-2.5, 5.5, 1.0],
                "size": [0.75, 0.75]
            }, {
                "offset": [3.5, 5.5, 1.0],
                "size": [0.75, 0.75]
            }, {
                "offset": [2.5, 5.5, 1.0],
                "size": [0.75, 0.75]
            },
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
    var webs = renderer.bindProperty("fiskheroes:webs");
    webs.textureRope.set("rope");
    webs.textureRopeBase.set("hook");
    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, rh, reactor1, chest37, chestLauncher37);

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF, 25);
    hud2 = jarvis.createComponent(renderer, utils, "bulkchest", "h_chest", 1);
    hud3 = jarvis.createComponent(renderer, utils, "mk37gauntlets", "h_gauntlet", 1);
    hud4 = jarvis.createComponent(renderer, utils, "mk37back", "h_back", 1);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "dual.PUNCH", "sind:dual_punch")
        .setData((entity, data) => {
            data.load(entity.getData("fiskheroes:web_swinging") && entity.isPunching());
        })
        .priority = -8;
    utils.addAnimationEvent(renderer, "WEBSWING_SHOOT_RIGHT", "fiskheroes:web_swing_shoot_right");
    utils.addAnimationEvent(renderer, "WEBSWING_SHOOT_LEFT", "fiskheroes:web_swing_shoot_left");
    utils.addAnimationEvent(renderer, "WEBSHOOTER_SHOOT_RIGHT", "fiskheroes:web_shoot_right");
    utils.addAnimationEvent(renderer, "WEBSHOOTER_SHOOT_LEFT", "fiskheroes:web_shoot_left");
}

function render(entity, renderLayer, isFirstPersonArm) {
    parent.render(entity, renderLayer, isFirstPersonArm);
    if (!entity.isInWater()) {
        boosters.render(entity, renderLayer, isFirstPersonArm, false);
    }
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "CHESTPLATE") {
            reactor1.render();
            chest37.render();
            if (entity.getData("sind:dyn/srockets_timer") > 0) {
                chestLauncher37.render();
            }
            if (entity.getInterpolatedData("sind:dyn/srockets_cooldown") >= 0.35 && entity.getData("sind:dyn/srockets")) {
                rightmissile.render();
            }
        }
    }
    if(renderLayer == "CHESTPLATE"){
        rh.render();
        unibeam.render(entity, isFirstPersonArm);
    }
    if(renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud2.render(entity, renderLayer, isFirstPersonArm);
        hud3.render(entity, renderLayer, isFirstPersonArm);
        hud4.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}
