extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:null",
    "launcher": "sind:null",
    "ultron": "sind:ironlegiondrone/ultron.tx.json",
    "ultron_lights": "sind:ironlegiondrone/ultron_lights",
    "ultron_repulsor": "sind:ironlegiondrone/ultron_repulsor",

    "fire": "sind:repulsor_layer.tx.json",
    "legion": "sind:ironlegiondrone/ironlegiondrones_r3.tx.json",
    "legion_lights": "sind:ironlegiondrone/ironlegiondrones_lights",
    "legion_rep": "sind:ironlegiondrone/ironlegiondrones_repulsor"
});
var metal_heat2;
var head, body, leftArm, rightArm, rightLeg, leftLeg, rightBoot, repulsor;
var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    renderer.setTexture((entity, renderLayer) => {
        return "null";
    });
    renderer.setLights((entity, renderLayer) => {
        return "null";
    });
    renderer.bindProperty("fiskheroes:opacity").setOpacity((entity, renderLayer) => {
        return 0.99999;
    });
    renderer.setItemIcons("%s/0", "%s/1", "%s/2", "%s/3");
    renderer.showModel("HELMET", "head", "headwear");
    renderer.showModel("CHESTPLATE", "body", "rightArm", "leftArm");
    renderer.showModel("LEGGINGS", "rightLeg", "leftLeg");
    renderer.showModel("BOOTS", "rightLeg", "leftLeg");
    renderer.fixHatLayer("HELMET");

    initEffects(renderer);
    initAnimations(renderer);
}
function initEffects(renderer) {
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [{
        "firstPerson": [-4.5, 3.75, -7.0],
        "offset": [-0.5, 9.0, 0.0],
        "size": [1.5, 1.5]
    }
    ]).setCondition(entity => entity.getData("sind:dyn/rep_timer") < 1);

    var x_offset2 = -4.5 - 5;
    var y_offset2 = 3.75 - 5;
    var z_offset2 = -7.0 - 11;

    var x_offset3 = -0.5 - 5;
    var y_offset3 = 9.0 - 5;
    var z_offset3 = 0.0 - 11;

    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [{
        "firstPerson": [-4.5, 3.75, -7.0],
        "offset": [-0.5, 9.0, 0.0],
        "size": [1.5, 1.5]
    }, {
        "firstPerson": [x_offset2 - 13, y_offset2 - 32, z_offset2 + 24],
        "offset": [x_offset3 - 13, y_offset3 - 32, z_offset3 + 24],
        "size": [1.5, 1.5],
        "anchor": "body"
    }, //15
    {
        "firstPerson": [x_offset2 + 13, y_offset2 - 32, z_offset2 + 24],
        "offset": [x_offset3 + 13, y_offset3 - 32, z_offset3 + 24],
        "size": [1.5, 1.5],
        "anchor": "body"
    }, //17
    {
        "firstPerson": [x_offset2 - 32, y_offset2 - 29, z_offset2 + 21],
        "offset": [x_offset3 - 32, y_offset3 - 29, z_offset3 + 21],
        "size": [1.5, 1.5],
        "anchor": "body"
    }, //33
    {
        "firstPerson": [x_offset2 + 32, y_offset2 - 29, z_offset2 + 21],
        "offset": [x_offset3 + 32, y_offset3 - 29, z_offset3 + 21],
        "size": [1.5, 1.5],
        "anchor": "body"
    } //40
    ]).setCondition(entity => entity.getData("sind:dyn/rep_timer") == 1);

    //iron legion stuff
    ironlegion_base = createIronLegion(renderer, "sind:ironlegiondrones/everything", "legion", "legion_lights");
    ironlegion_rep = createIronLegion(renderer, "sind:ironlegiondrones/everything", null, "legion_rep");
    ironlegionfire = createIronLegion(renderer, "sind:ironlegiondrones/fire_else", null, "fire");
    ironlegionfirehand = createIronLegion(renderer, "sind:ironlegiondrones/fire_rep", null, "fire");
    ironlegionfirehandL = createIronLegion(renderer, "sind:ironlegiondrones/fire_rep2", null, "fire");

    //ultron stuff
    var headModel = renderer.createResource("MODEL", "sind:ultron/ultron_head");
    headModel.texture.set("ultron", "ultron_lights");
    head = renderer.createEffect("fiskheroes:model").setModel(headModel);
    head.anchor.set("head");

    var bodyModel = renderer.createResource("MODEL", "sind:ultron/ultron_body");
    bodyModel.texture.set("ultron", "ultron_lights");
    body = renderer.createEffect("fiskheroes:model").setModel(bodyModel);
    body.anchor.set("body");

    var rightArmModel = renderer.createResource("MODEL", "sind:ultron/ultron_rightarm");
    rightArmModel.texture.set("ultron", "ultron_lights");
    rightArm = renderer.createEffect("fiskheroes:model").setModel(rightArmModel);
    rightArm.anchor.set("rightArm");
    rightArm.setOffset(-5, -2, 0);

    var rightLegModel = renderer.createResource("MODEL", "sind:ultron/ultron_rightleg");
    rightLegModel.texture.set("ultron", "ultron_lights");
    rightLeg = renderer.createEffect("fiskheroes:model").setModel(rightLegModel);
    rightLeg.anchor.set("rightLeg");
    rightLeg.setOffset(-2, -12, 0.1);

    var leftArmModel = renderer.createResource("MODEL", "sind:ultron/ultron_leftarm");
    leftArmModel.texture.set("ultron", "ultron_lights");
    leftArm = renderer.createEffect("fiskheroes:model").setModel(leftArmModel);
    leftArm.anchor.set("leftArm");
    leftArm.setOffset(5, -2, 0);

    var leftLegModel = renderer.createResource("MODEL", "sind:ultron/ultron_leftleg");
    leftLegModel.texture.set("ultron", "ultron_lights");
    leftLeg = renderer.createEffect("fiskheroes:model").setModel(leftLegModel);
    leftLeg.anchor.set("leftLeg");
    leftLeg.setOffset(2, -12, -0.1);

    var rightBootModel = renderer.createResource("MODEL", "sind:ultron/ultron_rightboot");
    rightBootModel.texture.set("ultron", "ultron_lights");
    rightBootModel.generateMirror();
    rightBoot = renderer.createEffect("fiskheroes:model").setModel(rightBootModel);
    rightBoot.anchor.set("rightLeg");
    rightBoot.setOffset(-2, -12, -0.1);
    rightBoot.mirror = true;

    var repulsorModel = renderer.createResource("MODEL", "sind:ultron/ultron_rightarm");
    repulsorModel.texture.set(null, "ultron_repulsor");
    repulsor = renderer.createEffect("fiskheroes:model").setModel(repulsorModel);
    repulsor.anchor.set("rightArm");
    repulsor.setOffset(-5, -2, 0);

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");

    metal_heat2 = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat2.includeEffects(head, body, rightArm, rightLeg, leftArm, leftLeg, rightBoot);
}
function initAnimations(renderer) {
    renderer.removeCustomAnimation("iron_man.LAND");
    addAnimationWithData(renderer, "iron_man.LAND3", "sind:ironman_landing", "sind:dyn/superhero_landing_timer").setCondition(entity => entity.getData("sind:dyn/rep_timer") < 1)
        .priority = -8;
    addAnimation(renderer, "ultron", "sind:ultron").setData((entity, data) => {
        data.load(0, entity.isAlive() ? 1 : 0);
    }).priority = -12;
    addAnimationWithData(renderer, "ultron.AIMING", "sind:ultron_aim", "fiskheroes:aiming_timer")
        .setCondition(entity => !entity.getHeldItem().doesNeedTwoHands() && !entity.getHeldItem().isRifle())
        .priority = 10;
}
function render(entity, renderLayer) {
    if (entity.getData("sind:dyn/rep_timer") > 0) {
        ironlegion_base.render();
        ironlegion_rep.render();
        ironlegion_rep.opacity = 1 - entity.getInterpolatedData("sind:dyn/srockets_timer");
        ironlegionfire.render();
        if (entity.getData("sind:dyn/srockets_timer") < 1) {
            ironlegionfirehandL.render();
            if (entity.getData("fiskheroes:aiming_timer") < 1) {
                ironlegionfirehand.render();
            }
        }
    }
    switch (renderLayer) {
        case "HELMET":
            head.render();
            break;
        case "CHESTPLATE":
            body.render();
            rightArm.render();
            leftArm.render();
            repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
            repulsor.render();
            break;
        case "LEGGINGS":
            rightLeg.render();
            leftLeg.render();
            break;
        case "BOOTS":
            rightBoot.render();
            break;
    }
    metal_heat2.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat2.render();
}

function createIronLegion(renderer, model, texture2, lights) {
    var Model1 = renderer.createResource("MODEL", model);
    Model1.bindAnimation("sind:flight/ironlegion.anim.json").setData((entity, data) => {
        var timer = Math.max((entity.getData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("sind:dyn/superhero_landing_timer"))), entity.getData("sind:dyn/flight_timer"));
        data.load(0, timer);
        data.load(1, entity.getData("fiskheroes:flight_boost_timer"));
    });

    Model1.bindAnimation("sind:ironlegionaim").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:aiming_timer"));
        data.load(1, 1 - (Math.max(entity.getInterpolatedData("fiskheroes:aiming_timer"), entity.getInterpolatedData("sind:dyn/sneaking_timer"), entity.getInterpolatedData("sind:dyn/srockets_timer"), entity.getInterpolatedData("fiskheroes:beam_charge"))));
    });
    Model1.bindAnimation("sind:ironlegionrockets").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/srockets_timer"));
    });
    Model1.bindAnimation("sind:ironlegionenter").setData((entity, data) => {
        data.load(entity.getData("sind:dyn/rep") ? entity.getInterpolatedData("sind:dyn/rep_timer") : 1);
    });
    Model1.bindAnimation("sind:ironlegionexit").setData((entity, data) => {
        data.load(1 - entity.getInterpolatedData("sind:dyn/rep_timer") * 1 - entity.getData("sind:dyn/rep"));
    });
    Model1.bindAnimation("sind:ironlegionsneak").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/sneaking_timer"));
        data.load(1, 1 - entity.getInterpolatedData("fiskheroes:aiming_timer"));
    });
    Model1.texture.set(texture2, lights);
    var effect = renderer.createEffect("fiskheroes:model").setModel(Model1);
    effect.anchor.set("body");

    return effect;
}