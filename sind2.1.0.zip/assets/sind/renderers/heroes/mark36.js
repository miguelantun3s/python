extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark36/mark36_layer1",
    "layer2": "sind:mark36/mark36_layer2",
    "back": "sind:mark36/mark36_back",
    "lights": "sind:mark35/mark35_lights",
    "suit": "sind:mark36/mark36_suit.tx.json",
    "mask": "sind:mark36/mark36_mask.tx.json",
    "shoulder": "sind:mark36/mark36_shoulder.tx.json",
    "repulsor": "fiskheroes:iron_man_repulsor",
    "repulsor_left": "fiskheroes:iron_man_repulsor_left",
    "repulsor_boots": "fiskheroes:iron_man_repulsor_boots",

    //jarvis stuff
    "player": "sind:hud/mark36/full",
    "player_mh": "sind:hud/mark36/mh",
    "player0": "sind:hud/mark35/0",
    "player1": "sind:hud/mark36/1",
    "player2": "sind:hud/mark35/2",
    "player3": "sind:hud/mark35/3",
    "h_back": "sind:hud/mark35/back",
    "h_back1": "sind:hud/mark35/w_back",
    "h_back_mh": "sind:hud/mark35/mh_back",
    "h_shoulder": "sind:hud/mark35/shoulder",
    "h_shoulder1": "sind:hud/mark35/w_shoulder",
    "h_shoulder_mh": "sind:hud/mark35/mh_shoulder",
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/mk36_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var boosters;
var reactor1;

var helmet;
var reactor;
var accessories;
var rh;
var lh;
var metal_heat;
var unibeam;

var jarvis = implement("sind:external/jarvis");
var hud, hud2, hud3;

function initEffects(renderer) {
    parent.initEffects(renderer);
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, -0.5, -0.35);
    
    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    reactor1= iron_man_utils.createMk35Torso(renderer, utils, "back", null, "shoulder", null);

    utils.bindParticles(renderer, "sind:mk36").setCondition(entity => entity.getData("fiskheroes:flying"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 1.75, -3],
                "size": [1.5, 1.75]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));
    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, reactor1.reactor1, reactor1.rshoulder);

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF, 25, "yes i am mk36");
    hud2 = jarvis.createComponent(renderer, utils, "mk35shoulders", "h_shoulder", 1);
    hud3 = jarvis.createComponent(renderer, utils, "mk35back", "h_back", 1);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);

    addAnimation(renderer, "snapper.POSE", "sind:clawsidle")
    .setData((entity, data) => {
        data.load(1);
    });

    addAnimationWithData(renderer, "snapper.CLAW", "sind:dual_aiming", "sind:dyn/beam_charging_timer2").priority = 12;
}
function render(entity, renderLayer, isFirstPersonArm) {
    parent.render(entity, renderLayer, isFirstPersonArm);
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "CHESTPLATE") {
            reactor1.render(entity, renderLayer, isFirstPersonArm);
        }
    }
    if(renderLayer == "CHESTPLATE"){
        unibeam.render(entity, isFirstPersonArm);
    }
    if(renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud2.render(entity, renderLayer, isFirstPersonArm);
        hud3.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}
