extend("sind:mark10");
loadTextures({
    "layer1": "sind:mark19/mark19_layer1",
    "layer2": "sind:mark19/mark19_layer2.tx.json",
    "suit": "sind:mark19/mark19_suit.tx.json",
    "mask": "sind:mark19/mark19_mask.tx.json",
    "chin": "sind:mark19/mark19_chin",
    "chest": "sind:mark19/mark19_chest",
    "flaps": "sind:mark9/mark9_flaps.tx.json",
    "thigh": "sind:mark19/mark19_thigh",

    //jarvis stuff
    "player": "sind:hud/mark19/full",
    "player2": "sind:hud/mark19/2",
    "player3": "sind:hud/mark25/3"
});
function range(){
    return 20;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimationWithData(renderer, "clamping", "sind:feetlock", "sind:dyn/clamp_timer")
        .priority = -7;
}