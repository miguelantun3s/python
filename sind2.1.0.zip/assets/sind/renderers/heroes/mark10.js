extend("sind:external/iron_man_base");
loadTextures({
    "layer1": "sind:mark10/mark10_layer1",
    "layer2": "sind:mark10/mark10_layer2.tx.json",
    "suit": "sind:mark10/mark10_suit.tx.json",
    "mask": "sind:mark3/mark3_mask.tx.json",
    "chin": "sind:mark4/mark4_chin",
    "chest": "sind:mark10/mark10_chest",
    "flaps": "sind:mark9/mark9_flaps.tx.json",
    "thigh": "sind:mark10/mark10_thigh",

    //jarvis stuff
    "player": "sind:hud/mark10/full",
    "player_mh": "sind:hud/mark10/mh",
    "player1": "sind:hud/mark10/1",
    "player2": "sind:hud/mark10/2",
    "player3": "sind:hud/mark35/3",
    "h_bulkchest": "sind:hud/mark10/chest",
    "h_bulkchest1": "sind:hud/mark10/w_chest",
    "h_bulkchest_mh": "sind:hud/mark10/mh_chest"
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("fiskheroes:external/iron_man_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var rightmissile;
var helmet, chin;
var rock;
var thigh;
var chest;
var metal_heat;
var unibeam;

var jarvis = implement("sind:external/jarvis");
var hud, hud2;

function range(){
    return 15;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
}

function initEffects(renderer) {
    parent.initEffects(renderer);

    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.65);
    
    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    chin = iron_man_utils.createChinplate(renderer, "chin", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    var thighModel = utils.createModel(renderer, "sind:thigh", "thigh", null);
    thighModel.generateMirror();
    thighModel.bindAnimation("sind:thigh").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/srockets_timer"));
    });
    thigh = renderer.createEffect("fiskheroes:model").setModel(thighModel);
    thigh.anchor.set("rightLeg");
    thigh.mirror = true;
    thigh.setOffset(-2.0, -12.0, 0);

    var rock = utils.createModel(renderer, "sind:thighmissilesleft", "rockets", null);
    rock.generateMirror();
    rock.bindAnimation("sind:trockets").setData((entity, data) => {
        data.load(0, entity.getData("sind:dyn/srockets_cooldown") > 0.48);
        data.load(1, entity.getData("sind:dyn/srockets_cooldown") > 0.57);
        data.load(2, entity.getData("sind:dyn/srockets_cooldown") > 0.65);
    });
    rightmissile = renderer.createEffect("fiskheroes:model").setModel(rock);
    rightmissile.anchor.set("leftLeg");
    rightmissile.mirror = true;
    rightmissile.setOffset(2.0, -12.0, 0);

    flares = iron_man_utils.createFlares(renderer, utils, "layer2", null);
    chest = iron_man_utils.createBulkChest(renderer, utils, "chest", null);
    flaps = iron_man_utils.createFlaps(renderer, utils, "flaps", null, 7);

    utils.bindParticles(renderer, "fiskheroes:iron_man").setCondition(entity => entity.getData("fiskheroes:flying"));
    utils.bindBeam(renderer, "fiskheroes:energy_projection", "sind:rockets1", "rightLeg", 0xFFFFFF, [{
                "offset": [4.0, 2.0, 1.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [3.0, 2.0, 1.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [4.0, 3.0, 1.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [3.0, 3.0, 1.0],
                "size": [0.25, 0.25]
            },
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

    utils.bindBeam(renderer, "fiskheroes:energy_projection", "sind:rockets1", "leftLeg", 0xFFFFFF, [{
                "offset": [-4.0, 2.0, 1.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-3.0, 2.0, 1.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-4.0, 3.0, 1.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-3.0, 3.0, 1.0],
                "size": [0.25, 0.25]
            },
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 2.75, -3],
                "size": [1.5, 1.5]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, chin.effect, rightmissile, thigh, chest.chest, flaps.flaps, flares.flares);
    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF, range());
    hud2 = jarvis.createComponent(renderer, utils, "bulkchest", "h_bulkchest", 1);
}

function render(entity, renderLayer, isFirstPersonArm) {
    parent.render(entity, renderLayer, isFirstPersonArm);
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            chin.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "LEGGINGS") {
            if (entity.getData("sind:dyn/srockets_timer") > 0) {
                thigh.render();
            }
            if (entity.getData("sind:dyn/flares_timer") > 0 && entity.getData("fiskheroes:suit_open_timer") == 0) {
                flares.render(entity, renderLayer, isFirstPersonArm);
            }
            if (entity.getInterpolatedData("sind:dyn/srockets_cooldown") >= 0.35 && entity.getData("sind:dyn/srockets")) {
                rightmissile.render();
            }
        }
    }
    if(renderLayer == "CHESTPLATE"){
        flaps.render(entity, renderLayer, isFirstPersonArm);
        chest.render(entity, renderLayer, isFirstPersonArm);
        unibeam.render(entity, isFirstPersonArm);
    }
    if(renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud2.render(entity, renderLayer, isFirstPersonArm);
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}
